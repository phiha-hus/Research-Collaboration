% Example problems 2,3 and 4 from A pseudo-spectra based characterisation
% of the robust strong H-infinity norm of time-delay systems with
% real-valued and structured uncertainties by Appeltans and Michiels.

addpath('../SRC');
addpath('../SRC/TDS_EIGV');
example_uncertain_tds_create
% Example 2 - robust strong H-infinity norm attained at finite frequency
% x'(t) = (-7 + 3 * delta_1 * 1) x(t) + (-5 + 2 * delta_2 * 1 ) x(t-1) + 4 w(t) ;
% z (t) = (2 - 2 * delta_1 * 1) x(t) + (1 + delta_1) w(t) +  w(t-1);
% with |delta_1| <= 0.15 and |delta_2| <= 0.2
options = struct('caution_level',0,'print_level',1,'metadata',ex1_meta);
uncertain_tds_rob_strong_hinfnorm(ex1_tds,options)
% Example 3 - robust strong H-infinity norm attained at infinity
% x'(t) = (-3 + 1 * delta_2 * 1) x(t) + (-1 + 3 * delta_1 * 1 ) x(t-1) + 4 w(t) ;
% z (t) = (-2 - 3 * delta_1 * 1 + 2*delta_2 *1) x(t) + (3 + delta_1) w(t) + (1+delta_1+delta_2) w(t-1);
% with |delta_1| <= 0.1 and |delta_2| <= 0.25
options = struct('caution_level',0,'print_level',1,'metadata',ex2_meta);
uncertain_tds_rob_strong_hinfnorm(ex2_tds,options)
% Example 4 - robust strong H-infinity norm attained at infinity for
% arbitrairy small delay perturbations.
% x'(t) = (-2+delta_1) x(t) + (1+delta_2) x(t-1) - w(t) + (-0.5+delta_1) w(t-2)
% z(t) = (-2+2*delta_2) x(t) + x(t-2) + (5+4*delta_1) w(t) + 1.5 w(t-1) + (-3 + delta_1) w(t-2)
% with |delta_1|<= 0.2 and |delta_2|<= 0.3
options = struct('caution_level',0,'print_level',1,'metadata',ex3_meta);
uncertain_tds_rob_strong_hinfnorm(ex3_tds,options)