%Open loop systems (to which real-valued uncertainties are added) of the
%benchmark problems introduced in Section 7.3 of Fixed-order H-infinity
%control for interconnected systems using delay differential algebraic
%equations by Suat Gumussoy and Wim Michiels (Published in SIAM Journal on
%Control and Optimization,49(5):2212-2238 in 2011)
clear
addpath('../SRC');
addpath('../SRC/TDS_EIGV');

load('benchmark_Gumussoy_Michiels_2011')
metadata_P1 = uncertain_tds_metadata(P1);
metadata_P2 = uncertain_tds_metadata(P2);
metadata_P3 = uncertain_tds_metadata(P3);
metadata_P4 = uncertain_tds_metadata(P4);
metadata_P5 = uncertain_tds_metadata(P5);

uncertain_tds_rob_strong_hinfnorm(P1,struct('caution_level',0,'print_level',1,'metadata_tds',metadata_P1));
uncertain_tds_rob_strong_hinfnorm(P2,struct('caution_level',0,'print_level',1,'metadata_tds',metadata_P2));
uncertain_tds_rob_strong_hinfnorm(P3,struct('caution_level',0,'print_level',1,'metadata_tds',metadata_P3));
uncertain_tds_rob_strong_hinfnorm(P4,struct('caution_level',0,'print_level',1,'metadata_tds',metadata_P4));
uncertain_tds_rob_strong_hinfnorm(P5,struct('caution_level',0,'print_level',1,'metadata_tds',metadata_P5));