addpath('../SRC/');

% Example 1
% x'(t) = (-7 + 3 * delta_1 * 1) x(t) + (-5 + 2 * delta_2 * 1 ) x(t-1) + 4 w(t) ;
% z (t) = (2 - 2 * delta_1 * 1) x(t) + (1 + delta_1) w(t) +  w(t-1);
% with |delta_1| <= 0.15 and |delta_2| <= 0.2
ex1_A = {[-7],[-5]};
ex1_hA = [0,1];
ex1_B = {[4]};
ex1_hB = [0];
ex1_C = {[2]};
ex1_hC = [0];
ex1_D = {[1],[1]};
ex1_hD = [0 1];
ex1_delta(1) = struct('delta_bar',0.15,'q',1,'r',1);
ex1_delta(2) = struct('delta_bar',0.2, 'q',1,'r',1);
ex1_uA = cell(1,2);
ex1_uA{1}(1) = struct('l',1,'G',3,'H',1);
ex1_uA{2}(1) = struct('l',2,'G',2,'H',1);
ex1_uB = cell(1,1);
ex1_uC = cell(1,1);
ex1_uC{1}(1) = struct('l',2,'G',-2,'H',1);
ex1_uD = cell(1,2);
ex1_uD{1}(1) = struct('l',1,'G',1,'H',1);
[ex1_tds,ex1_meta] = uncertain_tds_create('retarded',ex1_A,ex1_hA,ex1_B,ex1_hB,ex1_C,ex1_hC,ex1_D,ex1_hD,ex1_delta,ex1_uA,ex1_uB,ex1_uC,ex1_uD);
clear ex1_A  ex1_hA ex1_B ex1_hB ex1_C ex1_hC ex1_D ex1_hD ex1_delta ex1_uA ex1_uB ex1_uC ex1_uD;

% Example 2
% x'(t) = (-3 + 1 * delta_2 * 1) x(t) + (-1 + 3 * delta_1 * 1 ) x(t-1) + 4 w(t) ;
% z (t) = (-2 - 3 * delta_1 * 1 + 2*delta_2 *1) x(t) + (3 + delta_1) w(t) + (1+delta_1+delta_2) w(t-1);
% with |delta_1| <= 0.1 and |delta_2| <= 0.25
ex2_A = {[-3],[-1]};
ex2_hA = [0,1];
ex2_B = {[4]};
ex2_hB = [0];
ex2_C = {[-2]};
ex2_hC = [0];
ex2_D = {[3],[1]};
ex2_hD = [0 1];
ex2_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
ex2_delta(2) = struct('delta_bar',0.25, 'q',1,'r',1);
ex2_uA = cell(1,2);
ex2_uA{1}(1) = struct('l',2,'G',1,'H',1);
ex2_uA{2}(1) = struct('l',1,'G',3,'H',1);
ex2_uB = cell(1,1);
ex2_uC = cell(1,1);
ex2_uC{1}(1) = struct('l',1,'G',-3,'H',1);
ex2_uC{1}(1) = struct('l',2,'G',2,'H',1);
ex2_uD = cell(1,2);
ex2_uD{1}(1) = struct('l',1,'G',1,'H',1);
ex2_uD{2}(1) = struct('l',1,'G',1,'H',1);
ex2_uD{2}(2) = struct('l',2,'G',1,'H',1);
[ex2_tds,ex2_meta] = uncertain_tds_create('retarded',ex2_A,ex2_hA,ex2_B,ex2_hB,ex2_C,ex2_hC,ex2_D,ex2_hD,ex2_delta,ex2_uA,ex2_uB,ex2_uC,ex2_uD);
clear ex2_A  ex2_hA ex2_B ex2_hB ex2_C ex2_hC ex2_D ex2_hD ex2_delta ex2_uA ex2_uB ex2_uC ex2_uD;

% Example 3
% x'(t) = (-2+delta_1) x(t) + (1+delta_2) x(t-1) - w(t) + (-0.5+delta_1) w(t-2)
% z(t) = (-2+2*delta_2) x(t) + x(t-2) + (5+4*delta_1) w(t) + 1.5 w(t-1) + (-3 + delta_1) w(t-2)
% with |delta_1|<= 0.2 and |delta_2|<= 0.3
ex3_A = {-2,1};
ex3_hA = [0 1];
ex3_B = {-1,-0.5};
ex3_hB = [0 2];
ex3_C = {-2 1};
ex3_hC = [0 2];
ex3_D = {5,1.5,-3};
ex3_hD = [0 1 2];
ex3_delta(1) = struct('delta_bar',0.2,'q',1,'r',1);
ex3_delta(2) = struct('delta_bar',0.3,'q',1,'r',1);
ex3_uA = cell(1,2);
ex3_uA{1} = struct('l',1,'G',1,'H',1);
ex3_uA{2} = struct('l',2,'G',1,'H',1);
ex3_uB = cell(1,2);
ex3_uB{2} = struct('l',1,'G',1,'H',1);
ex3_uC = cell(1,2);
ex3_uC{1} = struct('l',2,'G',2,'H',1);
ex3_uD = cell(1,3);
ex3_uD{1} = struct('l',1,'G',4,'H',1);
ex3_uD{3} = struct('l',1,'G',1,'H',1);
[ex3_tds,ex3_meta] = uncertain_tds_create('retarded',ex3_A,ex3_hA,ex3_B,ex3_hB,ex3_C,ex3_hC,ex3_D,ex3_hD,ex3_delta,ex3_uA,ex3_uB,ex3_uC,ex3_uD);
clear ex3_A ex3_hA ex3_B ex3_hB ex3_C ex3_hC ex3_D ex3_hD ex3_delta ex3_uA ex3_uB ex3_uC ex3_uD

% Example 4 (Non scalar uncertainties)
% x'(t) = (-7 + [1 1] delta_1 [0; 1]) x(t) + (1 + [1 0] delta_1 [1; 1] + 2 delta_2) x(t-1) + 4 w(t) ;
% z (t) = (2 + [1 0] delta_1 [1; 0]+ [0 1] delta_1 [0; 1]) x(t) + (1 + delta_2) w(t) +  w(t-1);
% with |delta_1| <= 0.2 and |delta_2| <= 0.1
ex4_A = {[-7],[-5]};
ex4_hA = [0,1];
ex4_B = {[4]};
ex4_hB = [0];
ex4_C = {[2]};
ex4_hC = [0];
ex4_D = {[1],[1]};
ex4_hD = [0 1];
ex4_delta(1) = struct('delta_bar',0.2,'q',2,'r',2);
ex4_delta(2) = struct('delta_bar',0.1,'q',1,'r',1);
ex4_uA = cell(1,2);
ex4_uA{1}(1) = struct('l',1,'G',[1 1],'H',[0; 1]);
ex4_uA{2}(1) = struct('l',2,'G',2,'H',1);
ex4_uA{2}(2) = struct('l',1,'G',[1 0],'H',[1; 1]);
ex4_uB = cell(1,1);
ex4_uC = cell(1,1);
ex4_uC{1}(1) = struct('l',1,'G',[1 0],'H',[1; 0]);
ex4_uC{1}(2) = struct('l',1,'G',[0 1],'H',[0; 1]);
ex4_uD = cell(1,2);
ex4_uD{1}(1) = struct('l',2,'G',1,'H',1);
[ex4_tds,ex4_meta] = uncertain_tds_create('retarded',ex4_A,ex4_hA,ex4_B,ex4_hB,ex4_C,ex4_hC,ex4_D,ex4_hD,ex4_delta,ex4_uA,ex4_uB,ex4_uC,ex4_uD);
clear ex4_A  ex4_hA ex4_B ex4_hB ex4_C ex4_hC ex4_D ex4_hD ex4_delta ex4_uA ex4_uB ex4_uC ex4_uD;

% Example 5 (No feedthrough terms)
ex5_A = {[-3 1;0 -2],[-1 1;0 -3]};
ex5_hA = [0,1];
ex5_B = {[4 2;-1 3]};
ex5_hB = [0];
ex5_C = {[-2 1;-4 3]};
ex5_hC = [0];
ex5_D = {};
ex5_hD = [];
ex5_delta(1) = struct('delta_bar',0.3,'q',2,'r',1);
ex5_delta(2) = struct('delta_bar',0.15, 'q',1,'r',2);
ex5_delta(3) = struct('delta_bar',0.2, 'q',1,'r',1);
ex5_uA = cell(1,2);
ex5_uA{1}(1) = struct('l',1,'G',[1 1;0 0],'H',[1 0]);
ex5_uA{2}(1) = struct('l',2,'G',[3;4],'H',[1 0;0 1]);
ex5_uB = cell(1,1);
ex5_uC = cell(1,1);
ex5_uC{1}(1) = struct('l',1,'G',[-3 2;0 1],'H',[1 4]);
ex5_uC{1}(2) = struct('l',3,'G',[1;0] ,'H',[1 0]);
ex5_uD = cell(1,0);
[ex5_tds,ex5_meta] = uncertain_tds_create('retarded',ex5_A,ex5_hA,ex5_B,ex5_hB,ex5_C,ex5_hC,ex5_D,ex5_hD,ex5_delta,ex5_uA,ex5_uB,ex5_uC,ex5_uD);
clear ex5_A  ex5_hA ex5_B ex5_hB ex5_C ex5_hC ex5_D ex5_hD ex5_delta ex5_uA ex5_uB ex5_uC ex5_uD;

% Example 6 (IFAC 15th workshop on time-delay systems - paper)

% Example 7 (IFAC 15th workshop on time-delay systems -presentation)
% (currently without uncertainties on delays)
ex7_A = {[-5 2;-7 -2],[2 1;0.5 1],[-1 0;0.1 1]};
ex7_hA = [0 1.4 2.12];
ex7_B = {[1;-2] [2;2]};
ex7_hB = [0 1.4];
ex7_C = {[1 2]};
ex7_hC = [0];
ex7_D = {};
ex7_hD = [];
ex7_delta(1) = struct('delta_bar',0.3,'q',1,'r',1);
ex7_delta(2) = struct('delta_bar',0.2,'q',2,'r',2);
ex7_uA = cell(1,3);
ex7_uA{1}(1) = struct('l',1,'G',[1;0],'H',[1 0]);
ex7_uA{1}(2) = struct('l',1,'G',[0;1],'H',[0 1]);
ex7_uA{2} = struct('l',2,'G',eye(2),'H',eye(2));
ex7_uA{3} = struct('l',1,'G',[1;0],'H',[1 0]);
ex7_uB = cell(1,2);
ex7_uB{2} = struct('l',2,'G',[1 0;0 0],'H',[1;0]);
ex7_uC = cell(1,1);
ex7_uC{1} = struct('l',1,'G',1,'H',[3 -2]);
ex7_uD = cell(1,0);
[ex7_tds,ex7_meta] = uncertain_tds_create('retarded',ex7_A,ex7_hA,ex7_B,ex7_hB,ex7_C,ex7_hC,ex7_D,ex7_hD,ex7_delta,ex7_uA,ex7_uB,ex7_uC,ex7_uD);
clear ex7_A  ex7_hA ex7_B ex7_hB ex7_C ex7_hC ex7_D ex7_hD ex7_delta ex7_uA ex7_uB ex7_uC ex7_uD;

% Example 8 (DDAE system)
ex8_E = [zeros(2,4);zeros(2,2) eye(2)];
ex8_A = {[0 1 -1 0;0.5 2 0 -1;1 -0.5 0 0;1 -3 0 0],[0 0 0 0;0.2 1 0 0;zeros(2,4)]};
ex8_hA = [0 0.2];
ex8_B = {[0;0;1;0]};
ex8_hB = [0.5];
ex8_C = {[1 1 0 0;0 1 0 0]};
ex8_hC = 0;
ex8_D = {};
ex8_hD = [];
ex8_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
ex8_delta(2) = struct('delta_bar',0.15,'q',1,'r',1);
ex8_uA = cell(1,2);
ex8_uA{1} = struct('l',1,'G',[0;0;1;0],'H',[0 1 0 0]);
ex8_uA{2} = struct('l',2,'G',[0;1;0;0],'H',[1 0 0 0]);
ex8_uB = cell(1,1);
ex8_uC = cell(1,1);
ex8_uD = cell(1,0);
[ex8_tds,ex8_meta] = uncertain_tds_create('ddae',ex8_E,ex8_A,ex8_hA,ex8_B,ex8_hB,ex8_C,ex8_hC,ex8_D,ex8_hD,ex8_delta,ex8_uA,ex8_uB,ex8_uC,ex8_uD);
clear ex8_E ex8_A  ex8_hA ex8_B ex8_hB ex8_C ex8_hC ex8_D ex8_hD ex8_delta ex8_uA ex8_uB ex8_uC ex8_uD;
