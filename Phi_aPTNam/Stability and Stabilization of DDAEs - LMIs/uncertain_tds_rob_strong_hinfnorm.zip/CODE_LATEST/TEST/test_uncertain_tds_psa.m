clear variables
addpath('../SRC');
addpath('../SRC/TDS_EIGV');
%% TEST 1: retarded system no delay + no uncertainty
test1_A = {[-1 2;0 -0.2]};
test1_C = {[1 2]};
[test1_utds,test1_metadata] = uncertain_tds_create('retarded',test1_A,[0],{},...
    [],test1_C,[0],{},[],struct('delta_bar',0.1,'q',1,'r',1),cell(1,1),...
    cell(1,0),{struct('l',1,'G',1,'H',[1 0])},cell(1,0));
[psa] = uncertain_tds_psa(test1_utds,struct('metadata_tds',test1_metadata));
assert(psa == -0.2,'TEST 1 failed.')
%% TEST 2: retarded system no delay 
test2_A = {[-1 2;0 -0.2]};
test2_C = {[1 2]};
test2_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test2_delta(2) = struct('delta_bar',0.95,'q',1,'r',1);
test2_uA = cell(1,1);
test2_uA{1}(1) = struct('l',1,'G',[0;1],'H',[0 1]);
test2_uA{1}(2) = struct('l',2,'G',[1;0],'H',[1 1]);
[test2_utds,test2_metadata] = uncertain_tds_create('retarded',test2_A,[0],{},...
    [],test2_C,0,{},[],test2_delta,test2_uA,...
    cell(1,0),{struct('l',1,'G',1,'H',[1 0])},cell(1,0));
[psa] = uncertain_tds_psa(test2_utds,struct('metadata_tds',test2_metadata,'print_level',1));
assert(abs(psa +0.05)<1e-8,'TEST 2 failed.')
%% TEST 3: retarded system with delay + no uncertainty
test3_A = {[-1 2;0 -0.2],[4 5;-2 4],[-1 3;-4 -5]};
test3_C = {[1 2]};
test3_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test3_delta(2) = struct('delta_bar',0.95,'q',1,'r',1);
test3_uA = cell(1,3);
[test3_utds,test3_metadata] = uncertain_tds_create('retarded',test3_A,[0 1 2],{},...
    [],test3_C,0,{},[],test3_delta,test3_uA,...
    cell(1,0),{struct('l',1,'G',1,'H',[1 0])},cell(1,0));
[psa] = uncertain_tds_psa(test3_utds,struct('metadata_tds',test3_metadata))
%% TEST 4: retarded system with delay + unused uncertainty
test4_A = {[-1 2;0 -0.2],[4 5;-2 4],[-1 3;-4 -5]};
test4_C = {[1 2]};
test4_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test4_delta(2) = struct('delta_bar',0.1,'q',1,'r',1);
test4_delta(3) = struct('delta_bar',0.05,'q',2,'r',2);
test4_uA = cell(1,3);
test4_uA{1}(1) = struct('l',3,'G',eye(2),'H',eye(2));
test4_uA{1}(2) = struct('l',2,'G',[1;0],'H',[1 1]);
test4_uA{3}(1) = struct('l',2,'G',[0;1],'H',[0 1]);
[test4_utds,test4_metadata] = uncertain_tds_create('retarded',test4_A,[1 2 3],{},...
    [],test4_C,2,{},[],test4_delta,test4_uA,...
    cell(1,0),{struct('l',1,'G',1,'H',[1 0])},cell(1,0));
[psa] = uncertain_tds_psa(test4_utds,struct('metadata_tds',test4_metadata,'print_level',1))
%% TEST 5: DDAE system without delay
test5_E = [1 0;0 0];
test5_A = {[-0.1 0;0 1]};
test5_C = {[1 0]};
test5_delta = struct('delta_bar',{},'q',{},'r',{});
[test5_utds,test5_metadata] = uncertain_tds_create('ddae',test5_E,test5_A,0 ...
    ,{},[],test5_C,0,{},[],test5_delta,cell(1,1),...
    cell(1,0),cell(1,1),cell(1,0));
[psa] = uncertain_tds_psa(test5_utds,struct('metadata_tds',test5_metadata));
assert(abs(psa +0.1)<1e-8,'TEST 5 failed.')
%% TEST 6: DDAE system with delay 
test6_E = [1 0;0 0];
test6_A = {[-0.1 0;0 1],[-1 2;0.5 -0.2],[-3 1;-2 0]};
test6_C = {[1 0]};
test6_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test6_delta(2) = struct('delta_bar',0.1,'q',1,'r',1);
test6_delta(3) = struct('delta_bar',0.05,'q',2,'r',2);
test6_uA = cell(1,3);
test6_uA{1}(1) = struct('l',3,'G',eye(2),'H',eye(2));
test6_uA{1}(2) = struct('l',2,'G',[1;0],'H',[1 1]);
test6_uA{3}(1) = struct('l',2,'G',[0;1],'H',[0 1]);
[test6_utds,test6_metadata] = uncertain_tds_create('ddae',test6_E,test6_A,[0 1 2] ...
    ,{},[],test6_C,0,{},[],test6_delta,test6_uA,...
    cell(1,0),{struct('l',1,'G',1,'H',[1 0])},cell(1,0));
[psa] = uncertain_tds_psa(test6_utds,struct('metadata_tds',test6_metadata))
%% TEST 7: No scalar uncertainty 
test7_E = [1 0;0 0];
test7_A = {[-0.1 0;0 1],[-1 2;0.5 -0.2],[-3 1;-2 0]};
test7_C = {[1 0]};
test7_delta(1) = struct('delta_bar',0.05,'q',2,'r',2);
test7_uA = cell(1,3);
test7_uA{1}(1) = struct('l',1,'G',eye(2),'H',eye(2));
[test7_utds,test7_metadata] = uncertain_tds_create('ddae',test7_E,test7_A,[0 1 2] ...
    ,{},[],test7_C,0,{},[],test7_delta,test7_uA,...
    cell(1,0),cell(1,1),cell(1,0));
[psa] = uncertain_tds_psa(test7_utds,struct('metadata_tds',test7_metadata))