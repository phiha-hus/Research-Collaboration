clear variables
addpath('../SRC');
addpath('../SRC/TDS_EIGV');
%% TEST 1: uncertain_tds has no direct feed through terms
[test1_utds,test1_metadata] = uncertain_tds_create('retarded',{[1]},[0],{},...
    [],{},[],{},[],struct('delta_bar',0.1,'q',1,'r',1),{struct('l',1,'G',1,'H',1)},...
    cell(1,0),cell(1,0),cell(1,0));
options = struct('metadata',test1_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test1_utds,options);
assert(rob_strong_asympt_hinfnorm == 0,'Test 1 failed. For this test case uncertain_tds has no direct feed through terms thus the robust strong asymptotic H-infinity norm should equal 0');
%% TEST 2: uncertain_tds has only one direct feed through term with no uncertainty
D = rand(5,5);
[test2_utds,test2_metadata] = uncertain_tds_create('retarded',{[1]},[0],{},...
    [],{},[],{D},[0],struct('delta_bar',0.1,'q',1,'r',1),{struct('l',1,'G',1,'H',1)},...
    cell(1,0),cell(1,0),cell(1,1));
options = struct('metadata',test2_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test2_utds,options);
assert(abs(rob_strong_asympt_hinfnorm - max(svd(D)))<1e-10,'Test 2 failed. For this test case uncertain_tds has only one direct feed through term with no uncertainty thus the robust strong asymptotic H-infinity norm should equal the largest singular value of D0');
%% TEST 3: uncertain_tds has only one direct feed through term with scalar uncertainty
D = [5 0;0 3];
[test3_utds,test3_metadata] = uncertain_tds_create('retarded',{[1]},[0],{},...
    [],{},[],{D},0,struct('delta_bar',1.5,'q',1,'r',1),cell(1,1),...
    cell(1,0),cell(1,0),{struct('l',1,'G',[0;1],'H',[0 1])});
options = struct('metadata',test3_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test3_utds,options);
assert(rob_strong_asympt_hinfnorm == 5,'Test 3-1 failed.');
D = [5 0;0 3];
[test3_utds,test3_metadata] = uncertain_tds_create('retarded',{[1]},[0],{},...
    [],{},[],{D},0,struct('delta_bar',2.5,'q',1,'r',1),cell(1,1),...
    cell(1,0),cell(1,0),{struct('l',1,'G',[0;1],'H',[0 1])});
options = struct('metadata',test3_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test3_utds,options);
assert(rob_strong_asympt_hinfnorm == 5.5,'Test 3-2 failed.');
%% TEST 4: uncertain_tds has only one direct feed through term with non-scalar uncertainty
D = [0];
[test4_utds,test4_metadata] = uncertain_tds_create('retarded',{[1]},[0],{},...
    [],{},[],{D},0,struct('delta_bar',1,'q',2,'r',1),cell(1,1),...
    cell(1,0),cell(1,0),{struct('l',1,'G',[1 1],'H',[1])});
options = struct('metadata',test4_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test4_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-sqrt(2))<1e-10,'Test 4 failed.');
%% TEST 5: uncertain_tds has only one direct feed through term with both scalar and non-scalar uncertainty
D = [5 0;0 3];
delta(1) = struct('delta_bar',1.5,'q',1,'r',1);
delta(2) = struct('delta_bar',1,'q',2,'r',1);
uD1(1) = struct('l',1,'G',[0;1],'H',[0 1]);
uD1(2) = struct('l',2,'G',[0 0;1 1],'H',[0 1]);
[test5_utds,test5_metadata] = uncertain_tds_create('retarded',{[1]},[0],{},...
    [],{},[],{D},0,delta,cell(1,1),cell(1,0),cell(1,0),{uD1});
options = struct('metadata',test5_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test5_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-(4.5+sqrt(2)))<1e-10,'Test 5 failed.');

%% TEST 6: uncertain_tds has multiple direct feed through terms without uncertainty
[test6_utds,test6_metadata] = uncertain_tds_create('retarded',{1},0,{},...
    [],{},[],{1,-2,3,4,-5},[0,1,2,3,4],struct('delta_bar',{},'q',{},'r',{}),cell(1,1),cell(1,0),cell(1,0),cell(1,5));
options = struct('metadata',test6_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test6_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-15)<1e-10,'Test 6 failed.');

%% TEST 7: uncertain_tds has multiple direct feed through terms with scalar uncertainties
delta(1) = struct('delta_bar',1,'q',1,'r',1);
delta(2) = struct('delta_bar',1,'q',1,'r',1);
delta(3) = struct('delta_bar',1,'q',1,'r',1);
delta(4) = struct('delta_bar',1,'q',1,'r',1);
delta(5) = struct('delta_bar',1,'q',1,'r',1);
delta(6) = struct('delta_bar',1,'q',1,'r',1);
uD1(1) = struct('l',1,'G',1,'H',1);
uD1(2) = struct('l',2,'G',1,'H',-1);
uD2(1) = struct('l',2,'G',1,'H',1);
uD3(1) = struct('l',1,'G',1,'H',1);
uD3(2) = struct('l',2,'G',1,'H',-1);
uD3(3) = struct('l',3,'G',1,'H',1);
uD5(1) = struct('l',4,'G',1,'H',1);
[test7_utds,test7_metadata] = uncertain_tds_create('retarded',{1},0,{},...
    [],{},[],{1,-2,3,4,-5},[0,1,2,3,4],delta,cell(1,1),cell(1,0),cell(1,0),{uD1,uD2,uD3,{},uD5});
options = struct('metadata',test7_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test7_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-22)<1e-10,'Test 7 failed.');
clear uD1 uD2 uD3 uD5
%% TEST 8: uncertain_tds has multiple direct feed through terms with non-scalar uncertainties
D0 = [5 0;0 3];
D1 = [0 0;0 0.5];
D2 = [-1 0;0 0];
delta(1) = struct('delta_bar',1,'q',2,'r',2);
delta(2) = struct('delta_bar',1,'q',2,'r',1);
uD1(1) = struct('l',1,'G',eye(2),'H',eye(2));
uD3(1) = struct('l',2,'G',[1 1;0 0],'H',[1 0]);
[test8_utds,test8_metadata] = uncertain_tds_create('retarded',{1},0,{},...
    [],{},[],{D0,D1,D2},[0,1,2],delta,cell(1,1),cell(1,0),cell(1,0),{uD1,{},uD3});
options = struct('metadata',test8_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test8_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-(7+sqrt(2)))<1e-10,'Test 8 failed.');
clear uD1 uD3
%% TEST 9: uncertain_tds has multiple direct feed throug terms and multiple uncertainties (both scalar and non-scalar)
D0 = [5 0;0 3];
D1 = [0 0;0 0.5];
D2 = [-1 0;0 0];
delta(1) = struct('delta_bar',1,'q',2,'r',2);
delta(2) = struct('delta_bar',1,'q',1,'r',1);
uD1(1) = struct('l',1,'G',eye(2),'H',eye(2));
uD3(1) = struct('l',2,'G',[1;0],'H',[1 0]);
[test9_utds,test9_metadata] = uncertain_tds_create('retarded',{1},0,{},...
    [],{},[],{D0,D1,D2},[0,1,2],delta,cell(1,1),cell(1,0),cell(1,0),{uD1,{},uD3});
options = struct('metadata',test9_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test9_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-8)<1e-10,'Test 9 failed.');
clear uD1 uD3
%% TEST 10: uncertain_tds has multiple uncertainties but only some appear in asymtotic transfer function
D0 = [5 0;0 3];
D1 = [0 0;0 0.5];
D2 = [-1 0;0 0];
delta(1) = struct('delta_bar',1,'q',2,'r',2);
delta(2) = struct('delta_bar',1,'q',1,'r',1);
delta(3) = struct('delta_bar',1,'q',1,'r',1);
delta(4) = struct('delta_bar',1,'q',1,'r',1);
uD1(1) = struct('l',1,'G',eye(2),'H',eye(2));
uD3(1) = struct('l',4,'G',[1;0],'H',[1 0]);
[test10_utds,test10_metadata] = uncertain_tds_create('retarded',{1},0,{},...
    [],{},[],{D0,D1,D2},[0,1,2],delta,cell(1,1),cell(1,0),cell(1,0),{uD1,{},uD3});
options = struct('metadata',test10_metadata);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test10_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-8)<1e-10,'Test 10 failed.');
%% TEST 11: first delay is non-zero

D0 = [5 0;0 3];
D1 = [0 0;0 0.5];
D2 = [-1 0;0 0];
delta(1) = struct('delta_bar',1,'q',2,'r',2);
delta(2) = struct('delta_bar',1,'q',1,'r',1);
delta(3) = struct('delta_bar',1,'q',1,'r',1);
delta(4) = struct('delta_bar',1,'q',1,'r',1);
uD1(1) = struct('l',1,'G',eye(2),'H',eye(2));
uD3(1) = struct('l',4,'G',[1;0],'H',[1 0]);
[test11_utds,test11_metadata] = uncertain_tds_create('retarded',{1},0,{},...
    [],{},[],{D0,D1,D2},[0.5,1,2],delta,cell(1,1),cell(1,0),cell(1,0),{uD1,{},uD3});
options = struct('metadata',test9_metadata);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(test9_utds,options);
assert(abs(rob_strong_asympt_hinfnorm-8)<1e-10,'Test 10 failed.');

clear variables
rmpath('../SRC')