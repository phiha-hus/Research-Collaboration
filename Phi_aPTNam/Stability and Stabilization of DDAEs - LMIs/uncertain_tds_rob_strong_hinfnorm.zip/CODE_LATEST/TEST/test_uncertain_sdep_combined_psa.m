clear
addpath('../SRC');
addpath('../SRC/TDS_EIGV');
%% TEST 1 : No real valued uncertainties + epsilon = 0
test1_Q = [1 0 0;zeros(2,3)];
test1_P = {rand(3,3),rand(3,3),rand(3,3)};
test1_hP = [0 0.4435 0.43534];
test1_epsilon = 0;
test1_hat_delta = {};
test1_uP = cell(1,3);
test1_R = [0;1;0];
test1_S = [0 0 1];
[test1_usdep,test1_meta] = uncertain_sdep_create(test1_Q,test1_P,test1_hP,test1_R,test1_S,test1_hat_delta,test1_uP,test1_epsilon);
uncertain_sdep_combined_psa(test1_usdep,struct('metadata_sdep',test1_meta))
%% TEST 2 : No real valued uncertainties + epsilon neq 0
test2_Q = [1 0 0;zeros(2,3)];
test2_P = {rand(3,3),rand(3,3),rand(3,3)};
test2_hP = [0 0.4435 0.43534];
test2_epsilon = 0.2;
test2_hat_delta = {};
test2_uP = cell(1,3);
test2_R = [0;1;0];
test2_S = [0 0 1];
[test2_usdep,test2_meta] = uncertain_sdep_create(test2_Q,test2_P,test2_hP,test2_R,test2_S,test2_hat_delta,test2_uP,test2_epsilon);
uncertain_sdep_combined_psa(test2_usdep,struct('metadata_sdep',test2_meta))
%% TEST 3: Real valued uncertainties (non-scalar) + epsilon = 0
test3_Q = [1 0 0;zeros(2,3)];
test3_P = {rand(3,3)-5*eye(3),rand(3,3),rand(3,3)};
test3_hP = [0 0.4435 0.43534];
test3_epsilon = 0.;
test3_hat_delta = struct('delta_bar',0.12,'q',3,'r',3);
test3_uP = cell(1,3);
test3_uP{1} = struct('l',1,'G',eye(3),'H',eye(3));
test3_uP{2} = struct('l',1,'G',-eye(3),'H',eye(3));
test3_uP{3} = struct('l',1,'G',-eye(3),'H',ones(3,3));
test3_R = [0;1;0];
test3_S = [0 0 1];
[test3_usdep,test3_meta] = uncertain_sdep_create(test3_Q,test3_P,test3_hP,test3_R,test3_S,test3_hat_delta,test3_uP,test3_epsilon);
uncertain_sdep_combined_psa(test3_usdep,struct('metadata_sdep',test3_meta,'print_level',2))
%% TEST 4: Real valued uncertainties (scalar + non-scalar) + epsilon neq 0
test4_Q = [1 0 0;zeros(2,3)];
test4_P = {rand(3,3)-eye(3)*7,rand(3,3),rand(3,3)};
test4_hP = [0 0.4435 0.43534];
test4_epsilon = 0.4;
test4_hat_delta(1) = struct('delta_bar',0.12,'q',3,'r',3);
test4_hat_delta(2) = struct('delta_bar',0.25,'q',1,'r',1);
test4_uP = cell(1,3);
test4_uP{1}(1) = struct('l',1,'G',eye(3),'H',eye(3));
test4_uP{1}(2) = struct('l',2,'G',[1;0;3],'H',[0 1 1]);
test4_uP{2} = struct('l',1,'G',-eye(3),'H',eye(3));
test4_uP{3}(1) = struct('l',1,'G',-eye(3),'H',ones(3,3));
test4_uP{3}(2) = struct('l',2,'G',[-1;0;0],'H',[4 0 0.5]);
test4_R = [0;1;0];
test4_S = [0 0 1];
[test4_usdep,test4_meta] = uncertain_sdep_create(test4_Q,test4_P,test4_hP,test4_R,test4_S,test4_hat_delta,test4_uP,test4_epsilon);
uncertain_sdep_combined_psa(test4_usdep,struct('metadata_sdep',test4_meta,'print_level',2))
%% TEST 5: Real valued uncertainties (more than 3 scalar uncertainties)
test5_Q = [1 0 0;zeros(2,3)];
test5_P = {rand(3,3),rand(3,3),rand(3,3)};
test5_hP = [0 0.5435 0.43534];
test5_epsilon = 0.4;
test5_hat_delta(1) = struct('delta_bar',0.12,'q',1,'r',1);
test5_hat_delta(2) = struct('delta_bar',0.25,'q',1,'r',1);
test5_hat_delta(3) = struct('delta_bar',0.125,'q',1,'r',1);
test5_hat_delta(4) = struct('delta_bar',0.005,'q',1,'r',1);
test5_uP = cell(1,3);
test5_uP{1}(1) = struct('l',1,'G',[1;0;0],'H',[1 0 0]);
test5_uP{1}(2) = struct('l',2,'G',[0;1;3],'H',[0 0 1]);
test5_uP{1}(2) = struct('l',1,'G',[1;3;0],'H',[0 1 1]);
test5_uP{1}(2) = struct('l',4,'G',[0;0;3],'H',[0 0 1]);
test5_uP{2} = struct('l',3,'G',[0;1;0],'H',[1 0 2]);
test5_uP{3}(1) = struct('l',1,'G',[0;2;0],'H',[0 0.1 1]);
test5_uP{3}(2) = struct('l',4,'G',[-1;0;1],'H',[4 0 0.5]);
test5_uP{3}(3) = struct('l',4,'G',[0;0;1],'H',[0 4 0.5]);
test5_uP{3}(4) = struct('l',1,'G',[-1;0;0],'H',[1 0 0]);
test5_uP{3}(5) = struct('l',2,'G',[-1;0;1],'H',[0 -0.5 0]);
test5_uP{3}(6) = struct('l',3,'G',[0;0;1],'H',[4 0.5 0]);
test5_R = [0;1;0];
test5_S = [0 0 1];
[test5_usdep,test5_meta] = uncertain_sdep_create(test5_Q,test5_P,test5_hP,test5_R,test5_S,test5_hat_delta,test5_uP,test5_epsilon);
uncertain_sdep_combined_psa(test5_usdep,struct('metadata_sdep',test5_meta,'print_level',1))
%% TEST 6: No delays
test6_Q = [1 0 0;zeros(2,3)];
test6_P = {rand(3,3)-5*eye(3)};
test6_hP = 0;
test6_epsilon = 0.4;
test6_hat_delta(1) = struct('delta_bar',0.12,'q',1,'r',1);
test6_uP{1}(1) = struct('l',1,'G',[1;0;0],'H',[1 0 0]);
test6_R = [0;1;0];
test6_S = [0 0 1];
[test6_usdep,test6_meta] = uncertain_sdep_create(test6_Q,test6_P,test6_hP,test6_R,test6_S,test6_hat_delta,test6_uP,test6_epsilon);
uncertain_sdep_combined_psa(test6_usdep,struct('metadata_sdep',test6_meta,'print_level',1))
%%
clear