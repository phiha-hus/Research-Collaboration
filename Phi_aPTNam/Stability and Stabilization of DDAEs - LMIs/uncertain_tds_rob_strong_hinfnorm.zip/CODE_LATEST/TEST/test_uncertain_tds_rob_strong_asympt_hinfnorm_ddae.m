clear
addpath('../SRC');
addpath('../SRC/TDS_EIGV')
%% TEST 1
% Retarded system transformed to DDAE system thus
% Ta(delta,theta) = D0(delta)+D1(delta)*exp(j theta1)+D2(delta)*exp(j theta2)
%                 = 1+delta3 - 5 *exp(j theta1) +(2+3delta3)*exp(j theta2)
% Correct answer 8.8 
test1_E = [1 0 0;0 0 0;0 0 0];
test1_A = {[1 2 0;0 -1 0;3 1 -1],[0 0 0;0 0 0;0 -5 0],[0 0 0;0 0 0;0 2 0]};
test1_hA = [0 1 2];
test1_uA = cell(1,3);
test1_uA{1}(1) = struct('l',1,'G',[1;0;0],'H',[1 0 0]);
test1_uA{1}(2) = struct('l',2,'G',[0;0;1],'H',[1 0 0]);
test1_uA{1}(3) = struct('l',3,'G',[0;0;1],'H',[0 1 0]);
test1_uA{3}(1) = struct('l',3,'G',[0;0;3],'H',[0 1 0]);
test1_B = {[0;1;0]};
test1_hB = 0;
test1_uB = cell(1,1);
test1_C = {[0 0 1]};
test1_hC = 0;
test1_uC = cell(1,1);
test1_D = {};
test1_hD = [];
test1_uD = cell(1,0);
test1_delta(1) = struct('delta_bar',0.4,'q',1,'r',1);
test1_delta(2) = struct('delta_bar',0.3,'q',1,'r',1);
test1_delta(3) = struct('delta_bar',0.2,'q',1,'r',1);
test1_left_null_E = [0 0;1 0;0 1];
test1_right_null_E = [0 0;1 0;0 1];
[test1_utds,test1_metadata] = uncertain_tds_create('ddae',test1_E,test1_A,...
    test1_hA,test1_B,test1_hB,test1_C,test1_hC,test1_D,test1_hD,test1_delta,...
    test1_uA,test1_uB,test1_uC,test1_uD);
[rob_strong_asympt_hinfnorm] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test1_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test1_left_null_E,'right_null_E',...
    test1_right_null_E,'metadata',test1_metadata));
assert(abs(rob_strong_asympt_hinfnorm-8.8)<1e-8,'TEST 1 failed');
%% TEST2
% Ta = -(4.3+delta_4)*(7+delta_2+(2+delta_3)*exp(-s))^{-1} (-5 + 2*exp(-s)) + 4.4 + (5+delta_4)*exp(-s)
test2_E = [1 0;0 0];
test2_A = {[-7 3;2 7] [-3 0;0 -6]};
test2_hA= [0 1];
test2_uA = cell(1,2);
test2_uA{1}(1) = struct('l',1,'G',[1;0],'H',[1 0]);
test2_uA{1}(2) = struct('l',2,'G',[0;1],'H',[0 1]);
test2_uA{2}(1) = struct('l',3,'G',[0;1],'H',[0 1]);
test2_uA{2}(2) = struct('l',1,'G',[0;1],'H',[0 1]);
test2_B = {[-2;5],[1;-2]};
test2_hB = [0 1];
test2_uB = cell(1,2);
test2_uB{1}(1) = struct('l',3,'G',[1;0],'H',[1]);
test2_C = {[2 4.3]};
test2_hC = [0];
test2_uC = cell(1,1);
test2_uC{1}(1) = struct('l',4,'G',[1],'H',[0 1]);
test2_D = {[4.4], [5]};
test2_hD = [0 1];
test2_uD = cell(1,2);
test2_uD{2}(1) = struct('l',4,'G',[1],'H',[1]);
test2_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test2_delta(2) = struct('delta_bar',0.2,'q',1,'r',1);
test2_delta(3) = struct('delta_bar',0.3,'q',1,'r',1);
test2_delta(4) = struct('delta_bar',0.2,'q',1,'r',1);
test2_left_null_E = [0;1];
test2_right_null_E = [0;1];
[test2_utds,test2_metadata] = uncertain_tds_create('ddae',test2_E,test2_A,...
    test2_hA,test2_B,test2_hB,test2_C,test2_hC,test2_D,test2_hD,test2_delta,...
    test2_uA,test2_uB,test2_uC,test2_uD);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test2_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test2_left_null_E,'right_null_E',...
    test2_right_null_E,'metadata',test2_metadata));
%% TEST 3: No active uncertainties
test3_E = [1 0;0 0];
test3_A = {[-7 3;2 7] [-3 0;0 -6]};
test3_hA= [0 1];
test3_uA = cell(1,2);
test3_uA{1}(1) = struct('l',1,'G',[1;0],'H',[1 0]);
test3_uA{1}(2) = struct('l',2,'G',[1;0],'H',[0 1]);
test3_uA{2}(1) = struct('l',3,'G',[0;1],'H',[1 0]);
test3_uA{2}(2) = struct('l',1,'G',[0;1],'H',[1 0]);
test3_B = {[-2;5],[1;-2]};
test3_hB = [0 1];
test3_uB = cell(1,2);
test3_uB{1}(1) = struct('l',3,'G',[1;0],'H',[1]);
test3_C = {[2 4.3]};
test3_hC = [0];
test3_uC = cell(1,1);
test3_uC{1}(1) = struct('l',4,'G',[1],'H',[1 0]);
test3_D = {[4.4], [5]};
test3_hD = [0 1];
test3_uD = cell(1,2);
test3_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test3_delta(2) = struct('delta_bar',0.2,'q',1,'r',1);
test3_delta(3) = struct('delta_bar',0.3,'q',1,'r',1);
test3_delta(4) = struct('delta_bar',0.2,'q',1,'r',1);
test3_left_null_E = [0;1];
test3_right_null_E = [0;1];
[test3_utds,test3_metadata] = uncertain_tds_create('ddae',test3_E,test3_A,...
    test3_hA,test3_B,test3_hB,test3_C,test3_hC,test3_D,test3_hD,test3_delta,...
    test3_uA,test3_uB,test3_uC,test3_uD);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test3_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test3_left_null_E,'right_null_E',...
    test3_right_null_E,'metadata',test3_metadata));
%% TEST 4: Ta = 0
test4_E = [1 0;0 0];
test4_A = {[-7 4;2 2] [-4 0;0 0]};
test4_hA= [0 1];
test4_uA = cell(1,2);
test4_uA{1}(1) = struct('l',1,'G',[1;0],'H',[1 0]);
test4_uA{1}(2) = struct('l',2,'G',[1;0],'H',[0 1]);
test4_uA{2}(1) = struct('l',4,'G',[0;1],'H',[1 0]);
test4_uA{2}(2) = struct('l',1,'G',[0;1],'H',[1 0]);
test4_B = {[-2;2],[1;3]};
test4_hB = [0 1];
test4_uB = cell(1,2);
test4_uB{1}(1) = struct('l',3,'G',[1;0],'H',[1]);
test4_C = {[2 0]};
test4_hC = [0];
test4_uC = cell(1,1);
test4_uC{1}(1) = struct('l',4,'G',[1],'H',[1 0]);
test4_D = {};
test4_hD = [];
test4_uD = cell(1,0);
test4_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test4_delta(2) = struct('delta_bar',0.2,'q',1,'r',1);
test4_delta(3) = struct('delta_bar',0.3,'q',1,'r',1);
test4_delta(4) = struct('delta_bar',0.2,'q',1,'r',1);
test4_left_null_E = [0;1];
test4_right_null_E = [0;1];
[test4_utds,test4_metadata] = uncertain_tds_create('ddae',test4_E,test4_A,...
    test4_hA,test4_B,test4_hB,test4_C,test4_hC,test4_D,test4_hD,test4_delta,...
    test4_uA,test4_uB,test4_uC,test4_uD);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test4_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test4_left_null_E,'right_null_E',...
    test4_right_null_E,'metadata',test4_metadata));
%% TEST 5: No delays in Ta with no uncertainties
test5_E = [1 0;0 0];
test5_A = {[-7 4;2 2] [-4 0;0 0]};
test5_hA= [0 1];
test5_uA = cell(1,2);
test5_uA{1}(1) = struct('l',1,'G',[1;0],'H',[1 0]);
test5_uA{1}(2) = struct('l',2,'G',[1;0],'H',[0 1]);
test5_uA{2}(1) = struct('l',4,'G',[0;1],'H',[1 0]);
test5_uA{2}(2) = struct('l',1,'G',[0;1],'H',[1 0]);
test5_B = {[-2;2],[1;0]};
test5_hB = [0 1];
test5_uB = cell(1,2);
test5_uB{1}(1) = struct('l',3,'G',[1;0],'H',[1]);
test5_C = {[2 3]};
test5_hC = [0];
test5_uC = cell(1,1);
test5_uC{1}(1) = struct('l',4,'G',[1],'H',[1 0]);
test5_D = {};
test5_hD = [];
test5_uD = cell(1,0);
test5_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test5_delta(2) = struct('delta_bar',0.2,'q',1,'r',1);
test5_delta(3) = struct('delta_bar',0.3,'q',1,'r',1);
test5_delta(4) = struct('delta_bar',0.2,'q',1,'r',1);
test5_left_null_E = [0;1];
test5_right_null_E = [0;1];
[test5_utds,test5_metadata] = uncertain_tds_create('ddae',test5_E,test5_A,...
    test5_hA,test5_B,test5_hB,test5_C,test5_hC,test5_D,test5_hD,test5_delta,...
    test5_uA,test5_uB,test5_uC,test5_uD);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test5_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test5_left_null_E,'right_null_E',...
    test5_right_null_E,'metadata',test5_metadata));
%% TEST 6: No delays in Ta with uncertainties
test6_E = [1 0;0 0];
test6_A = {[-7 4;2 2] [-4 0;0 0]};
test6_hA= [0 1];
test6_uA = cell(1,2);
test6_uA{1}(1) = struct('l',1,'G',[1;0],'H',[1 0]);
test6_uA{1}(2) = struct('l',2,'G',[1;0],'H',[0 1]);
test6_uA{2}(1) = struct('l',4,'G',[0;1],'H',[1 0]);
test6_uA{2}(2) = struct('l',1,'G',[0;1],'H',[1 1]);
test6_B = {[-2;2],[1;0]};
test6_hB = [0 1];
test6_uB = cell(1,2);
test6_uB{1}(1) = struct('l',3,'G',[1;0],'H',[1]);
test6_C = {[2 3]};
test6_hC = [0];
test6_uC = cell(1,1);
test6_uC{1}(1) = struct('l',4,'G',[1],'H',[1 0]);
test6_D = {};
test6_hD = [];
test6_uD = cell(1,0);
test6_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test6_delta(2) = struct('delta_bar',0.2,'q',1,'r',1);
test6_delta(3) = struct('delta_bar',0.3,'q',1,'r',1);
test6_delta(4) = struct('delta_bar',0.2,'q',1,'r',1);
test6_left_null_E = [0;1];
test6_right_null_E = [0;1];
[test6_utds,test6_metadata] = uncertain_tds_create('ddae',test6_E,test6_A,...
    test6_hA,test6_B,test6_hB,test6_C,test6_hC,test6_D,test6_hD,test6_delta,...
    test6_uA,test6_uB,test6_uC,test6_uD);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test6_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test6_left_null_E,'right_null_E',...
    test6_right_null_E,'metadata',test6_metadata));
%% TEST 7: first delay is non-zero
test7_E = [1 0;0 0];
test7_A = {[-7 4;2 2]};
test7_hA= 1.3;
test7_uA = cell(1,1);
test7_B = {[-2;2]};
test7_hB = 1;
test7_uB = cell(1,1);
test7_uB{1}(1) = struct('l',3,'G',[1;0],'H',[1]);
test7_C = {[2 3]};
test7_hC = 4;
test7_uC = cell(1,1);
test7_uC{1}(1) = struct('l',4,'G',[1],'H',[1 0]);
test7_D = {3};
test7_hD = 2;
test7_uD = cell(1,1);
test7_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test7_delta(2) = struct('delta_bar',0.2,'q',1,'r',1);
test7_delta(3) = struct('delta_bar',0.3,'q',1,'r',1);
test7_delta(4) = struct('delta_bar',0.2,'q',1,'r',1);
test7_left_null_E = [0;1];
test7_right_null_E = [0;1];
[test7_utds,test7_metadata] = uncertain_tds_create('ddae',test7_E,test7_A,...
    test7_hA,test7_B,test7_hB,test7_C,test7_hC,test7_D,test7_hD,test7_delta,...
    test7_uA,test7_uB,test7_uC,test7_uD);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test7_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test7_left_null_E,'right_null_E',...
    test7_right_null_E,'metadata',test7_metadata));
%% TEST 9: Ta = delta
test9_E = [1 0;0 0];
test9_A = {[-7 4;2 2] [-4 0;0 0]};
test9_hA= [0 1];
test9_uA = cell(1,2);
test9_uA{1}(1) = struct('l',1,'G',[1;0],'H',[1 0]);
test9_uA{1}(2) = struct('l',2,'G',[1;0],'H',[0 1]);
test9_uA{2}(1) = struct('l',4,'G',[0;1],'H',[1 0]);
test9_uA{2}(2) = struct('l',1,'G',[0;1],'H',[1 1]);
test9_B = {[-2;2],[1;3]};
test9_hB = [0 1];
test9_uB = cell(1,2);
test9_uB{1}(1) = struct('l',3,'G',[1;0],'H',[1]);
test9_C = {[2 0]};
test9_hC = [0];
test9_uC = cell(1,1);
test9_uC{1}(1) = struct('l',4,'G',[1],'H',[1 0]);
test9_D = {0};
test9_hD = [0];
test9_uD = cell(1,0);
test9_uD{1} = struct('l',4,'G',1,'H',1);
test9_delta(1) = struct('delta_bar',0.1,'q',1,'r',1);
test9_delta(2) = struct('delta_bar',0.2,'q',1,'r',1);
test9_delta(3) = struct('delta_bar',0.3,'q',1,'r',1);
test9_delta(4) = struct('delta_bar',0.2,'q',1,'r',1);
test9_left_null_E = [0;1];
test9_right_null_E = [0;1];
[test9_utds,test9_metadata] = uncertain_tds_create('ddae',test9_E,test9_A,...
    test9_hA,test9_B,test9_hB,test9_C,test9_hC,test9_D,test9_hD,test9_delta,...
    test9_uA,test9_uB,test9_uC,test9_uD);
[rob_strong_asympt_hinfnorm,crit_delta] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(test9_utds,struct('print_level',...
    2,'caution_level',0,'left_null_E',test9_left_null_E,'right_null_E',...
    test9_right_null_E,'metadata',test9_metadata));
%%
clear
