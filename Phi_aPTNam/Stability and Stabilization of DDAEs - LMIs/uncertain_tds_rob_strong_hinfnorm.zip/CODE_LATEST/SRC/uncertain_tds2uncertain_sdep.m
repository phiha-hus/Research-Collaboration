function [uncertain_sdep,metadata_sdep] = uncertain_tds2uncertain_sdep(uncertain_tds,metadata_tds)
%UNCERTAIN_TDS2UNCERTAIN_SDEP(local function) creates the corresponding
%uncertain_sdep and the associated metadata for uncertain_tds.
%

% Corresponding SDEP
% Q\lambda - P0(delta) - sum_{k=1}^K Pk(delta) exp(-lambda tau_k) -R Delta S
% with Q = [E 0 0; 0 0 0;0 0 0]
%      P0= [A0(delta) B0(delta) 0;0 -Im 0;C0(delta) D0(delta) -Ip]
%      Pk= [Ak(delta) Bk(delta) 0;0   0 0;Ck(delta) Dk(delta)   0]
%      R = [0;Im;0]
%      S = [0 0 Ip]
%  




if (nargin == 1)
    metadata_tds = uncertain_tds_metadata(uncertain_tds);
end

uncertain_sdep = {};
metadata_sdep = {};

% Dimensions of the extended matrices
metadata_sdep.n = metadata_tds.n + metadata_tds.m + metadata_tds.p;  
metadata_sdep.m = metadata_tds.m;
metadata_sdep.p = metadata_tds.p;

% Location of matrices of tds in extended matrices
iA = 1:metadata_tds.n;
iB = metadata_tds.n+(1:metadata_tds.m);
iC = metadata_tds.n+metadata_tds.m + (1:metadata_tds.p);
fields = {'A','B','C','D'};
locations = {{iA,iA},{iA,iB},{iC,iA},{iC,iB}};

% Construct Q matrix
if metadata_tds.ddae
    uncertain_sdep.Q = blkdiag(uncertain_tds.E,zeros(metadata_tds.m+metadata_tds.p));
else
    uncertain_sdep.Q = blkdiag(eye(metadata_tds.n),zeros(metadata_tds.m+metadata_tds.p));
end

% Construct Pk matrices and uPk struct arrays
uncertain_sdep.hP = unique(horzcat([0],uncertain_tds.hA,uncertain_tds.hB,uncertain_tds.hC,uncertain_tds.hD)); % delays matrix P 
metadata_sdep.KP = length(uncertain_sdep.hP);
uncertain_sdep.P = {};
uncertain_sdep.uP = {};
for k = 1:metadata_sdep.KP
    uncertain_sdep.P{k} = zeros(metadata_sdep.n,metadata_sdep.n);
    uncertain_sdep.uP{k} = struct('l',{},'G',{},'H',{});
end
uncertain_sdep.P{1}(metadata_tds.n+(1:metadata_tds.m + metadata_tds.p),metadata_tds.n+(1:metadata_tds.m + metadata_tds.p)) = ...
    -eye(metadata_tds.m + metadata_tds.p);
for iF=1:length(fields)
    field = fields{iF};
    matrices=uncertain_tds.(field);
    delays=uncertain_tds.(['h' field]);
    uncertainties = uncertain_tds.(['u' field]);
    ix = locations{iF}{1};
    iy = locations{iF}{2};
    
    for k=1:metadata_tds.(['K' field])
        idmat = find(uncertain_sdep.hP == delays(k));
        uncertain_sdep.P{idmat}(ix,iy)= uncertain_sdep.P{idmat}(ix,iy)+matrices{k};
        for id1 = 1:length(uncertainties{k})
            G = zeros(metadata_sdep.n,size(uncertainties{k}(id1).G,2));
            G(ix,:) = uncertainties{k}(id1).G;
            H = zeros(size(uncertainties{k}(id1).H,1),metadata_sdep.n);
            H(:,iy) = uncertainties{k}(id1).H;
            uncertain_sdep.uP{idmat}(end+1) = struct('l',uncertainties{k}(id1).l,'G',G,'H',H);
        end
    end
end

% Construct R matrix
uncertain_sdep.R = zeros(metadata_sdep.n,metadata_sdep.m);
uncertain_sdep.R(iB,:) = eye(metadata_sdep.m);

% Construct S matrix
uncertain_sdep.S = zeros(metadata_sdep.p,metadata_sdep.n);
uncertain_sdep.S(:,iC) = eye(metadata_sdep.p);

% Copy delta
uncertain_sdep.hat_delta = uncertain_tds.hat_delta;
metadata_sdep.L = metadata_tds.L;

% Set epsilon
uncertain_sdep.epsilon = 0;

end

