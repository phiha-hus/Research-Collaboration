function [asymptotic_tf,metadata] = uncertain_tds2asymptotic_tf(uncertain_tds,metadata_tds,left_null_E,right_null_E)
%UNCTAIN_DDAE2ASYMPTOTIC(local function) Generates asymptotic transfer
%function associated with uncertain_tds:
% Ta(delta,tau) = S2*(P0_22(delta) + sum_{k=1}^{K} Pk_22(delta) exp(-s tau_k))^{-1}R2
% with P0_22(delta) = [A0_22(delta) B0_2(delta) 0;0 -Im 0;C0_2(delta) D0(delta) -Ip]
%      Pk_22(delta) = [Ak_22(delta) Bk_2(delta) 0;0   0 0;Ck_2(delta) Dk(delta)   0]
%      R2 = [0_{n-rank(E) x m}; I_m; 0_{p x m}] 
%      S2 = [0_{p x n-rank(E)}  0_{p x m}  I_p]
% with Ak_22 = U^{H} Ak_22 V
%      Bk_2 = U^{H}B
%      Ck_2 = CV
% with U and V (n x n-rank(E)) dimensional matrices whose columns form a
% basis for respectively the left and right null space of E
%
% [asymptotic_tf,metadata] = uncertain_tds2asymptotic_tf(uncertain_tds)
% generates an object that represents the asymtotic transfer function
% associated with uncertain_tds. 
%
% optional arguments
%  metadata_tds - metdata associated with uncertain_tds
%  left_null_E  - basis for the left null space of E
%  right_null_E - basis for the right null space of E
%



% asymptotic_tf - A structure array with the following fields
%   P22   - (1 x K) cell with Pk_22 matrices [(n22 x n22) dimensional]
%   hP22  - (1 x K) vector with delay terms
%   uP22  - (1 x K) cell with sturct arrays that contain information on how uncertainties influence Pk_22;
%               Fields struct array
%                   l - position corresponding uncertainty in delta
%                   G - left shape matrix
%                   H - right shape matrix
%   hat_delta - (1 x L) struct array that contain information about uncertainties
%               Fields struct array
%                   delta_bar - Maximum Frobenius norm uncertainty
%                   q - row dimension uncertainty
%                   r - column dimension uncertainty
%   S2    - (n22 x m) dimensional S2 matrix 
%   R2    - (p x n22) dimensional R2 matrix
%
% metadata - A structure array with the following fields
%   n22 - (n-rank(E) + m + p) dimension Pk_22 matrices
%   m - column dimension Ta
%   p - row dimension Ta
%   KP22 - number of number of Pk_22 matrices
%   L - number of uncertainties
%   delta_used - (1 x L) vector with booleans indicating whether an
%       uncertainty is present in the asymptotic tranfer function
%       (useful to avoid unnecessary computations when computing the robust
%       strong asymptotic H-inifinity norm)

 

if nargin < 2
    metadata_tds = uncertain_tds_metadata(uncertain_tds);
end
if nargin < 4
    if metadata_tds.ddae
        left_null_E = null(uncertain_tds.E');
        right_null_E = null(uncertain_tds.E);
        assert(size(left_null_E,2) == size(right_null_E,2),'Dimension of left and right null space of E does not match');
    else
        left_null_E = []; right_null_E = [];
    end
end

asymptotic_tf = {};
metadata = {};

dim_null  = size(right_null_E,2); % dimension nullspace E
metadata.n22 = dim_null+metadata_tds.m+metadata_tds.p; % size Pk_22 matrices
metadata.m   = metadata_tds.m;
metadata.p   = metadata_tds.p;

non_zero = struct('A',struct('mat',{},'delay',{},'u',{}),...
    'B',struct('mat',{},'delay',{},'u',{}),'C',struct('mat',{},'delay',{},'u',{}),...
    'D',struct('mat',{},'delay',{},'u',{}));

iA = 1:dim_null; 
iB = dim_null+(1:metadata_tds.m);
iC = dim_null+metadata_tds.m + (1:metadata_tds.p);

fields = {'A','B','C'};
apply_left = [true;true;false];
apply_right = [true;false;true];

%For DDAE find non-zero Ak_22(delta), B_k_2(delta), Ck_2(delta)
if (dim_null~= 0)
    for i = 1:length(fields)
        for k = 1:metadata_tds.(['K' fields{i}])
            MAT = uncertain_tds.(fields{i}){k};
            if apply_left(i)
                MAT = left_null_E'*MAT;
            end
            if apply_right(i)
                MAT = MAT*right_null_E;
            end
            uncertainties = uncertain_tds.(['u' fields{i}]){k};
            non_zero_uncert = struct('l',{},'G',{},'H',{});
            for id1 = 1:length(uncertainties)
                uncertainty = uncertainties(id1);
                GMAT = uncertainty.G;
                if apply_left(i)
                    GMAT = left_null_E'*GMAT;
                end
                HMAT = uncertainty.H;
                if apply_right(i)
                    HMAT = HMAT*right_null_E;
                end
                if sigma1(GMAT) > 1e-13 && sigma1(HMAT) > 1e-13 
                    non_zero_uncert(end+1) = struct('l',uncertainty.l,'G',GMAT,'H',HMAT); 
                end
            end
            if sigma1(MAT)>1e-13 || ~isempty(non_zero_uncert)
                non_zero(1).(fields{i})(end+1) = struct('mat',MAT,'delay',...
                    uncertain_tds.(['h' fields{i}])(k),'u',non_zero_uncert);
            end
        end
    end
end

for kd = 1:metadata_tds.KD
    non_zero.D(kd) = struct('mat',uncertain_tds.D{kd},'delay',uncertain_tds.hD(kd),'u',uncertain_tds.uD{kd});
end

asymptotic_tf.hP22 = unique(horzcat(0, [non_zero.A.delay], [non_zero.B.delay], [non_zero.C.delay], [non_zero.D.delay]));
metadata.KP22 = length(asymptotic_tf.hP22);
asymptotic_tf.P22 = cell(1,metadata.KP22);

fields = {'A','B','C','D'};
iFields = {iA,iA;iA,iB;iC,iA;iC,iB};
% Construct P22 matrices
for k = 1:metadata.KP22
    asymptotic_tf.P22{k} = zeros(metadata.n22,metadata.n22);
    asymptotic_tf.uP22{k} = struct('l',{},'G',{},'H',{});
end
asymptotic_tf.P22{1}(dim_null+(1:metadata_tds.m+metadata_tds.p),dim_null+(1:metadata_tds.m+metadata_tds.p)) = ... 
    -eye(metadata_tds.m+metadata_tds.p);

for id0 = 1:length(fields)
    field = fields{id0};
    non_zero_field = non_zero.(field);
    ix = iFields{id0,1};
    iy = iFields{id0,2};
    for id1=1:length(non_zero_field)
        idmat = find(asymptotic_tf.hP22 == non_zero_field(id1).delay);
        asymptotic_tf.P22{idmat}(ix,iy) = asymptotic_tf.P22{idmat}(ix,iy) + non_zero_field(id1).mat;
        uncertainties = non_zero_field(id1).u;
        for id2=1:length(uncertainties)
            G = zeros(metadata.n22,size(uncertainties(id2).G,2)); 
            G(ix,:) = uncertainties(id2).G;
            H = zeros(size(uncertainties(id2).H,1),metadata.n22);
            H(:,iy) = uncertainties(id2).H;
            asymptotic_tf.uP22{idmat}(end+1) = struct('l',uncertainties(id2).l,'G',G,'H',H);
        end
    end
end
metadata.L = metadata_tds.L;
metadata.delta_used = false(1,metadata.L);
for l=1:metadata.L
    for k = 1:metadata.KP22
        res = find([asymptotic_tf.uP22{k}.l]==l, 1);
        if ~isempty(res)
            metadata.delta_used(l) = true;
            break;
        end
    end
end
asymptotic_tf.S2 = zeros(metadata.p,metadata.n22);
asymptotic_tf.R2 = zeros(metadata.n22,metadata.m);

asymptotic_tf.S2(:,iC) = eye(metadata.p);
asymptotic_tf.R2(iB,:) = eye(metadata.m);
asymptotic_tf.hat_delta = uncertain_tds.hat_delta;
end

function s1 = sigma1(A)
    if issparse(A)
        s1 = max(svds(A));
    else
        s1 = max(svd(A));
    end
end