function [psa,dpsa,crit_delta_n,crit_Delta,crit_lambda,crit_phi,crit_psi,hot_start_next,nb_ev_calc] = uncertain_sdep_combined_psa(uncertain_sdep,options)
%UNCERTAIN_SDEP_COMBINED_PSA(local function) computes the combined
%(hat{delta},epsilon)-pseudo spectral abscissa of an uncertain singular
%delay eigenvalue problem of the following form
% M(lambda;delta,Delta,tau) = Q lambda - P0(delta) - sum_{k=1}^K Pk(delta) 
%       exp(-lambda tau_k) -R Delta S
% with delta in hat{delta} and Delta in C^{m x p} & ||Delta||_2 <= epsilon
% using the projected gradient flow method.
%
% [psa] = uncertain_sdep_combined_psa(uncertain_sdep) returns the
% (hat{delta},epsilon)-pseudo-spectral abcissa of uncertain_sdep
%
% [psa,dpsa] = uncertain_sdep_combined_psa(uncertain_sdep) also returns the
% derivative of the psa with respect to epsilon
%
% [psa,dpsa,crit_delta,crit_Delta] =
% uncertain_sdep_combined_psa(uncertain_sdep) also returns the critical
% delta_n and Delta (crit_Delta is struct with fields u and v -> rank 1
% decomposition crit_Delta) 
%
% [psa,dpsa,crit_delta,crit_Delta,crit_lambda,crit_phi,crit_psi] =
% uncertain_sdep_combined_psa(uncertain_sdep) also returns the critical
% eigenvalue and its associated left (crit_phi) and right (crit_psi)
% eigenvectors
%
% [psa,dpsa,crit_delta,crit_Delta,crit_lambda,crit_phi,crit_psi,hot_start_next,nb_ev_calc]
%   = uncertain_sdep_combined_psa(uncertain_sdep) returns also
%   hot_start_next, which contains information to hot start method for next
%   epsilon and nb_ev_calc, the number of eigenvalue computations needed
%   by the algorithm
%
% [..] = uncertain_sdep_combined_psa(uncertain_sdep,options) allows to
% specify additional options 
%   options.print_level - 0 (quiet - default), 1 (result each initialisation), 2 (result each succesful step)
%   options.metadata_sdep - the metadata associated with uncertain_sdep (to avoid recomputation)
%   options.tol - Stop when relative or absolute change on lambda falls
%   below this threshold
%       #FUTURE Tolerance on 2-norm of the derivative of psa with respect to
%     the elements of delta and Delta (default - 1e-8)
%   options.early_stop - boolean function, returns as soon as the current
%     estimate for the psa is larger than 0 (useful in bisection method
%     where we are only interested in sign and not in the exact value of
%     the psa). 
%   options.caution_level - influences the number of initialisations
%      0 (small number of initialisations - default), 1, 2 (large number of initialisations)
%   options.hot_start - information to hot start method, a struct with the
%     following fields
%         u - m dimensional startvector for u
%         v - p dimensional startvector for v
%         delta - 1 x L dimensional cell with starting values for
%            delta_l^{n}




%HIGH LEVEL DESCRIPTION
% Compute alpha^{ps}(hat{delta},epsilon) by solving
% max_{delta in hat{delta}} max{Delta in C^{m x p} & ||Delta||_2 <= epsilon} 
%   Re(lambda_RM(M(lambda;delta,Delta,tau)))
% with hat{delta} = {delta in R^{q1 x r1} x ... x R^{qL x rL} : ||delta_l||_F <= bar{delta_l} };
% using gradient flow method with variables 
%     Delta(t) = epsilon u(t) v(t)^{H}
% and delta_l(t) = bar{delta_l} delta_l^n(t).
%
% Resulting path:
% We choose 
% delta_l^n'(t) = MAT_l(t) - <delta_l^n(t),MAT(t)>F delta_l^n(t) if ||delta^n_l||_F = 1 & <delta^{n}_l(t),MAT(t)>_F > 0
%               = MAT_l(t)                                       otherwise
% u'(t) = (epsilon/scal(t))*(j/2 Im((u(t)^H*transp(R)*phi(t))*(psi(t)^H*transp(S)*v(t)))u(t)+(I-u(t)u(t)^H)transp(R)*phi(t)*psi(t)^H*transp(S)*v(t))
% v'(t) = (epsilon/scal(t))*(j/2 Im((v(t)^H*S*psi(t))*(phi(t)'*R*u(t)))*v(t) + (I-v(t)*v(t)^H)*S*psi(t)*phi(t)^H*Ru(t))
%
% with MAT_l(t) = bar{delta_l}/scal(t) sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}
% (G_{l,s}^{Pk})^{T}*[Re(phi(t)) Im(phi(t))] * 
% [Re(exp(-lambda tau_k)) -Im(exp(-lambda tau_k));Im(exp(-lambda tau_k)) Re(exp(-lambda tau_k)) ] * 
% [Re(psi(t))^{T};Im(psi(t))^{T}] *(H_{l,s}^{Pk})^{T} and
% scal(t) = phi(t)^H(Q+sum_{k=1}^K tau_k Pk(delta) exp(-lambda(t) tau_k) psi(t);
% where phi(t) and psi(t) respectively the left and right eigenvectors of
% M(lambda;delta(t),Delta(t),tau) associated with the rightmost eigenvalue
% normalised such that scal(t) is real and strictly positive.
%
% Along this path Re(lambda_RM(t)) will monotonically increase as
% d Re(lambda_RM(t))/dt = Re(sum_{l=1}^L <delta_l^n'(t),MAT_l(t)>_F
% + (epsilon/scal)*Re(phi(t)^{H}Ru'(t)v(t)^{H}S psi(t)+phi(t)^{H}Ru(t)v'(t)^{H}S phi(t))
% 
%STEP 0: If no hot starting is used generate starting points for scalar delta
%        Else use hot start information to generate starting points
%ITERATE 1: iterate over these starting points
%|  STEP 1: Compute the (rightmost/dominant) eigenvalues and (associated eigenvectors) of
%|          M_init = M(lambda;delta^{init},Delta^{init},tau)
%|          #(FUTURE) HOW TO SELECT SUITABLE EIGENVALUES?
%|          #* Fast approximation of the Hinfty norm via optimization over spectral value sets - Guglielmi - 6.1 Multiplicity, controllability and observability
%|          #* A structured pseudo spectral method for Hinfty-norm computation of large-scale descriptor systems - Benner - 4.2 Choice eigenvalues
%|          #Balance nearness to being rightmost with large derivative (dominant.
%|          #Exponentially dominant pole (Benner) 
%|          
%|  ITERATE 2: iterate over selected eigenvalues
%|  |   STEP 2: initialise non-scalar delta_l^n, u and v.
%|  |           delta_l^{n,init} = sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}(G_{l,s}^{Pk})^{T}*[Re(phi_j) Im(phi_j)] * 
%|  |                    [Re(exp(-lambda_j tau_k)) -Im(exp(-lambda_j tau_k));Im(exp(-lambda_j tau_k)) Re(exp(-lambda_j tau_k)) ] * 
%|  |                    [Re(psi_j)^{T};Im(psi_j)^{T}] *(H_{l,s}^{Pk})^{T}
%|  |           u^{init} = R.'*phi_j/||R.'*phi_j||_2
%|  |           v^{init} = S psi_j/||S psi_j||_2
%|  |           with lambda_j the jth rightmost eigenvalue of M_init, and phi_j and psi_j its associated eigenvectors
%|  |   ITERATE 3: iterate until stopping criterium is fulfiled (or maximum number of iterations is reached)
%|  |   |   STEP 3: find h such that
%|  |   |           Re(lambda_RM(delta^{it+1},Delta^{it+1})) > Re(lambda_RM(delta^{it},Delta^{it}))
%|  |   |           with
%|  |   |           delta_l^n(it+1) = delta_l^n(it) + h_{it+1}*dot_delta_l(it)
%|  |   |           u(it+1) = normalise(exp(j*h_{it+1}*epsilon/scal*gamma(it)))u(it)+h_{it+1}*chi(j*h_{it+1}*epsilon/scal(t)*gamma(it))conj(beta(it))(R^{T}phi(it)-alpha(it)*u(it))
%|  |   |           v(it+1) = normalise(exp(-j*h_{it+1}*epsilon/scal*gamma(it)))u(it)+h_{it+1}*chi(-j*h_{it+1}*epsilon/scal(t)*gamma(it))conj(alpha(it))(S psi(it)-beta(it)*v(it))
%|  |   |           (Exponential forward Euler)
%|  |   |           OR
%|  |   |           u(it+1) = normalise(u(it) + h*epsilon/scal (j*gamma(it) *u(it) + conj(beta(it))*(R^{T} phi(it)-alpha(it) u(it)))
%|  |   |           v(it+1) = normailse(v(it) + h*epsilon/scal (-j *gamma(it) *v(it)+ conj(alpha(it))*(S psi(it)-beta(it) v(it)) )
%|  |   |           (Normal forward Euler) 
%|  |   |           with 
%|  |   |           alpha(it) = u(it)^{H} R^{T} phi(it)
%|  |   |           beta(it)  = v(it)^{H} S     psi(it)
%|  |   |           gamma(it) = 0.5*imag(alpha(it)*conj(beta(it))
%|  |   |           chi(z) = (exp(z)-1)/z


if(nargin == 1  || ~isstruct(options))
 options = struct(); 
end

[print_level,metadata_sdep,tol,early_stop,caution_level,hot_start] = parse_options(options,uncertain_sdep);
development_options = get_development_options();
L = metadata_sdep.L;
K = metadata_sdep.KP;

crit_delta_n = cell(1,metadata_sdep.L); % Stores critical delta
for l=1:metadata_sdep.L
    crit_delta_n{l} = zeros(uncertain_sdep.hat_delta(l).q,uncertain_sdep.hat_delta(l).r);
end
crit_Delta.u = zeros(metadata_sdep.m); % Stores critical Delta
crit_Delta.v = zeros(metadata_sdep.p);
nb_ev_calc = 0;
hot_start_next = {};
[crit_phi,crit_lambda,crit_psi,crit_scal] =  uncertain_sdep_calculate_eigenv(uncertain_sdep,metadata_sdep,crit_delta_n,crit_Delta.u,crit_Delta.u,1);
psa = real(crit_lambda);
if L == 0
    return
end
%% STEP 0: Generate starting points for scalar delta
 
 if (caution_level == 0)
    nb_eig_start = 3; % Number of right most eigenvalues to start from.
    scalar_cut_off = 3; % If there are less than scalar_cut_off scalar perturbations then generate complete. Otherwise sample grid using randi.
    nb_rand_scalar_points = 30; %Number of of sample points for randi.
 elseif(caution_level == 1)
    nb_eig_start = 6;
    scalar_cut_off = 4;
    nb_rand_scalar_points = 70;
 else
    nb_eig_start = max([rank(uncertain_sdep.E)*0.1,12]);
    scalar_cut_off = infty;
    nb_rand_scalar_points = 0;
 end
 
if (isempty(hot_start) )
    if development_options.scalar_initialisations
        q_list= [uncertain_sdep.hat_delta.q]; % List with row dimensions of uncertaities
        r_list= [uncertain_sdep.hat_delta.r]; % List with column dimensions of uncertainties
        [is_scalar,scalar_count,n_scalar] = check_scalar(q_list,r_list); % Check which perturbations are scalar
        if n_scalar <= scalar_cut_off
            scalar_initialisations = generate_scalar_uncertainties('grid',n_scalar,3);
        else
            scalar_initialisations = generate_scalar_uncertainties('randi',n_scalar,3,nb_rand_scalar_points);
        end
        
    else
        scalar_initialisations = zeros(1,0);
    end
    dimension_1_start_grid= size(scalar_initialisations,1);
else
    dimension_1_start_grid= length(hot_start);
end

 % Save the results of the different starting points
 lambda_save = -Inf*ones(dimension_1_start_grid,nb_eig_start);
 delta_save = cell(dimension_1_start_grid,nb_eig_start);
 u_save = cell(dimension_1_start_grid,nb_eig_start);
 v_save = cell(dimension_1_start_grid,nb_eig_start);
%% ITERATE 1: iterate over these starting points 
for scalar_iter = 1:dimension_1_start_grid
    %Initialise scalar uncertainties
    
    delta_init = cell(1,L);
    if isempty(hot_start)
        scalar_init = scalar_initialisations(scalar_iter,:);
        for l=1:L
            if development_options.scalar_initialisations && is_scalar(l)
                delta_init{l} = scalar_init(scalar_count(l));
            else
                delta_init{l} = zeros(uncertain_sdep.hat_delta(l).q,uncertain_sdep.hat_delta(l).r);
            end
        end
        Delta_u_init = zeros(metadata_sdep.m,1);
        Delta_v_init = zeros(metadata_sdep.p,1);
    else
        delta_init = hot_start(scalar_iter).delta;
        Delta_u_init = hot_start(scalar_iter).u;
        Delta_v_init = hot_start(scalar_iter).v;    
    end
    
%% STEP 1: Compute the (rightmost) eigenvalues and (associated eigenvectors) of M(lambda;delta^{init},Delta^{init},tau)
%(needed to initialise non-scalar uncertainties)
    options_eigenv = struct();
    [Phi0,Lambda0,Psi0,~] = uncertain_sdep_calculate_eigenv(uncertain_sdep,metadata_sdep,delta_init,Delta_u_init,Delta_v_init,nb_eig_start,options_eigenv);
    nb_ev_calc = nb_ev_calc + 1;
    nb_eig = length(Lambda0); % If calculate_eigenv returned less eigenvalues then expected.
%% ITERATE 2: Iterate over rightmost eigenvalues
    for eig_iter=1:nb_eig
%% STEP 2: initialise non-scalar delta_l^n, u and v.


% lambda0 is the (eig_iter)th rightmost eigenvalue of M_init, and phi0 and psi0 are its associated eigenvectors
        lambda0 = Lambda0(eig_iter);
        phi0 = Phi0(:,eig_iter);
        psi0 = Psi0(:,eig_iter);        
        
        delta = delta_init;
% Initialise non-scalar delta
% delta_l^{n,init} = sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}(G_{l,s}^{Pk})^{T}*[Re(phi_j) Im(phi_j)] * 
%                        [Re(exp(-lambda_j tau_k)) -Im(exp(-lambda_j tau_k));Im(exp(-lambda_j tau_k)) Re(exp(-lambda_j tau_k)) ] * 
%                        [Re(psi_j)^{T};Im(psi_j)^{T}*(H_{l,s}^{Pk})^{T}/||..||_F
        
        PHI = [real(phi0) imag(phi0)]; PSI = [real(psi0) imag(psi0)];
        Gamma = cell(1,K); % 1 \times K cell with \Gamma_k matrices
        for k=1:K
            term = exp(-uncertain_sdep.hP(k)*lambda0);
            Gamma{k} = [real(term) -imag(term);imag(term) real(term)];
        end
        
        for l=1:L
            if ~isempty(hot_start) || ~development_options.scalar_initialisations || ~is_scalar(l) 
                delta_l = zeros(uncertain_sdep.hat_delta(l).q,uncertain_sdep.hat_delta(l).r);
                for k=1:K
                    if ~isempty(uncertain_sdep.uP{k})
                        idx_l = find([uncertain_sdep.uP{k}.l] == l);
                        for s = idx_l
                            G = uncertain_sdep.uP{k}(s).G;
                            H = uncertain_sdep.uP{k}(s).H;
                            delta_l = delta_l + ((transp(G)*PHI)*Gamma{k}*transp(H*PSI));
                        end
                    end
                end
                norm_deltal = norm(delta_l,'fro');
                if (norm_deltal ~= 0)
                    delta{l} = delta_l/norm_deltal;
                end
            end
        end
        % Initialise u and v
        % u^{init} = R.'*phi0/||R.'*phi0||_2
        %v^{init} = S psi0/||S psi0||_2
        Delta_u = uncertain_sdep.R.'*phi0;        
        norm_Delta_u = norm(Delta_u);
        if (norm_Delta_u~=0)
            Delta_u = Delta_u/norm_Delta_u;
        end
        Delta_v = uncertain_sdep.S*psi0;
        norm_Delta_v = norm(Delta_v);
        if(norm_Delta_v~=0)
            Delta_v = Delta_v/norm_Delta_v;
        end
        
        % Prepare inner iterations
        step = development_options.step_init; lambda_prev = -Inf;
        iter = 1; % Iteration count
        eig_calc_inner = 0; % Count eigenvalue computations in inner iteration

        options_eigenv = struct();
        [phi,lambda,psi,scal] = uncertain_sdep_calculate_eigenv(uncertain_sdep,metadata_sdep,delta,Delta_u,Delta_v,1,options_eigenv);
        nb_ev_calc = nb_ev_calc + 1; eig_calc_inner = eig_calc_inner + 1;
        
        if (print_level >=2)
            fprintf('Scalar iteration %i/%i;  EV iteration %i/%i \n', ...
                scalar_iter,dimension_1_start_grid,eig_iter,nb_eig);
            fprintf('STEP %i: Re(lambda RM) = %12.6e\n',0,real(lambda))
        end
        delta_next = cell(1,metadata_sdep.L);
%% ITERATE 3: iterate until stopping criterium is fulfiled (or maximum number of iterations is reached)
        while(iter < development_options.max_iter) %

            [du,dv,alpha,beta,gamma] =  calculate_dot_Delta(Delta_u,Delta_v,phi,psi,uncertain_sdep.R,uncertain_sdep.S,uncertain_sdep.epsilon,scal);         
            dot_delta = calculate_dot_delta(uncertain_sdep,metadata_sdep,delta,phi,psi,scal,lambda); 
            
            if development_options.stop_criterium == 1
                STOP = stop_criterium(1,dot_delta,du,dv,tol);
            else
                STOP = stop_criterium(2,lambda,lambda_prev,tol);
            end
            
            if STOP
                if (print_level>=2)
                    fprintf('Stopping criterium fulfilled. \n');
                end
                break;
            end

            
%% STEP 3: find h such that
%       Re(lambda_RM(delta^{it+1},Delta^{it+1})) > Re(lambda_RM(delta^{it},Delta^{it}))
%       with
%       delta_l^n(it+1) = delta_l^n(it) + h_{it+1}*dot_delta_l(it)
%       u(it+1) = normalise(exp(j*h_{it+1}*epsilon/scal(it)*gamma(it)))u(it)+h_{it+1}*chi(j*h_{it+1}*epsilon/scal(it)*gamma(it))conj(beta(it))(R^{T}phi(it)-alpha(it)*u(it))
%       v(it+1) = normalise(exp(-j*h_{it+1}*epsilon/scal(it)*gamma(it)))u(it)+h_{it+1}*chi(-j*h_{it+1}*epsilon/scal(it)*gamma(it))conj(alpha(it))(S psi(it)-beta(it)*v(it))
%       (Exponential forward Euler)
%       OR
%       u(it+1) = normalise(u(it) + h*epsilon/scal*(j *gamma(it) *u(it) + conj(beta(it))*(R^{T} phi(it)-alpha(it) u(it))) 
%       v(it+1) = normalise(v(it) + h*epsilon/scal*(-j *gamma(it) *v(it) + conj(alpha(it))*(S psi(it)-beta(it) v(it))) 
%       (Normal forward Euler) 
            accepted = false;
            step_prev = step;
            while(~accepted && step>development_options.step_min)
                if (development_options.integration_method == 2)
                    u_next = Delta_u+step*du;
                    v_next = Delta_v+step*dv;
                else
                    u_next = exp( uncertain_sdep.epsilon/scal*gamma*1i*step)*Delta_u+step*chi(gamma*uncertain_sdep.epsilon/scal*1i*step)*conj(beta)*(uncertain_sdep.R'*phi-alpha*Delta_u);
                    v_next = exp(-uncertain_sdep.epsilon/scal*gamma*1i*step)*Delta_v+step*chi(-gamma*uncertain_sdep.epsilon/scal*1i*step)*conj(alpha)*(uncertain_sdep.S*psi-beta*Delta_v);
                end
                u_next = u_next/norm(u_next); v_next =v_next/norm(v_next);
                for l=1:L
                    delta_next{l} = delta{l}+step*dot_delta{l};
                    norm_delta = norm(delta_next{l},'fro');
                    if(norm_delta>1)
                        delta_next{l} = delta_next{l}/norm_delta;
                    end
                end

                options_eigenv = struct();
                options_eigenv.minimal_real_part = real(lambda)-0.1*max([1 abs(real(lambda))]);
                [phi_next,lambda_next,psi_next,scal_next] = uncertain_sdep_calculate_eigenv(uncertain_sdep,metadata_sdep,delta_next,u_next,v_next,1,options_eigenv);
                nb_ev_calc = nb_ev_calc + 1; eig_calc_inner = eig_calc_inner + 1;
                
                if(real(lambda_next)>real(lambda))
                    accepted = true;
                    if step==step_prev
                        if (~development_options.maximize_step_size) % Increase step size for NEXT iteration
                            step = step*development_options.step_increase;
                        else %Increase step size for THIS iteration until Re(lambda) no longer increases
                            stop_inner_iterate = false;
                            while ~stop_inner_iterate
                                step = step*development_options.step_increase;
                                delta_interm = cell(1,L);
                                for l=1:L % Apply update to deltas
                                    delta_interm{l} = delta{l}+step*dot_delta{l};
                                    norm_deltal = norm(delta_interm{l},'fro');
                                    if (norm_deltal > 1)
                                        delta_interm{l} = delta_interm{l}/norm_deltal;
                                    end
                                end
                                if (development_options.integration_method == 2)
                                    u_interm = Delta_u+step*du;
                                    v_interm = Delta_v+step*dv;
                                else
                                    u_interm = exp( uncertain_sdep.epsilon/scal*gamma*1i*step)*Delta_u+step*chi(uncertain_sdep.epsilon/scal*gamma*1i*step)*conj(beta)*(uncertain_sdep.R'*phi-alpha*Delta_u); 
                                    v_interm = exp(-uncertain_sdep.epsilon/scal*gamma*1i*step)*Delta_v+step*chi(-uncertain_sdep.epsilon/scal*gamma*1i*step)*conj(alpha)*(uncertain_sdep.S*psi-beta*Delta_v);
                                end
                                u_interm = u_interm/norm(u_interm); v_interm =v_interm/norm(v_interm);
                                options_eigenv = struct();
                                options_eigenv.minimal_real_part = real(lambda_next)-0.1*max([1 abs(real(lambda_next))]);
                                [phi_interm,lambda_interm,psi_interm,scal_interm] = uncertain_sdep_calculate_eigenv(uncertain_sdep,metadata_sdep,delta_interm,u_interm,v_interm,1,options_eigenv);
                                nb_ev_calc = nb_ev_calc + 1; eig_calc_inner = eig_calc_inner + 1;
                                if (real(lambda_interm) > real(lambda_next))
                                    lambda_next = lambda_interm;
                                    phi_next = phi_interm;
                                    psi_next = psi_interm;
                                    delta_next = delta_interm;
                                    u_next = u_interm;
                                    v_next = v_interm;
                                    scal_next = scal_interm;
                                else
                                    stop_inner_iterate = true;
                                end
                            end
                        end
                    end
                    phi = phi_next; psi = psi_next;
                    Delta_u = u_next; scal = scal_next; Delta_v = v_next;
                    delta = delta_next;
                    lambda_prev = lambda;
                    lambda = lambda_next;
                    if print_level >= 2
                         fprintf('STEP %i: Re(lambda RM) = %12.6e - step size = %12.6e \n',iter,real(lambda),step)
                    end
                else
                    step = step/development_options.step_reduction;
                end
            end
            if(~accepted) % minimal step size reached
                if print_level >= 2
                    fprintf('Step size too small. \n')
                end
                break;
            end
            if(early_stop && real(lambda)>0) % Early stopping
                if print_level >= 2
                    fprintf('Early stopping. \n')
                end
                psa = real(lambda);
                dpsa = nan;
                crit_Delta.u = u; crit_Delta.v = v;
                crit_delta_n = delta;
                crit_lambda = lambda;
                crit_phi = phi; 
                crit_psi = psi;
                hot_start_next = struct('delta',delta,'u',u,'v',v);
                return;
            end
            iter = iter+ 1;
        end
        lambda_save(scalar_iter,eig_iter) = lambda;
        delta_save{scalar_iter,eig_iter} = delta;
        u_save{scalar_iter,eig_iter} = Delta_u;
        v_save{scalar_iter,eig_iter} = Delta_v;
        if real(lambda)>psa
            psa = real(lambda);
            crit_delta_n = delta;
            crit_Delta.u = Delta_u; crit_Delta.v = Delta_v;
            crit_lambda = lambda;
            crit_phi = phi;
            crit_psi = psi;
            crit_scal = scal;
        end

        if(iter == development_options.max_iter) % maximum number of steps reached
            if (print_level >=2)
                fprintf('Maximum number of iterations reached \n')
            end
        end
        if (print_level ==1)
            fprintf('Scalar iteration %i/%i; EV iteration %i/%i : Re(lambda1) = %12.3e - eig calls = %i \n', ...
                scalar_iter,dimension_1_start_grid,eig_iter,nb_eig,real(lambda),eig_calc_inner);
        end
    end
end


%% STEP 4: Compute dpsa/dalpha =  (phi'*R*u*v'*S*psi)/(scal)
 dpsa = real((crit_phi'*uncertain_sdep.R*crit_Delta.u)*(crit_Delta.v'*uncertain_sdep.S*crit_psi))/crit_scal;
 hot_start_next = struct('delta',{},'u',{},'v',{});
 for i = 1:dimension_1_start_grid
     [~,ind_max] = max(real(lambda_save(i,:)));
     hot_start_next(i) = struct('delta',delta_save(i,ind_max),...
         'u',u_save{i,ind_max},'v',v_save{i,ind_max});
 end
end
function [STOP] = stop_criterium(varargin)
   if(varargin{1} == 1) 
       %stop_criterium(1,dot_delta,dot_u,dot_v
       % ||PGRAD_{delta,theta} sigma 1||_2) < tol
       %PGRAD projection of gradient on search space
       %PGRAD_{delta,theta} = (VEC(P_deltan_1(dsigma1/ddeltan_1)),..,VEC(P_deltan_1(dsigma1/ddeltan_L)),P_u(dsigma1/du),P_v(dsigma1/dv))
       % with dsigma1/ddeltan_l = (delta_bar_l/scal)*sum_k=0^K sum_s=1^{S_l^Pk} G_ls^{Pk}'PHI*GAMMA_k*PSI'*H_ls^{Pk}
       % where PHI = [real(phi) imag(phi)]; PSI = [real(psi) imag(psi)]; gamma_k = exp(-lambda tau_k) 
       % GAMMA_k = [real(gamma_k) -imag(gamma_k);imag(gamma_k) real(gamma_k)]
       % P_deltan_l(M) = M-<deltan_l,M>F deltan_l if ||deltan_l||_F >= 1 & <deltan_l,M> >0 
       %               = M otherwise
       % dsigma1
       dot_delta = varargin{2};
       dot_u = varargin{3}; dot_v = varargin{4};
       tol = varargin{5};
       grad = [dot_u;dot_v];
       for l=1:length(dot_delta)
           grad = [grad; reshape(dot_delta{l},[],1)];
       end
       STOP = norm(grad,'fro')<tol;
   else 
       %stop_criterium(2,lambda,lambda_prev,tol)
       % |lambda - lambda_prev| < tol*max([1,abs(lambda)])
       lambda = varargin{2}; lambda_prev = varargin{3}; tol = varargin{4};
       STOP = abs(lambda-lambda_prev)<(tol*max([1, abs(lambda)])) ;
   end
end
function [res] = chi(z)
%chi(z) = (exp(z)-1)/z;
    if (abs(z) < 1e-5) % Close to zero large cancellation error. Use Taylor approximation
        res = 1+z/2+z^2/6+z^3/24;
    else
        res = (exp(z)-1)/z;
    end
end
function [development_options] = get_development_options() 
    development_options.stop_criterium = 2;
    development_options.step_min = 1e-8; 
    development_options.step_init = 1; 
    development_options.step_reduction = 3;
    development_options.step_increase = 2;
    development_options.integration_method = 1;
    development_options.scalar_initialisations = true;
    development_options.maximize_step_size = false;
    % max_iter: maximum number of iterations for each starting point
    development_options.max_iter = 400;
    
    % Dominant pole
    % 0 Use right-most poles
    % 1 Use dominant poles in initialisation
    % 2 Use dominant poles in every step
    development_options.dominant_pole = 0;
    % Dominant pole method
    % 1 - Exponential dominant ||S phi|| * ||R^{T} psi|| * exp(beta*Re(lambda))
    % 2 - First order approximation Re(lambda)+ h* dRe(lambda)/dt
    development_options.dominant_pole_method = 0;
end
function [print_level,metadata_sdep,tol,early_stop,caution_level,hot_start] = parse_options(options,uncertain_sdep)
    if (isfield(options,'print_level'))
        print_level = options.print_level;
    else
        print_level = 0;
    end
    if isfield(options,'metadata')
        metadata_sdep = options.metadata;
    else
        metadata_sdep = uncertain_sdep_metadata(uncertain_sdep);
    end
    if (isfield(options,'tol'))
        tol = options.tol;
    else     
        tol = 1e-8;
    end
    if (isfield(options,'early_stop')) % stop as soon alpha > 0
        early_stop = options.early_stop;
    else
       early_stop = false;
    end
    if (isfield(options,'caution_level'))
        caution_level = options.caution_level;
    else
        caution_level = 0;
    end
    if isfield(options,'hot_start')
        hot_start = options.hot_start;
    else
        hot_start = {};
    end
end
function [dot_delta] = calculate_dot_delta(uncertain_sdep,metadata_sdep,delta,phi,psi,scal,lambda)
% delta_l^n'(t) = MAT_l(t) - <delta_l^n(t),MAT(t)>F delta_l^n(t) if ||delta^n_l||_F = 1 & <delta^{n}_l(t),MAT(t)>F > 0
%               = MAT_l(t)                                       otherwise
%
% MAT_l(t) = bar{delta_l}/scal(t) sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}
% transp(G_{l,s}^{Pk})*[Re(phi(t)) Im(phi(t))] * 
% [Re(exp(-lambda tau_k)) -Im(exp(-lambda tau_k));Im(exp(-lambda tau_k)) Re(exp(-lambda tau_k)) ] * 
% [transp(Re(psi(t)));transp(Im(psi(t)))] *transp(H_{l,s}^{Pk}
% scal(t) = phi(t)^H(Q+sum_{k=1}^K tau_k Pk(delta) exp(-lambda(t) tau_k) psi(t);
    PHI = [real(phi) imag(phi)]; PSI = [real(psi) imag(psi)];
    Gamma = cell(1,metadata_sdep.KP);
    for k=1:metadata_sdep.KP % If uncertainty on delays modify this part (UNCERTAINTY DELAY)
        tauk = uncertain_sdep.hP(k);
        term = exp(-tauk*lambda);
        Gamma{k} = [real(term) -imag(term);imag(term) real(term)];
    end
    dot_delta = cell(1,metadata_sdep.L);
    for l=1:metadata_sdep.L
        dot_delta{l} = zeros(uncertain_sdep.hat_delta(l).q,uncertain_sdep.hat_delta(l).r);
    end
    for k = 1: metadata_sdep.KP
        for id1 = 1:length(uncertain_sdep.uP{k})
            l = uncertain_sdep.uP{k}(id1).l;
            G = uncertain_sdep.uP{k}(id1).G;
            H = uncertain_sdep.uP{k}(id1).H;
            dot_delta{l} = dot_delta{l} + (G'*PHI)*Gamma{k}*(H*PSI)';        
        end
    end
    for l=1:metadata_sdep.L
        dot_delta{l} = uncertain_sdep.hat_delta(l).delta_bar/scal* dot_delta{l};
        inner_dotdelta_delta = sum(sum(dot_delta{l}.*delta{l}));
        if (norm(delta{l},'fro')>1-1e-8 && real(inner_dotdelta_delta)>0)
            dot_delta{l} = (dot_delta{l} - inner_dotdelta_delta*delta{l});
        end
    end
end
function [dot_u,dot_v,alpha,beta,gamma] = calculate_dot_Delta(u,v,phi,psi,R,S,epsilon,scal)
%CALCULATE_DOT_DELTA Computes du(t)/dt and dv(t)/dt (differential equations
%that describe the path for u and v)
% u'(t) = epsilon/scal*(j/2 Im((u(t)^{H}R^{T} phi(t))*(psi(t)^{H}S^{T}*v(t))u(t) + psi(t)^{H}S^{T} v(t) (I-u(t)u(t)^{H})R^{T} phi(t)) ;
% v'(t) = epsilon/scal*(j/2 Im((v(t)^{H}S phi(t))*(phi(t)^{H}R*u(t))v(t)+ (phi(T)^{H} R u(t) (I-v(t)v(t)^{H}) S psi(t));
% By introducing helper variables: 
%       alpha(t) = u(t)^{H}R^{T} phi(t)
%       beta(t)  = v(t)^{H}S psi(t)
%       gamma(t) = Im(alpha(t)*conj(beta(t)))
% u'(t) = epsilon/scal*(j gamma(t) u(t) + conj(beta) (R^{T} phi(t) - alpha u(t)))
% v'(t) = epsilon/scal*(-j gamma(t) v(t) + conj(alpha)(S psi(t) - beta v(t)))
    alpha = u'*transp(R)*phi;
    beta  = v'*S*psi;
    gamma = 0.5*imag(alpha*conj(beta));
    dot_u = (1i*gamma)*u + conj(beta)*(transp(R)*phi-alpha*u);
    dot_v =-(1i*gamma)*v + conj(alpha)*(S*psi-beta*v);
    dot_u = dot_u*epsilon/scal; dot_v = dot_v*epsilon/scal;
end

