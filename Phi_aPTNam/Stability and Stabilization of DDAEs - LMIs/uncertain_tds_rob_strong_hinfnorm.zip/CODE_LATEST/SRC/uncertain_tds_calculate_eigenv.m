function [Phi,Lambda,Psi,Scal] = uncertain_tds_calculate_eigenv(uncertain_tds,metadata_tds,delta,nb_eig,options)
%UNCERTAIN_TDS_CALCULATE_EIGENV Computes the nb_eig right-most characteristic roots and
%corresponding left and right eigenvectors for certain realisation of
%uncertain_tds.
%
% [Phi,Lambda,Psi,Scal] = 
% uncertain_tds_calculate_eigenv(uncertain_tds,metadata_tds,delta,nb_eig)
% computes the nb_eig right-most characteristic roots of 
% uncertain_tds.E lambda - sum_{k=1}^{metadata_tds.KA} (uncertain_tds.A{k}
% + sum_{s=1}^{length(uncertain_tds.uA{k}} uncertain_tds.uA{k}(s).G
% uncertain_tds.hat_delta(uncertain_tds.uA{k}(s).l) delta(uncertain_tds.uA{k}(s).l) 
% uncertain_tds.uA{k}(s).H) exp(-lambda uncertain_tds.hA(k))
% and its associated left (Phi) and right (Psi) eigenvalues. (Scal is a
% normalisation constant used in uncertain_tds_psa.m)
%
%[Phi,Lambda,Psi,Scal] = uncertain_tds_calculate_eigenv(...,options)
% allows to specify additional options:
%   options.minimal_real_part - search for characteristic roots to the right
%            of minimal_real_part (lower bound on real part characteristic
%            roots)

% PLANNED MODIFICATIONS:
%   - use other methods to select dominant poles instead of just right-most
%   - allow uncertainties on the delays
if nargin == 4
    options = struct();
end
[minimal_real_part] = parse_options(options);


hA = uncertain_tds.hA;
% Apply the uncertainties to the A matrices
Atilde = uncertain_tds.A;
for k = 1:metadata_tds.KA
    for id1 = 1:length(uncertain_tds.uA{k})
        G = uncertain_tds.uA{k}(id1).G;
        H = uncertain_tds.uA{k}(id1).H;
        l = uncertain_tds.uA{k}(id1).l;
        delta_bar = uncertain_tds.hat_delta(l).delta_bar;
    	Atilde{k} = Atilde{k}+delta_bar*G*delta{l}*H;
    end
end

% Get tds object and E matrix
if metadata_tds.ddae
    tds = tds_create({uncertain_tds.E},[0],Atilde,hA,'neutral');
    E = uncertain_tds.E;
else
    tds = tds_create(Atilde,hA);
    E = eye(metadata_tds.n);
end
tds.hD = [];
eigenvalues = compute_roots_DDAE(tds,get_roots_DDAE_options(minimal_real_part));
lambda=eigenvalues.l1;
% Remove infinite eigenvalues
lambda(isinf(lambda)) = []; 
% Sort eigenvalues for decreasing real part
[~,I]=sort(real(lambda),'descend'); 
Lambda = lambda(I);

% Remove complex conjugate eigenvalue pairs 
id = 1;
while id < length(Lambda)
    elem = Lambda(id);
    if abs(imag(elem))>1e-9
        Lambda(abs(Lambda-conj(elem))<1e-10) = [];
    end
    id = id+1;
end

% If to few eigenvalues are found, decrease lower bound on real part
% characteristic roots
count = 0;
while length(Lambda)<nb_eig && count <10
    minimal_real_part = minimal_real_part - 2;
    eigenvalues = compute_roots_DDAE(tds,get_roots_DDAE_options(minimal_real_part));
    lambda=eigenvalues.l1; lambda(isinf(lambda)) = [];
    [~,I]=sort(real(lambda),'descend');
    Lambda = lambda(I);
    % Remove complex conjugate eigenvalue pairs 
    id = 1;
    while id < length(Lambda)
        elem = Lambda(id);
        if abs(imag(elem))>1e-9
            Lambda(abs(Lambda-conj(elem))<1e-10) = [];
        end
        id = id+1;
    end
    count = count + 1;
end

if (length(Lambda)<nb_eig)
    warning('Found fewer eigenvalues as desired');
else
    Lambda = Lambda(1:nb_eig);
end
[Phi,Psi,Scal] = compute_eigenvectors_DDAE(E,Atilde,hA,Lambda);


end
function [minimal_real_part] = parse_options(options)
    if isfield(options,'minimal_real_part')
        minimal_real_part = options.minimal_real_part;
    else
        minimal_real_part = -1;
    end
end
function [options] = get_roots_DDAE_options(minimal_real_part)
    options.minimal_real_part=minimal_real_part;  % all roots with real part larger than this value are desired  
    options.max_size_eigenvalue_problem=1000;
    % results in a possible restriction of the number of discretization
    % points for characteristic roots computations
    options.newton_max_iterations=50;
    % maximum number of Newton iterations to correct characteristic roots
    options.root_accuracy=1e-10;
    % stop criterion for Newton's method: norm on residual 
    options.commensurate_basic_delay=[];
    % value of the basic delay h in case of commensurate delay (optional); 
    % may lead to a speedup if  basic delay if ratio tau_max/h is small
    %
    options.fixN=0;
end

function [Phi,Psi,Scal] = compute_eigenvectors_DDAE(E,Atilde,hA,Lambda)
     % (local function) computes left and right eigenvectors associated with
    % the eigenvalues in Lambda.
    % (Scal(i) is equal to Phi(:,i)'*(E+sum_{k}
    % hA(k)*Atilde{k}*exp(-Lambda(i)*hA(k)))*Psi(:,i). Normalisation
    % coefficient)
    n = size(E,1);
    Phi = zeros(n,length(Lambda)); Psi = zeros(n,length(Lambda));
    Scal = zeros(1,length(Lambda));
    for j = 1:length(Lambda)
        lambda = Lambda(j);
        CM = -lambda*E;
        for k=1:length(Atilde)
           CM = CM+Atilde{k} *exp(-lambda*hA(k));
        end
        [Phiw,Sigmaw,Psiw] = svd(CM); 
        if (Sigmaw(end) > 1e-5)
           warning('Obtained eigenvalue may be inprecise.'); 
        end
        phi = Phiw(:,end); psi = Psiw(:,end); % Singular vectors associ
        phi = phi*exp(-1i*angle(phi(1))); % Normalisation 
        
        % Normalise phi and psi such that 
        % phi^{H}*(E+sum_{k} hA(k)*Atilde{k}*exp(-Lambda(i)*hA(k)))*psi is
        % real and positive; 
        xiM = E; 
        for k = 1:length(Atilde)
           xiM = xiM + hA(k)*Atilde{k}*exp(-lambda*hA(k));
        end
        denominator = phi'*xiM*psi;
        psi = psi*exp(-1i*angle(denominator));
        Phi(:,j) = phi;Psi(:,j) = psi;
        Scal(j) = real(phi'*xiM*psi);
    end
end
