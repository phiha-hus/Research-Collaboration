function [is_scalar,scalar_idx,nscalar] = check_scalar(q_list,r_list,used)
%CHECK_SCALAR (local function) checks which (active) uncertainties are scalar

% INPUT:
%   q_list : (1 x L) vector with row dimensions of the uncertainties
%   r_list : (1 x L) vector with column dimensions of the uncertainties
%   used   : (1 x L) vector indicating whether uncertainty is used
% OUTPUT:
%   is_scalar : 1 times L logical array indicating whether delta_l is scalar
%   scalar_count : 1 times L array with order number of the scalar uncertainties
%   final_count : number of scalar uncertainties

if nargin == 2
    used = true(1,length(q_list));
end
is_scalar = q_list == 1 & r_list == 1 & used;
scalar_idx = cumsum(is_scalar);
nscalar = scalar_idx(end);
scalar_idx(~is_scalar) = 0;
end

