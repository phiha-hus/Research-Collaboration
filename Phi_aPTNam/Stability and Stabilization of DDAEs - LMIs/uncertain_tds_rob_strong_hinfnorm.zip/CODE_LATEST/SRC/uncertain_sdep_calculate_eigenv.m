function [Phi,Lambda,Psi,Scal] = uncertain_sdep_calculate_eigenv(uncertain_sdep,metadata_sdep,delta_n,u,v,nb_eig,options)
%UNCERTAIN_SDEP_CALCULATE_EIGENV(local function) computes the right-most characteristic roots and
%corresponding left and right eigenvectors for a certain realisation of
%uncertain_sdep.
%
%[Phi,Lambda,Psi,Scal] =
%uncertain_sdep_calculate_eigenv(uncertain_sdep,metadata_sdep,delta_n,epsilon,u,v,nb_eig)
% computes the nb_eig right-most characteristic roots of 
%   uncertain_sdep.Q lambda - sum_{k=1}^{metadata_sdep.KP}
%   (uncertain_sdep.P{k}+ sum_{s=1}^{length(uncertain_sdep.uP{k})}
%   uncertain_sdep.uP{k}(s).G*uncertain_sdep.hat_delta(uncertain_sdep.uP{k}(s).l).delta_bar * 
%   delta_n(uncertain_sdep.uP{k}(s).l)*uncertain_sdep.uP{k}(s).H)
%   -R *uncertain_sdep.epsilon u v^{H} S  and its associated left (Phi) and
%   right (Psi) eigenvalues. (Scal is a normalisation constant used in
%   uncertain_sdep_combined_psa.m)
%
%[Phi,Lambda,Psi,Scal] = uncertain_sdep_calculate_eigenv(...,options)
% allows to specify additional options:
%   options.minimal_real_part - search for characteristic roots to the right
%            of minimal_real_part (lower bound on real part characteristic
%            roots)


% PLANNED MODIFICATIONS:
%   - use other methods to select dominant poles instead of just right-most
%   - allow uncertainties on the delays
if nargin == 6
    options = struct();
end
[minimal_real_part] = parse_options(options);

Q = uncertain_sdep.Q;


hP = uncertain_sdep.hP;
% Apply the uncertainties to the P matrices
P = uncertain_sdep.P;
for k = 1:metadata_sdep.KP
    for s = 1:length(uncertain_sdep.uP{k})
        G = uncertain_sdep.uP{k}(s).G;
        H = uncertain_sdep.uP{k}(s).H;
        l = uncertain_sdep.uP{k}(s).l;
        delta_bar = uncertain_sdep.hat_delta(l).delta_bar;
    	P{k} = P{k}+delta_bar*G*delta_n{l}*H;
    end
end
P{1} = P{1}+uncertain_sdep.epsilon*(uncertain_sdep.R*u)*(v'*uncertain_sdep.S);

% Compute eigenvalues
tds = tds_create({Q},[0],P,hP,{},[],{},[],{},[],{},[],{},[],{},[],{},[],{},[],'neutral');
tds.hD = [];
eigenvalues = compute_roots_DDAE(tds,get_roots_DDAE_options(minimal_real_part));
lambda=eigenvalues.l1; 
% Remove infinite eigenvalues
lambda(isinf(lambda)) = [];
% Sort eigenvalues for decreasing real part
[~,I]=sort(real(lambda),'descend');
Lambda = lambda(I);

% Remove complex conjugate eigenvalue pairs 
id = 1;
while id < length(Lambda)
    elem = Lambda(id);
    if abs(imag(elem))>1e-9
        Lambda(abs(Lambda-conj(elem))<1e-10) = [];
    end
    id = id+1;
end

% If to few eigenvalues are found, decrease lower bound on real part
% characteristic roots
count = 0;
while length(Lambda)<nb_eig && count <10
    minimal_real_part = minimal_real_part - 2;
    eigenvalues = compute_roots_DDAE(tds,get_roots_DDAE_options(minimal_real_part));
    lambda=eigenvalues.l1; lambda(isinf(lambda)) = [];
    [~,I]=sort(real(lambda),'descend');
    Lambda = lambda(I);
    % Remove complex conjugate eigenvalue pairs 
    id = 1;
    while id < length(Lambda)
        elem = Lambda(id);
        if abs(imag(elem))>1e-9
            Lambda(abs(Lambda-conj(elem))<1e-10) = [];
        end
        id = id+1;
    end
    count = count + 1;
end


if (length(Lambda)<nb_eig)
    warning('Found fewer eigenvalues as desired');  
else
    Lambda = Lambda(1:nb_eig);
end
[Phi,Psi,Scal] = compute_eigenvectors_DDAE(Q,P,hP,Lambda);

end
function [minimal_real_part] = parse_options(options)
    if isfield(options,'minimal_real_part')
        minimal_real_part = options.minimal_real_part;
    else
        minimal_real_part = -1;
    end
end
function [options] = get_roots_DDAE_options(minimal_real_part)
    options.minimal_real_part=minimal_real_part;  % all roots with real part larger than this value are desired  
    options.max_size_eigenvalue_problem=1000;
    % results in a possible restriction of the number of discretization
    % points for characteristic roots computations
    options.newton_max_iterations=50;
    % maximum number of Newton iterations to correct characteristic roots
    options.root_accuracy=1e-10;
    % stop criterion for Newton's method: norm on residual 
    options.commensurate_basic_delay=[];
    % value of the basic delay h in case of commensurate delay (optional); 
    % may lead to a speedup if  basic delay if ratio tau_max/h is small
    %
    options.fixN=0;
end
function [Phi,Psi,Scal] = compute_eigenvectors_DDAE(Q,P,hP,Lambda)
    % (local function) computes left and right eigenvectors associated with
    % the eigenvalues in Lambda.
    % (Scal(i) is equal to Phi(:,i)'*(Q+sum_{k}
    % hP(k)*P{k}*exp(-Lambda(i)*hP(k)))*Psi(:,i). Normalisation
    % coefficient)
    nM = size(Q,1);
    Phi = zeros(nM,length(Lambda)); Psi = zeros(nM,length(Lambda));
    Scal = zeros(1,length(Lambda));
    for j = 1:length(Lambda)
        lambda = Lambda(j);
        CM = -lambda*Q;
        for k=1:length(P)
           CM = CM+P{k} *exp(-lambda*hP(k));
        end
        [Phiw,Sigmaw,Psiw] = svd(CM); 
        if (Sigmaw(end) > 1e-5)
           warning('Obtained eigenvalue may be inprecise.'); 
        end
        phi = Phiw(:,end); psi = Psiw(:,end); 
        phi = phi*exp(-1i*angle(phi(1))); % Normalisation 
        
        % Normalise phi and psi such that 
        % phi^{H}*(Q+sum_{k} hP(k)*P{k}*exp(-Lambda(i)*hP(k)))*psi is real
        % and positive; 
        xiM = Q; 
        for k = 1:length(P)
           xiM = xiM + hP(k)*P{k}*exp(-lambda*hP(k));
        end
        denominator = phi'*xiM*psi;
        psi = psi*exp(-1i*angle(denominator));
        Phi(:,j) = phi;Psi(:,j) = psi;
        Scal(j) = real(phi'*xiM*psi);
    end
end