function [uncertain_sdep,metadata_sdep] = uncertain_sdep_create(Q,P,hP,R,S,hat_delta,uP,epsilon)
%UNCERTAIN_SDEP_CREATE creates an uncertain_sdep struct and its associated
%metadata.
%
%   [uncertain_sdep,metadata_sdep] =
%   uncertain_sdep_create(Q,P,hP,R,S,hat_Delta,uP,epsilon) creates
%   uncertain_sdep object and associated metadata for an uncertain sdep of
%   the following form:
%   Q lambda - sum_{k=1}^{lenght(P)} (P{k}+ sum_{s=1}^{length(uP)}uP{k}(s).G delta_{uP{k}(s).l} uP{k}(s).H) e^{-lambda hP(k)} - R Delta S
%   with delta_l a real-valued uncertainty of dimension hat_delta(l).q x hat_delta(l).r
%   and a maximum Frobenius norm of hat_delta(l).delta_bar and Delta a
%   complex valued uncertainty of dimension size(R,2) times size(S,1) and
%   a maximum spectral norm of epsilon
% INPUT
%   Q  - a real-valued, square, (possibly singular) matrix
%   P  - (1 x K) cell array with real-valued, square P matrices
%   hP - (1 x K) vector with the delays (real-valued and non-negative)
%   R,S- real-valued matrices
%   hat_delta - (1 x L) struct array with information on the real-valued uncertainties
%       and the following fields:
%           delta_bar - bound on Frobenius norm of uncertainty
%           q - row dimension uncertainty
%           r - column dimension uncertainty
%   - uP (1 x K) cell with struct array that contain information on how the
%   uncertainties influence the P matrices and the following fields:
%       l - position uncertainty in hat_delta
%       G - left shape matrix
%       H - right shape matrix
%   epsilon - bound on spectral norm of Delta (complex valued perturbation)
% OUTPUT
%   uncertain_sdep - struct with the following fields
%       Q, P, hP, R, S, hat_delta, uP, epsilon
%   metadata_sdep - struct with the following fields
%       n, m, p, KP, L

uncertain_sdep = {};
metadata_sdep = {};

if isreal(Q)
    if size(Q,1) ~= size(Q,2)
        error('Invalid dimensions. Matrix Q must be square.')
    end
    uncertain_sdep.Q = Q;
    metadata_sdep.n = size(Q,1);
else
    error('Invalid data type. Matrix Q should be real.')
end

if iscell(P)
    KP = length(P);
    for k = 1:KP
        if ~isreal(P{k})
            error('Invalid data type. Matrix P{%i} should be real.',k)
        end
        if size(P{k},1) ~= metadata_sdep.n || size(P{k},2) ~= metadata_sdep.n
            error('Invalid dimensions. Matrix P{%i} does not have the correct size. Expected (%i,%i) got (%i,%i).',k,metadata_sdep.n,metadata_sdep.n,size(P{k},1),size(P{k},2))
        end
    end
    if ~isreal(hP)
        error('Invalid data type. Elements of hP must be a real.');
    end
    if length(hP) ~= length(P)
        error('Invalid dimensions. Length of hP does not match the length of P.');
    end
    if any(hP<0)
        error('Invalid data type. Delay vector hP contains negative delays.');
    end
    uncertain_sdep.P = P;
    uncertain_sdep.hP = hP;
    metadata_sdep.KP = KP;
else
    error('Invalid data type. P should be a cell');
end
if isreal(R)
    if size(R,1) ~= metadata_sdep.n
        error('Invalid dimensions. Row dimension of R should be equal to %i, got %i',metadata_sdep.n,size(R,1))
    end
    uncertain_sdep.R = R;
    metadata_sdep.m = size(R,2); 
else
    error('Invalid data type. Matrix R should be real.')
end 

if isreal(S)
    if size(S,2) ~= metadata_sdep.n
        error('Invalid dimensions. Column dimension of S should be equal to %i, got %i',metadata_sdep.n,size(S,2))
    end
    uncertain_sdep.S = S;
    metadata_sdep.p = size(S,1); 
else
    error('Invalid data type. Matrix S should be real.')
end 

if isempty(hat_delta)
    uncertain_sdep.hat_delta = struct('delta_bar',{},'q',{},'r',{});
    metadata_sdep.L = 0;
else
    if (isstruct(hat_delta) && isfield(hat_delta,'delta_bar') && isfield(hat_delta,'q') && isfield(hat_delta,'r'))
        uncertain_sdep.hat_delta = hat_delta;
        metadata_sdep.L = length(uncertain_sdep.hat_delta);
    else
        error('Invalid data type. Input argument hat_delta is not a struct or does not contain the necessary fields.');
    end
end

if iscell(uP) && length(uP) == metadata_sdep.KP
    for k=1:metadata_sdep.KP
        temp_u = uP{k};
        if ~isempty(temp_u)
            if (~isstruct(temp_u) || ~isfield(temp_u,'l') || ~isfield(temp_u,'G') || ~isfield(temp_u,'H'))
                error('Invalid data type. Input argument uP{%i} is not a struct or does not contain the necessary fields.',k); 
            end
            for s = 1:length(temp_u)
                if temp_u(s).l > metadata_sdep.L || temp_u(s).l < 1
                    error('Number uP{%i}(%i).l is invalid. Expected integer between 1 and %i.',k,s,metadata_sdep.L)
                end
                l = temp_u(s).l; 
                if size(temp_u(s).G,1) ~= metadata_sdep.n || size(temp_u(s).G,2) ~= uncertain_sdep.hat_delta(l).q
                    error('Invalid dimensions. Right shape matrix uP{%i}(%i).G does not have the correct size. Expected (%i,%i) got (%i,%i).',...
                        k,s,metadata_sdep.n,uncertain_sdep.hat_delta(l).q,...
                        size(temp_u(s).G,1),size(temp_u(s).G,2))
                end

                if size(temp_u(s).H,2) ~= metadata_sdep.n || size(temp_u(s).H,1) ~= uncertain_sdep.hat_delta(l).r
                    error('Invalid dimensions. Left shape matrix uP{%i}(%i).H does not have the correct size. Expected (%i,%i) got (%i,%i).',...
                        k,s,uncertain_sdep.hat_delta(l).r,metadata_sdep.n,...
                        size(temp_u(s).H,1),size(temp_u(k).H,2))
                end
            end
        end
    end
    uncertain_sdep.uP = uP;
else
    error('Input argument uP is not a cell of appropriate size.');
end

if isreal(epsilon) && epsilon >=0
    uncertain_sdep.epsilon = epsilon;
else
    error('Invalid data type. Input argument epsilon should be non negative.') 
end
end

