function [rob_strong_asympt_hinfnorm,crit_delta,nb_sv_calc] = uncertain_tds_rob_strong_asympt_hinfnorm(uncertain_tds,options)
%UNCERTAIN_TDS_ROB_STRONG_ASYMPT_HINFNORM computes the robust strong
%asymptotic H-infinity norm of an uncertain_tds by solving the following
%optimisation problem:
%   max_{delta in hat_delta} max_{theta in [0,2 pi)^K} sigma1(Ta(delta,theta))
%   with
%   Ta(delta,theta) = D0(delta) + sum_{k} Dk(delta) exp(1j*theta(k)) (retarded case)
%   Ta(delta,theta) = D0(delta) + sum_{k} Dk(delta) exp(1j*theta(k)) +
%   (C0_2(delta)+sum_{k} Ck(delta)exp(1j*theta(k))) (A0_2(delta)+sum_{k}
%   Ak(delta)exp(1j*theta(k)))^{-1} (B0_2(delta)+sum_{k} Bk(delta)exp(1j*theta(k)))
%
% [rob_strong_asympt_hinfnorm] =
% uncertain_tds_rob_strong_asympt_hinfnorm(uncertain_tds) returns
% robust strong asymtotic H-infinity norm of uncertain_tds
% 
% [rob_strong_asympt_hinfnorm,crit_delta] =
% uncertain_tds_rob_strong_asympt_hinfnorm(uncertain_tds) also returns
% the critical delta
%
% [rob_strong_asympt_hinfnorm,crit_delta,crit_theta,nb_sv_calc] =
% uncertain_tds_rob_strong_asympt_hinfnorm(uncertain_tds) also returns
% number of singular value calculations in calculations
%
% [..] = uncertain_tds_rob_strong_asympt_hinfnorm(uncertain_tds,options)
% allows to specify additional options:
%       options.metadata_tds - metadata_tds associated with uncertain_tds
%       options.caution_level - influences number of initialisations
%       0 (small number of initialisations - default), 1, 2 (large number of initialisations)
%       options.print_level: 0 (quiet - default), 1 (result each initialisation), 2 (result each succesful step)
%       options.tol - Tolerance on 2-norm of the derivative of sigma1 with respect to
%          the elements of delta and theta (default - 1e-8)
%       FOR DDAE systems
%       options.left_E - left null space of the E matrix in uncertain_tds
%       options.right_E - right null space of the E matrix in uncertain_tds
    if nargin == 1
        metadata_tds = uncertain_tds_metadata(uncertain_tds);
        options.metadata_tds = metadata_tds;
    end
    metadata_tds = options.metadata_tds;
    if ~metadata_tds.ddae
        [rob_strong_asympt_hinfnorm,crit_delta,nb_sv_calc] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(uncertain_tds,options);
    else
        [rob_strong_asympt_hinfnorm,crit_delta,nb_sv_calc] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(uncertain_tds,options);
    end
end