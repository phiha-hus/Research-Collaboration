function [rob_strong_hinfnorm,rob_strong_asympt_hinfnorm,crit_omega,crit_delta,psa,output] = uncertain_tds_rob_strong_hinfnorm(uncertain_tds,options)
%UNCERTAIN_TDS_ROB_STRONG_HINFNORM computes the robust strong H-infinity
%norm of a linear, time-invariant, uncertain (ddae) delay system .
%
% [rob_strong_hinfnorm] = uncertain_tds_rob_strong_hinfnorm(uncertain_tds)
% returns the robust strong H-infinity norm of uncertain_tds
%
% [rob_strong_hinfnorm,rob_strong_asympt_hinfnorm,crit_omega] =
% uncertain_tds_rob_strong_hinfnorm(uncertain_tds) also returns the
% frequency at which robust strong H-infinity norm is attained (inf if the
% robust strong H-infinity norm is equal to the robust strong asymptotic
% H-infinity norm and NaN if system is not strongly internally
% exponentially stable for all delta in hat_delta)
%
% [rob_strong_hinfnorm,rob_strong_asympt_hinfnorm,crit_omega,crit_delta] =  
% uncertain_tds_rob_strong_hinfnorm(uncertain_tds) also returns the
% critical uncertainty associated with the robust strong H-infinity norm
%
% [rob_strong_hinfnorm,rob_strong_asympt_hinfnorm,crit_omega,crit_delta,psa,output]=
% uncertain_tds_rob_strong_hinfnorm(uncertain_tds) also returns the strong
% hat_delta pseudo-spectral abscissa of the uncertain system and some
% additional information on the total computation time of the algorithm and
% the computation time of the different steps.
%
% [..] = uncertain_tds_rob_strong_hinfnorm(uncertain_tds,options) allows to
% specify additional options
%   options.robust_strong_hinfnorm_lb - lowerbound for the robust strong hinfnorm (default: 0)
%   options.robust_strong_hinfnorm_ub - upperbound for hinfnorm (default: inf)
%   options.print_level - 0 (quiet - default), 1 (normal)
%   options.tol - influence accuracy (no guaranteed bound)
%   options.caution_level  - influences the number of initialisations used
%     for computing the psa, the robust strong asymptotic H-infinity norm and
%     the robust distance to finite root crossing 0 (low), 1 (normal), 2 (high)  
%  options.metadata_tds


%PLANNED MODIFICATIONS
% - allow for uncertainties on delays
% - guaranteed bound on accuracy

% High-level description implementation
%   STEP 0 - Compute the strong hat_delta pseudo spectral abscissa of
%     E\lamba-\tilde{A}0-\sum_{k=1}^{K} \tilde{A}k e^{-\lambda (\tau+\delta\tau_k)} 
%   STEP 1 - Compute the robust strong asymptotic H-infinity norm
%     (|||T_a(.;.,tau)|||_{H-infty}^{hat_delta}) 
%   STEP 2 - Compute the robust structured complex distance to finite root
%     crossing (dist_{FIN}(hat_delta))

%% START UP
start_total = tic;

if(nargin==1)
   options = struct(); 
end

[rob_strong_hinfnorm_lb,rob_strong_hinfnorm_ub,tol,print_level,caution_level,metadata_tds] = parse_options(options,uncertain_tds);

options_gradient_flow = struct();
options_gradient_flow.caution_level = caution_level;


options_gradient_flow.print_level = 0;

output = {};

%% STEP 0 - Compute the strong hat_delta pseudo spectral abscissa
options_psa = options_gradient_flow;
options_psa.metadata_tds = metadata_tds;

start_psa = tic;
if metadata_tds.ddae
    [psa,crit_delta_psa,crit_lambda_psa,~,~,output_psa] = uncertain_tds_strong_psa(uncertain_tds,options_psa);
else
    [psa,crit_delta_psa,crit_lambda_psa,~,~,output_psa] = uncertain_tds_psa(uncertain_tds,options_psa);
end
time_psa = toc(start_psa);
output.psa = struct('time',time_psa,'nb_eig_calc',output_psa.nb_eig_calc);
if (print_level >= 1)
   fprintf('STEP 0: alpha^{ps}(hat_delta) = %11.4e (Time: %9.3e (s) - Number eigenvalue calculations: %i)\n',psa,time_psa,output_psa.nb_eig_calc); 
end

if(psa>0)
    rob_strong_hinfnorm = nan;
    rob_strong_asympt_hinfnorm = nan;
    crit_omega = nan;
    crit_delta = crit_delta_psa;
    output.total_time = toc(start_total);
    warning('Not all admissible realisations of the uncertain system are (strongly) internally exponentially stable.');
    return;
end

%% STEP 1 - Compute the robust strong asymptotic H-infinity norm 
options_asympt = options_gradient_flow;
options_asympt.metadata_tds = metadata_tds;

start_asympt = tic;
[rob_strong_asympt_hinfnorm,crit_delta_asympt,nb_sv_calc] = uncertain_tds_rob_strong_asympt_hinfnorm(uncertain_tds,options_asympt);
time_asympt = toc(start_asympt);
output.asympt = struct('time',time_asympt,'nb_svd_calc',nb_sv_calc);
if (print_level >= 1)
   fprintf('STEP 1: |||T_a(.;.,tau)|||_{H-infty}^{hat_delta}= %11.4e (Time: %9.3e (s) - Number singular value calculations: %i)\n',rob_strong_asympt_hinfnorm,time_asympt,nb_sv_calc);
end
%% STEP 2 - Compute the robust structured complex distance to finite root crossing
% a) Create associtated sdep
[uncertain_sdep,metadata_sdep] = uncertain_tds2uncertain_sdep(uncertain_tds,metadata_tds);
% b) Compute lowerbound and upperbound for dist_{FIN}; 
lower = struct(); 
upper = struct(); 

options_combined_psa = options_gradient_flow;
options_combined_psa.metadata = metadata_sdep;
start_bounds = tic;
start_lb = tic;
if(rob_strong_hinfnorm_ub == inf)
    lower.epsilon = 0; 
    lower.alpha = psa; 
    lower.crit_delta = crit_delta_psa;
    lower.crit_lambda = crit_lambda_psa; 
    nb_eig_calc_lb = 0;
else
    dist_fin_lb = min([1/rob_strong_hinfnorm_ub,1/rob_strong_asympt_hinfnorm]);
    uncertain_sdep.epsilon = dist_fin_lb;
    [alpha_lb,~,crit_delta_lb,~,crit_lambda_lb,~,~,~,nb_ev_calc_lb_step] = uncertain_sdep_combined_psa(uncertain_sdep,options_combined_psa);
    lower.epsilon = dist_fin_lb; lower.alpha = psa_lb; 
    lower.lambda = crit_lambda_lb; lower.crit_delta = crit_delta_lb;
    nb_eig_calc_lb = nb_ev_calc_lb_step;
    if(alpha_lb>0) % Opletten bij ddae system -> use psa and not strong psa
        warning('Too small upper bound on the robust strong H-infinity norm. Using +inf instead!')
        lower.epsilon = 0; lower.alpha = psa; 
        lower.lambda = lambda_psa; 
        lower.crit_delta = crit_delta_psa;
    end
end
time_lb = toc(start_lb);
if (print_level >= 1)
	fprintf('Lower bound: epsilon_ub = %10.3e - alpha(hat{delta},epsilon_lb) = %11.4e (Time: %9.3e(s) - Number eigenvalue calculations: %i)\n',lower.epsilon,lower.alpha,time_lb,nb_eig_calc_lb); 
end

if(rob_strong_hinfnorm_lb == 0)
    epsilon_ub = 1/uncertain_tds_sigma1(uncertain_tds,0,[],metadata_tds); 
else
    epsilon_ub = 1/robust_hinf_lb; 
end
epsilon_ub = min(epsilon_ub,0.8/rob_strong_asympt_hinfnorm);

found_ub = false;
nb_eig_calc_ub = 0; iter_ub = 1;
while( ~found_ub) % Keep increasing epsilon_ub untill alpha_ub >= 0    
    start_ub = tic;
    uncertain_sdep.epsilon = epsilon_ub;
    [alpha_ub,~,crit_delta_ub,~,crit_lambda_ub,~,~,~,nb_ev_calc_ub_step] = uncertain_sdep_combined_psa(uncertain_sdep,options_combined_psa);
    time_ub = toc(start_ub);
    upper.epsilon = epsilon_ub; upper.alpha = alpha_ub; 
    upper.lambda = crit_lambda_ub; 
    upper.crit_delta = crit_delta_ub;
    nb_eig_calc_ub = nb_eig_calc_ub + nb_ev_calc_ub_step;
    if (print_level >= 1)
       fprintf('Upper bound - %i: epsilon_ub = %10.3e - alpha(hat{delta},epsilon_ub) = %11.4e (Time: %9.3e(s) - Number eigenvalue calculations: %i)\n',iter_ub,epsilon_ub,alpha_ub,time_ub,nb_ev_calc_ub_step); 
    end
    if alpha_ub > 0
        found_ub = true;
    else
        epsilon_ub = min(2*epsilon_ub,(epsilon_ub+3/rob_strong_asympt_hinfnorm)/4);
        lower = upper;
    end
    
    if(abs(1/epsilon_ub-rob_strong_asympt_hinfnorm)<tol*rob_strong_asympt_hinfnorm)
        % Algorithm finished - no finite root crossing found.
        rob_strong_hinfnorm = rob_strong_asympt_hinfnorm;
        crit_omega = Inf;
        crit_delta = crit_delta_asympt;
        time_bounds = toc(start_bounds);
        nb_eig_calc_bounds = nb_eig_calc_lb + nb_eig_calc_ub;
        output.bounds = struct('time',time_bounds,'nb_eig_calc',nb_eig_calc_bounds);
        output.total_time = toc(start_total);
        if (print_level >= 1)
            fprintf('Algorithm finished - no finite root crossing found.')
            fprintf('The robust H infinity norm is equal to asymptotic robust H infinity norm. \n');
            fprintf('|||T(.;.)|||_{H_infty}^{hat_delta} = %11.4e (Time: %9.3e (s))\n',rob_strong_hinfnorm,output.total_time)
        end
       return; 
    end
    iter_ub  = iter_ub +1;
end

time_bounds = toc(start_bounds);
nb_eig_calc_bounds = nb_eig_calc_lb + nb_eig_calc_ub;
output.bounds = struct('time',time_bounds,'nb_eig_calc',nb_eig_calc_bounds);
if print_level >= 1
    fprintf(['Initial bounds found: lowerbound = %11.4e (%11.4e) and upperbound = %11.4e(%11.4e) ' ...
        '(Time: %9.3e (s)- Number eigenvalue calculations: %i).\n'],... 
        lower.epsilon,lower.alpha,upper.epsilon,upper.alpha,time_bounds,nb_eig_calc_bounds);
end

% c) compute robust structured complex distance to instability
start_newt_bisec = tic;
[dist_fin,crit_omega,crit_delta,output_newt_bisec] = newt_bisec_robust_hinf(uncertain_sdep,lower,upper,tol,print_level,options_combined_psa);
time_newt_bisec = toc(start_newt_bisec);
if (print_level >= 1)
   fprintf('STEP 3: dist_{FIN}(hat_delta) =  %11.4f (Time: %9.3e (s) - Number eigenvalue calculations: %i ). \n', ... 
       dist_fin,time_newt_bisec,output_newt_bisec.nb_eig_calc);
end
if (print_level >= 1)
    fprintf('Algorithm finished.\n');
end
rob_strong_hinfnorm = 1/dist_fin;
output.total_time = toc(start_total);
fprintf('|||T(.;.)|||_{H_infty}^{hat_delta} = %11.4e (Time: %9.3e (s))\n',rob_strong_hinfnorm,output.total_time)
end

function [rob_strong_hinfnorm_lb,rob_strong_hinfnorm_ub,tol,print_level,caution_level,metadata_tds] = parse_options(options,uncertain_tds)
    if(isfield(options,'robust_hinf_lb'))
        rob_strong_hinfnorm_lb = options.rob_strong_hinfnorm_lb;
    else
        rob_strong_hinfnorm_lb = 0; 
    end
    if(isfield(options,'robust_hinf_ub'))
        rob_strong_hinfnorm_ub = options.rob_strong_hinfnorm_ub;
    else
        rob_strong_hinfnorm_ub = Inf;
    end
    if(isfield(options,'print_level'))
        print_level = options.print_level;
    else
        print_level = 0;
    end
    if isfield(options,'metadata_tds')
        metadata_tds = options.metadata_tds;
    else
        metadata_tds = uncertain_tds_metadata(uncertain_tds);
    end
    if isfield(options,'caution_level')
        caution_level = options.caution_level;
    else
        caution_level = 0;
    end
    if (isfield(options,'tol'))
       tol = options.tol;
    else
       tol = 1e-9;
    end

end

function [dist_fin,crit_omega,crit_delta,output] = newt_bisec_robust_hinf(uncertain_sdep,lower,upper,tol,print_level,options_combined_psa)
%NEWT_BISEC_ROBUST_HINF (local function) Adapted implementationf of Newton-Bisection
%algorithm form calculating the robust H infinity norm
%   Based on rtsafe found in W. Press, S. Teukolsky and W. Vetterling -
%   Numerical recipes in Fortran 77: the art of scientific computing,
%   Cambridge University press, 2nd edition, 1996
%


development_options.hotstart = 1;


dist_fin_lb = lower.epsilon; psa_lb = lower.alpha;
dist_fin_ub = upper.epsilon; psa_ub = upper.alpha;
output.nb_eig_calc = 0; 

if(abs(psa_lb) < tol)
   dist_fin = dist_fin_lb;
   crit_omega = imag(lower.lambda);
   crit_delta = lower.crit_delta;
   return
elseif(abs(psa_ub) < tol)
   dist_fin = dist_fin_ub;
   crit_omega = imag(upper.lambda);
   crit_delta = upper.crit_delta;
   return
end


depsilon = dist_fin_ub-dist_fin_lb;

iter_nb = 0;
while true
    if iter_nb == 0 || ...
        ((epsilon-dist_fin_ub).*dalpha-alpha_ps)*((epsilon-dist_fin_lb)*dalpha-alpha_ps) >= 0 || ...
         abs(2*alpha_ps) > abs(depsilon_old.*dalpha)
    %Bisection step
        depsilon_old = depsilon;
        depsilon = 0.5*(dist_fin_ub-dist_fin_lb);
        epsilon = dist_fin_lb+depsilon;
    else
    %Newton step
        depsilon_old = depsilon;
        depsilon =  alpha_ps/dalpha; 
        epsilon = epsilon-depsilon;
    end
    start_psa = tic;
    uncertain_sdep.epsilon = epsilon;
    [alpha_ps,dalpha,crit_delta,~,crit_lambda,~,~,hot_start_next,nb_ev_calc_step] = uncertain_sdep_combined_psa(uncertain_sdep,options_combined_psa);
    time_psa = toc(start_psa);
    if development_options.hotstart
        options_combined_psa.hot_start = hot_start_next;
    end
    output.nb_eig_calc = output.nb_eig_calc + nb_ev_calc_step;
    iter_nb = iter_nb + 1;
    if (print_level >= 1)
        fprintf('Newton-Bisection - %i: epsilon = %11.4e - alpha = %11.4e - dalpha = %11.4e (Time: %9.3e - Number eigenvalue calculations: %i)\n',iter_nb,epsilon,alpha_ps,dalpha,time_psa,nb_ev_calc_step);
    end
    
    if (abs(depsilon)<tol )
       break; 
    end
    if(alpha_ps<0)
       dist_fin_lb = epsilon;
    else
        dist_fin_ub = epsilon;
    end
    
end
crit_omega = imag(crit_lambda);
dist_fin = epsilon;
end


