function [uncertain_tds,metadata_tds] = uncertain_tds_create(varargin)
%UNCERTAIN_TDS_CREATE creates an uncertain_tds object and its associated
%metadata.
%
%   [uncertain_tds,metadata] = uncertain_tds('retarded',A,hA,B,hB,C,hC,D,hD,hat_delta,uA,uB,uC,uD)
%   creates an uncertain_tds object and associated metadata for an
%   uncertain LTI retarded time-delay system of the following form:  
%        x'(t) = sum_{k=1}^{length(A)} (A{k} + sum_{s=1}^{lenght(uA{k})} uA{k}(s).G delta_{uA{k}(s).l} uA{k}(s).H) x(t-hA(k)) + 
%                   + sum_{k=1}^{length(B)} (B{k} + sum_{s=1}^{lenght(uB{k})} uB{k}(s).G delta_{uB{k}(s).l} uB{k}(s).H) w(t-hB(k)) 
%        z(t)  = sum_{k=1}^{length(C)} (C{k} + sum_{s=1}^{lenght(uC{k})} uC{k}(s).G delta_{uC{k}(s).l} uC{k}(s).H) x(t-hC(k)) + 
%                   sum_{k=1}^{length(D)} (D{k} + sum_{s=1}^{lenght(uC{k})} uD{k}(s).G delta_{uD{k}(s).l} uD{k}(s).H) w(t-hDk) 
%        with delta_l a real-valued uncertainty of dimension hat_delta(l).q x hat_delta(l).r
%        and a maximum Frobenius norm of hat_delta(l).delta_bar
% INPUT       
%   A  - Cell with KA real valued (n x n) state matrices
%   hA - Delay vector (dimension KA) for state matrices (Note elements in hA should be uniqe)
%   B  - Cell with KB real valued (n x m) input matrices
%   hB - Delay vector (dimension KB) for input matrices (Note elements in hB should be uniqe)
%   C  - Cell with KC real valued (p x n) output matrices
%   hC - Delay vector (dimension KC) for output matrices (Note elements in hC should be uniqe)
%   D  - Cell with KD real valued (p x m) direct feedthrough matrices
%   hD - Delay vector (dimension KD) for direct feedthrough matrices (Note elements in hD should be uniqe)
%   hat_delta - (Contains information on the uncertainties.)
%    (1 x L) Structure array (struct) with the following fields
%       delta_bar - bound on Frobenius norm of uncertainty
%       q - row dimension of uncertainty
%       r - column dimension of uncertainty
%   uA, uB, uC, uD - (Contains information on how the uncertainties influence
%   the coefficient matrices.) 
%     (1 x KA/KB/KC/KD) Cell of struct arrays with the
%     following fields:
%       l - position uncertainty in hat_delta
%       G - left shape matrix
%       H - right shape matrix
%  
%   [uncertain_tds,metadata] = uncertain_tds('ddae',E,A,hA,B,hB,C,hC,D,hD,hat_delta,uA,uB,uC,uD)
%   creates an uncertain_tds object and associated metadta for an uncertain LTI system
%   described by delay differential algebraic equations of the following form:
%         Ex'(t) = sum_{k=1}^{length(A)} (A{k} + sum_{s=1}^{lenght(uA{k})} uA{k}(s).G delta_{uA{k}(s).l} uA{k}(s).H) x(t-hA(k)) + 
%                   + sum_{k=1}^{length(B)} (B{k} + sum_{s=1}^{lenght(uB{k})} uB{k}(s).G delta_{uB{k}(s).l} uB{k}(s).H) w(t-hB(k)) 
%        z(t)  = sum_{k=1}^{length(C)} (C{k} + sum_{s=1}^{lenght(uC{k})} uC{k}(s).G delta_{uC{k}(s).l} uC{k}(s).H) x(t-hC(k)) + 
%                   sum_{k=1}^{length(D)} (D{k} + sum_{s=1}^{lenght(uC{k})} uD{k}(s).G delta_{uD{k}(s).l} uD{k}(s).H) w(t-hDk) 
% INPUT
%   E  - real-valued n x n matrix     
%   A  - Cell with KA real valued (n x n) state matrices
%   hA - Delay vector (dimension KA) for state matrices (Note elements in hA should be uniqe)
%   B  - Cell with KB real valued (n x m) input matrices
%   hB - Delay vector (dimension KB) for input matrices (Note elements in hB should be uniqe)
%   C  - Cell with KC real valued (p x n) output matrices 
%   hC - Delay vector (dimension KC) for output matrices (Note elements in hC should be uniqe)
%   D  - Cell with KD real valued (p x m) direct feedthrough matrices
%   hD - Delay vector (dimension KD) for direct feedthrough matrices (Note elements in hD should be uniqe)
%   hat_delta - (Contains information on the uncertainties.)
%    (1 x L) Structure array (struct) with the following fields
%       delta_bar - bound on Frobenius norm of uncertainty
%       q - first dimension of uncertainty
%       r - second dimension of uncertainty
%   uA, uB, uC, uD - (Contains information on how uncertainties influence
%   coefficient matrices.)
%     (1 x KA/KB/KC/KD) Cell of structure arrays (struct) with the
%     following fields:
%       l - position uncertainty in hat_delta
%       G - left shape matrix
%       H - right shape matrix
%
%   Assumption: 
%        hA(1) = 0,  and 
%        U' A{1} + sum_{s=1}^{lenght(uA{1})} uA{1}(s).G delta_{uA{1}(s).l} uA{1}(s).H V is non-singular for all permissable delta, 
%        where U and V are matrices whose columns form a basis for respectively 
%        the left and right nullspace of E 
%
% % OUTPUT
%   uncertain_tds - struct with the following fields
%       E, A, hA, uA, B, hB, uB, C, hC, uC, D, hD, uD, hat_delta
%   metadata_sdep - struct with the following fields
%       ddae, delay_free, KA, KB, KC, KD, n, m, p, L

% Example (for more examples see also example_uncertain_tds_create.m)
% x'(t) = (-7 + [1 1] delta_1 [0; 1]) x(t) + (1 + [1 0] delta_1 [1; 1] + 2 delta_2) x(t-1) + 4 w(t) ;
% z (t) = (2 + [1 0] delta_1 [1; 0]+ [0 1] delta_1 [0; 1]) x(t) + (1 + delta_2) w(t) +  w(t-1);
% with |delta_1| <= 0.2 and |delta_2| <= 0.1
%
%>> hat_delta(1) = struct('delta_bar',0.2,'q',2,'r',2);
%>> hat_delta(2) = struct('delta_bar',0.1,'q',1,'r',1);
%>> uA{1}(1) = struct('l',1,'G',[1 1],'H',[0;1]);
%>> uA{2}(1) = struct('l',1,'G',[1 0],'H',[1;1]);
%>> uA{2}(2) = struct('l',2,'G',2,'H',1);
%>> uB{1}(1) = struct('l',{},'G',{},'H',{});
%>> uC{1}(1) = struct('l',1,'G',[1 0],'H',[1; 0]);
%>> uC{1}(2) = struct('l',1,'G',[0 1],'H',[0; 1]);
%>> uD{1}(1) = struct('l',2,'G',1,'H',1);
%>> uncertain_tds('retarded',{[-7],[1]},[0 1],{[4]},[0],{[2]},[0],{[1],[1]},[0 1], ...
%   hat_delta,uA,uB,uC,uD)

%PLANNED MODIFICATIONS::
%   - Allow for uncertainties on delays.
%   - Allow for repetions in delays
%   - For delay free-systems, allow function handle for matrix A.
%   - Check (causality/ impulsive solution) assumption for ddae systems by computing
%       min_{delta in hat{delta}} sigma_min(U^{H}A0 V)

inputparam = varargin; 
nb_param = length(inputparam);
if nb_param==0
    error('Not enough input arguments.');
end

uncertain_tds = {};
metadata_tds = {};

% Check if retarded or ddae.
if ischar(inputparam{1}) && strcmpi( inputparam{1}, 'retarded')
    if length(inputparam) <14
        error('Not enough input arguments.');
    elseif length(inputparam) >14
        error('Too many input arguments.');
    end
    metadata_tds.ddae = false;
    uncertain_tds.E = [];
    idxA = 2; 
elseif ischar(inputparam{1}) && strcmpi( inputparam{1}, 'ddae')
    if length(inputparam) <15
        error('Not enough input arguments.');
    elseif length(inputparam) > 15
        error('Too many input arguments.');
    end
    tempE = inputparam{2};
    if isreal(tempE)
        if size(tempE,2) ~= size(tempE,1)
            error('Invalid dimensions. Matrix E must be square.')
        end
        metadata_tds.ddae = true;
        uncertain_tds.E = tempE;
        idxA = 3; 
    else
        error('Invalid data type. Matrix E must be real.');
    end
else
    error('Invalid system type. Options: retarded and ddae.')
end

fields = {'A','B','C','D'};
for i = 1:length(fields) 
    index_matrix_cell = idxA+(i-1)*2;
    tmpcell = inputparam{index_matrix_cell}; 
    if ~iscell(tmpcell)
        error('Invalid data type. %s must be a cell.',fields{i});
    elseif ~isempty(tmpcell)
        for k=1:length(tmpcell)
            if ~isreal(tmpcell{k})
                error('Invalid data type. Matrix %s{%i} must be real.',fields{i},k);
            end
        end
    end
    uncertain_tds.(fields{i}) = tmpcell; 
    metadata_tds.(strcat('K',fields{i})) = length(tmpcell);
    
    tmpdelay = inputparam{index_matrix_cell+1}; 
    if ~isempty(tmpdelay) && ~isreal(tmpdelay)
        error('Invalid data type. h%s must be a real.',fields{i});
    end
    if length(tmpdelay) ~= metadata_tds.(['K' fields{i}])
        error('Length of %s does not match the length of h%s.',fields{i},fields{i});
    end
    if any(tmpdelay<0)
        error('Delay vector h%s contains negative delays.',fields{i});
    end
    if length(unique(tmpdelay)) ~= length(tmpdelay)
        error('Delay vector h%s contains repetitions.',fields{i});
    end
    uncertain_tds.(['h' fields{i}]) = tmpdelay;
end

delay_free = true;
for i=1:length(fields)
    if metadata_tds.(['K' fields{i}]) > 1 || (metadata_tds.(['K' fields{i}]) == 1 && uncertain_tds.(['h' fields{i}]) ~= 0)
        delay_free = false;
        break;
    end
end

if delay_free
    metadata_tds.delay_free = true;
    metadata_tds.A_sparse = ~isempty(uncertain_tds.A) && issparse(uncertain_tds.A{1});  
else
    metadata_tds.delay_free = false;
    metadata_tds.A_sparse = false;
end

% Find n (dimension state vector)
if metadata_tds.ddae
    metadata_tds.n = size(uncertain_tds.E,1);
elseif (metadata_tds.KA>0)
    metadata_tds.n = size(uncertain_tds.A{1},1);
elseif (metadata_tds.KB>0)
    metadata_tds.n = size(uncertain_tds.B{1},1);
elseif (metadata_tds.KC>0)
    metadata_tds.n = size(uncertain_tds.C{1},2);
else
    metadata_tds.n = 0;
end
% Find m (dimension input vector)
if (metadata_tds.KB > 0)
    metadata_tds.m = size(uncertain_tds.B{1},2);
elseif (metadata_tds.KD >0)
    metadata_tds.m = size(uncertain_tds.D{1},2);
else
    metadata_tds.m = 0;
end
% Find p (dimension output vector)
if (metadata_tds.KC > 0)
    metadata_tds.p = size(uncertain_tds.C{1},1);
elseif (metadata_tds.KD > 0)
    metadata_tds.p = size(uncertain_tds.D{1},1);
else
    metadata_tds.p = 0;
end 

% Check if matrices in A, B, C, D have the correct size
dimensions= [metadata_tds.n metadata_tds.n;metadata_tds.n metadata_tds.m;...
    metadata_tds.p metadata_tds.n;metadata_tds.p metadata_tds.m];
for i = 1:length(fields)
    for k=1:metadata_tds.(['K' fields{i}])
        if size(uncertain_tds.(fields{i}){k},1)~= dimensions(i,1) || ...
            size(uncertain_tds.(fields{i}){k},2) ~= dimensions(i,2)
            error('Matrix %s{%i} does not have the correct size. Expected (%i,%i) got (%i,%i).',...
                fields{i},k,dimensions(i,1),dimensions(i,2),...
                size(uncertain_tds.(fields{i}){k},1),size(uncertain_tds.(fields{i}){k},2));
        end
    end
end

% For systems in ddae form check if E has appropriate dimension
if metadata_tds.ddae
    if size(uncertain_tds.E,1) ~= metadata_tds.n || size(uncertain_tds.E,2) ~= metadata_tds.n
        error('Matrix E does not have the correct size. Expected (%i,%i) got (%i,%i).',...
            metadata_tds.n,metadata_tds.n,size(uncertain_tds.E,1),size(uncertain_tds.E,2));
    end
end

% For systems in ddae form check if assumption (U^{H}A0(delta)V is non-singular)
% holds for nominal system.
if metadata_tds.ddae
    if rank(uncertain_tds.E) < metadata_tds.n
        U = null(uncertain_tds.E'); V = null(uncertain_tds.E);
        ind0 = find(uncertain_tds.hA== 0);
        if isempty(ind0)
            warning('U^{H}A0V is (close to) singular.');
        end
        A0 = zeros(metadata_tds.n,metadata_tds.n);
        for ind = ind0
            A0 = A0 + uncertain_tds.A{ind};
        end
        if metadata_tds.delay_free && metadata_tds.A_sparse
            sigma_min = min(svds(U'*A0*V,3,'smallest'));
        else
            sigma_min = min(svd(U'*A0*V));
        end
        if sigma_min<1e-12
            warning('U^{H}A0V is (close to) singular.');
        end
    end
end

% position of hat_delta in input arguments
idxhatdelta = idxA + 8;
    
hatdeltatemp = inputparam{idxhatdelta};
if isempty(hatdeltatemp)
    uncertain_tds.hat_delta = struct('delta_bar',{},'q',{},'r',{});
    metadata_tds.L = 0;
else
    if (isstruct(hatdeltatemp) && isfield(hatdeltatemp,'delta_bar') && isfield(hatdeltatemp,'q') && isfield(hatdeltatemp,'r'))
        uncertain_tds.hat_delta = hatdeltatemp;
        metadata_tds.L = length(uncertain_tds.hat_delta);
    else
        error('Input argument hat_delta is not a struct or does not contain the necessary fields.');
    end
end



for idx = 1:length(fields)
    temp_u_cell = inputparam{idxhatdelta+idx};
    u_name  = ['u' fields{idx}];
    if iscell(temp_u_cell) && length(temp_u_cell) == metadata_tds.(['K' fields{idx}])
        for k=1:metadata_tds.(['K' fields{idx}])
            temp_u = temp_u_cell{k};
            if ~isempty(temp_u)
                if (~isstruct(temp_u) || ~isfield(temp_u,'l') || ~isfield(temp_u,'G') || ~isfield(temp_u,'H'))
                    error('Input argument %s{%i} is not a struct or does not contain the necessary fields.',u_name,k); 
                end
                for s = 1:length(temp_u)
                    if temp_u(s).l > metadata_tds.L || temp_u(s).l < 1
                        error('Number %s{%i}(%i).l is invalid. Expected integer between 1 and %i.',u_name,k,s,metadata_tds.L)
                    end
                    l = temp_u(s).l; 
                    if size(temp_u(s).G,1) ~= dimensions(idx,1) || size(temp_u(s).G,2) ~= uncertain_tds.hat_delta(l).q
                        error('Right shape matrix %s{%i}(%i).G does not have the correct size. Expected (%i,%i) got (%i,%i).',...
                            u_name,k,s,dimensions(idx,1),uncertain_tds.hat_delta(l).q,...
                            size(temp_u(s).G,1),size(temp_u(s).G,2))
                    end

                    if size(temp_u(s).H,2) ~= dimensions(idx,2) || size(temp_u(s).H,1) ~= uncertain_tds.hat_delta(l).r
                        error('Left shape matrix %s{%i}(%i).H does not have the correct size. Expected (%i,%i) got (%i,%i).',...
                            u_name,k,s,uncertain_tds.hat_delta(l).r,dimensions(idx,2),...
                            size(temp_u(s).H,1),size(temp_u(s).H,2))
                    end
                end
            end
        end
        uncertain_tds.(u_name) = temp_u_cell;
    else
        error('Input argument %s is not a cell of appropriate size.',u_name);
    end
end

end

