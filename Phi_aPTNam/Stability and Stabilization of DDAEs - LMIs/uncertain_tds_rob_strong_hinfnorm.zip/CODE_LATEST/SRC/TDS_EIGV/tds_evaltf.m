function tf = tds_evaltf(tds,sv,md)
% tds_evaltf: evaluates the transfer function at a complex point s
%
%  tds = tds_evaltf(tds,s);
%  tds = tds_evaltf(tds,s,md);
%  
%  The function evaluates the transfer function of the time-delay
%  system tds for the values of the laplace variable sv (vector or
%  scalar). If metadata is not given, it is checked that the system
%  is a valid time-delay system, lti, neutral, then metadata is
%  computed. 
%
%  If s is a vector, then a multidimensional array of size 
%    md.nC1 x md.nB1 x length(s)
%  is returned.
%
%  Example: plot Bode diagram
%  A=[0 1; -4 -1]; B=[0 0; 2 1];
%  tds=tds_create({A,B},[0 1],{[1;0]},0,{[1,1]},0);
%  omegav=logspace(-1,2,200);
%  Hv=tds_evaltf(tds,1i*omegav);
%  loglog(omegav,abs(squeeze(Hv)));

if nargin<3
    tds_check_valid(tds);
    tds_assert_properties(tds,'lti','neutral');
    md = tds_metadata(tds);
end


tf=zeros(md.nC1,md.nB1, length(sv));

for k=1:length(sv)
    s=sv(k);

    sumB1=zeros(md.nE,md.nB1);
    sumC1=zeros(md.nC1,md.nE);
    sumD11=zeros(size(sumC1,1),size(sumB1,2));
    
    sumAE=tds.E{1}*(s*exp(-tds.hE(1)*s));
    for id=2:md.mE
        sumAE=sumAE + tds.E{id}*(s*exp(-tds.hE(id)*s));
    end
    
    for id=1:md.mA
        sumAE=sumAE - tds.A{id}*exp(-tds.hA(id)*s);
    end
    
    for id=1:md.mB1
        sumB1=sumB1 + tds.B1{id}*exp(-tds.hB1(id)*s);
    end
    
    for id=1:md.mC1
        sumC1=sumC1 + tds.C1{id}*exp(-tds.hC1(id)*s);
    end
    
    for id=1:md.mD11
        sumD11=sumD11 + tds.D11{id}*exp(-tds.hD11(id)*s);
    end
    
    tf(:,:,k) = sumC1*(sumAE\sumB1)+sumD11;
        
end