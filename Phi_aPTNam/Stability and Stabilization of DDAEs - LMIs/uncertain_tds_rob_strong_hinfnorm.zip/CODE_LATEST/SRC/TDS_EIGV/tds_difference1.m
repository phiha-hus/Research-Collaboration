function [f,grad]=tds_difference1(diff);

% case for one delay


Dc=diff.Dc;
D=diff.D{1};

DDc=D*Dc;
no=length(DDc);

u=eig(DDc);
[m1,m2]=max(abs(u));
l=u(m2);

[U,S,V]=svd(DDc-l*eye(no));
u=U(:,no);
v=V(:,no);

%
% C_D and its sensitivity
%

if l==0,
    f=-inf;
    grad=zeros(size(Dc));
elseif diff.hD==0,
    if m1<1,
        f=-inf;
    else
        f=inf;
    end
    grad=zeros(size(Dc));
else
    f=1/(diff.hD)*log(m1);
    grad=1/(diff.hD*m1^2)*real(conj(l)* (1/(u'*v)*transpose(u'*D)*transpose(v)));
end



return


