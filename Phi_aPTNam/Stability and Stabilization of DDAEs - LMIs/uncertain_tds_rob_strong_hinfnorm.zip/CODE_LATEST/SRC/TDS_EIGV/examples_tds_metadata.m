% Examples for tds_metadata function

% clear tds;
% tds=tds_create({2*eye(3),eye(3)},[0 0],{4*eye(3),eye(3)},[0,1],'neutral');
% md=tds_metadata(tds)

% clear tds;
% tds=tds_create({2*eye(2),eye(2)},[0 1],{[2;1]},{eye(2)},{[2;1]},1);
% md=tds_metadata(tds);

% clear tds;
% tds=tds_create({eye(2)},0,{2*eye(2),eye(2)},[0 1],{[2;1]},{eye(2)},[0],{[2;1]},1,{[0;1]},0,{[-1;0]},1);
% md=tds_metadata(tds)

% clear tds;
% tds=tds_create({eye(2),eye(2)},[0 1],{2*eye(2),eye(2)},[0 1],{[2;1]},[0],{eye(2)},[0],{[2;1]},1,{[0;1]},0,{[-1;0]},1,'neutral');
% md=tds_metadata(tds)

% clear tds;
% tds=tds_create({eye(2),-eye(2)},[0 0],{2*eye(2),eye(2)},[0 1],{[2;1]},[0],{eye(2)},[0],{[2;1]},1,{[0;1]},0,{[-1;0]},1,'neutral');
% md=tds_metadata(tds)