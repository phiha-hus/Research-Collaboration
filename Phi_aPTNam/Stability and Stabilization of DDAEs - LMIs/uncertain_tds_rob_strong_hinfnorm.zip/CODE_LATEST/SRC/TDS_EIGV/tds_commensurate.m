function [tdscommobj,tauresidual]=tds_commensurate(tdsobj,varargin)
% tds_commensurate: create a commensurate time-delay system
% 
%  [tdscommobj,tauresidual]=tds_commensurate(tdsobj)
%  or 
%  [tdscommobj,tauresidual]=tds_commensurate(tdsobj,tol)
%
%  Creates a new time-delay system tdscommobj which is equivalent
%  to (or approximates) tdsobj but has the delays 0:tau0:taumax,
%  i.e., the system has commensurate delays. The cells of matrices 
%  in tdscommobj will typically be large with many zero matrices.   
%
%  tol is the tolerance for the rounding of the rational number
%  (see also: help rat), for which the default is
%  1e-6*norm(X,1). The error in the approximation of the delays is
%  stored in tauresidual. 
%   
%  The function does not always produce the best approximation, in
%  particular for systems with more than two delays.
%
%  Example: 
%  tdsobj=tds_create({rand(3),rand(3), rand(3)},[0 1 3.1]);
%  [tdscommobj1,taures1]=tds_commensurate(tdsobj);
%  taures1              % approximation error is zero 
%  size(tdscommobj1.A)  % size of system
% 
%  % Not well approximated by a small commensurate system:
%  tdsobj=tds_create({rand(3),rand(3), rand(3)},[0 1 pi]);
%  [tdscommobj2,taures2]=tds_commensurate(tdsobj);
%  taures2              % approximation error is not zero 
%  size(tdscommobj2.A)  % and size of system is large
% 
%  % We can make it more accurate by decreasing the
%  % tolerance, and increasing the number of delays.
%  [tdscommobj3,taures3]=tds_commensurate(tdsobj,1e-8);
%  taures3              % approximation error is smaller
%  size(tdscommobj3.A)  % and size of system is large
% 
    


    %% Fetch all delay values from all delay fields
    fields=tds_get_delay_fields(tdsobj);
    v=[];
    for k=1:length(fields)
        v=[v,getfield(tdsobj,['h',fields{k}])];
    end
    v=unique(v); % v is a vector with all delays
    taumax=max(v);  

    
    n=length(tdsobj.A{1}); % Assume A exist


    %% Construct the least common multiplier of all the denominators:
    %% This is not necesserily the most compact representations of 
    %% the commensurate system.
    if (length(varargin)>0)
        [N,D]=rat(v/taumax,varargin{1});    
    else
        [N,D]=rat(v/taumax);    
    end

    if (D==0)
        p=0;
    else
        % Compute the least common denominator of all the rational values
        p=1;
        for k=1:length(D)
            p=lcm(p,D(k)); 
        end
    end
    ptau=round(v*p/taumax); % vector of integers    
    if (taumax==0)
       ptau=zeros(size(ptau)); 
    end
    delay_to_index=[v',ptau']; 

    tau0=taumax/p;
    if (p==0)
       tau0=0; 
    end
    % ptau*tau0 is (almost) equal to the delays.
    
    tauresidual=ptau*tau0-v; % The remainder of the approximation

    if (p>1e5)
        p
        warning(['Creating a commensurate system with a very large ', ...
                 'number of  delays. Deacrease tolerance to increase speed.']);
    end
    if (p>1e7) % Too many delays
       p
       error(['No reasonable commensurate approximation found. Try ', ...
              'decreasing the tolerance.']);
    end
    
    
    %% Construct the coefficient sparse commensurate system 
    
    
    tauv=0:tau0:taumax;
    if (length(tauv)==0)
       tauv=0; 
    end
    tdscommobj=tdsobj;
    % For loop all relevant fields.
    fields=tds_get_delay_fields(tdsobj);
    for f=1:length(fields)
        Q0=getfield(tdscommobj,fields{f});
        Q0_tau=getfield(tdscommobj,['h',fields{f}]);
        
        % Reset the matrices
        Q=cell(1,p+1);
        if (issparse(Q0{1}))
            Zmat=sparse(size(Q0{1},1), size(Q0{1},2)); % sparse zero matrix
        else    
            Zmat=zeros(size(Q0{1}));    % full zero matrix
        end
        for k=1:length(Q)
           Q{k}=Zmat; 
        end

        % for loop through all the delays
        for k=1:length(Q0)
            % Look up at what index this delay corresponds to
            % and add the corresponding matrix
            tau_ind=find(delay_to_index(:,1)==Q0_tau(k));
            QQ0=Q{delay_to_index(tau_ind,2)+1};
            Q{delay_to_index(tau_ind,2)+1}=QQ0+Q0{k};
        end
        
        % Update the fields
        tdscommobj=setfield(tdscommobj,fields{f},Q);        
        tdscommobj=setfield(tdscommobj,['h',fields{f}],tauv);        
    end
    