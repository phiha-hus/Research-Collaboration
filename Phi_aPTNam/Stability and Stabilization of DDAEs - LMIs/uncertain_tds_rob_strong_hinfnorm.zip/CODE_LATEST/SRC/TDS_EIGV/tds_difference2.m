function [f,grad]=tds_difference2(diff);

% case for two delays



N=20; 

Dc=diff.Dc;
D1=diff.D{1};D2=diff.D{2};
DDc1=D1*Dc;  DDc2=D2*Dc;
no=length(DDc1);
tau1=diff.hD(1);
tau2=diff.hD(2);




% voorlopig
if norm(diff.Dc)<1.e-8,
    f=-inf;
    grad=zeros(size(Dc));
return
end
% end voorlopig





x=fzero(@predictc1,0);

[dummy1,radiuseig,theta]=predictc1(x);

D=D1*exp(-x*tau1)+D2*exp(-x*tau2)*exp(1i*theta);
Dh=D*Dc;
[U,S,V]=svd(Dh-radiuseig*eye(no));


u=U(:,no);
v=V(:,no);


%
% C_D and its sensitivity
%


if radiuseig==0,
    f=-inf;
    grad=zeros(size(Dc));
else
    f=x;
    grad=real((conj(radiuseig)*transpose(u'*D)*transpose(v))/(u'*v));
    factor=real((conj(radiuseig)*u'*(DDc1*tau1*exp(-x*tau1)+DDc2*tau2*exp(-x*tau2)*exp(1i*theta))*v)/(u'*v));
    grad=grad/factor;
end







                           
function [f,radiuseig,theta]=predictc1(c);

 radius=0; radiuseig=0; theta=0;
    th = linspace(0,pi,N);
    for k=1:N
        M=diff.D{1}*exp(-c*tau1)+diff.D{2}*exp(-c*tau2)*exp(1i*th(k));
        u=eig(M*Dc);
        [m1,m2]=max(abs(u));
        if m1>radius,
           radius=m1;
           radiuseig=u(m2);
           theta=th(k);
        end 
    end
 f=radius-1;
    
end







end


