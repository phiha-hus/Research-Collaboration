function fields=tds_get_delay_fields(tds)
%  tds_get_delay_fields: the matrix/delay fields of struct tds 
%   
%  fields=tds_get_delay_fields(tdsobj)
%
%    Returns a cell array of field names for which the struct
%    tdsobj has non-empty matrices. 
%
%    This method depends on the tds data structure and is meant for
%    internal use. 
% 
%  Example:
%  tds=tds_create({rand(4)},0);
%  fields=tds_get_delay_fields(tds) % returns {'A'}
%  A=getfield(tds,fields{1}); % Get the matrices
%

    fields={};
    % For-loop through all potential fields
    allfields={'E','A','B1','B2','C1','C2','D11','D12','D21', 'D22'};
    for k=1:length(allfields)
        if (isfield(tds,allfields{k})) % It  exists 
            if (length(getfield(tds,allfields{k}))>0) % It has matrices
                fields={fields{:},allfields{k}}; % Add it
            end
        end
    end
    
    
    