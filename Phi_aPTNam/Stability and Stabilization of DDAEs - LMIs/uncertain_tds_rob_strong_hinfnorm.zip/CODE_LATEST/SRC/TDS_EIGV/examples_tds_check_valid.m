% Examples for tds_check_valid function

tds.E={};
tds.hE=[];
tds.A={2*eye(2),eye(2)};
tds.hA=[0 1];
tds.B1={[2;1]};
tds.hB1=0;
tds.C1={eye(2)};
tds.hC1=0;
tds.B2={rand(2,3)};
tds.hB2=0;
tds.C2={eye(2)};
tds.hC2=0;
tds.D11={[2;1]};
tds.hD11=[1];
tds.D12={rand(2,3)};
tds.hD12=1;
tds.D21={[1;1]};
tds.hD21=0;
tds.D22={rand(2,3)};
tds.hD22=1;


%% no input parameter case
% tds_check_valid();

%% all fields should defined
% tds1=tds;
% tds1=rmfield(tds1,'C2');
% tds_check_valid(tds1);

%% each system matrix should be a cell array with numerical content
% tds1=tds;
% tds1.A=eye(2); % !
% % tds.A={'a'}; % !
% tds_check_valid(tds1);

%% each system delay should be a vector with numerical content
% tds1=tds;
% tds1.A={1};
% tds1.hA={1}; % !
% % tds1.hA='a'; % !
% tds_check_valid(tds);

%% system delays should be nonnegative
% tds1=tds;
% tds1.A={1,2}; %!
% tds1.hA=[1 -1];
% tds_check_valid(tds1);

%% sizes of matrices inside a cell array should be same
% tds1=tds;
% tds1.A={1,eye(2)}; %!
% tds1.hA=[1 2];
% tds_check_valid(tds1);

%% the number of system delays should be same as system matrices
% tds1=tds;
% tds1.A={2*eye(2),eye(2)}; %!
% tds1.hA=[1];
% tds_check_valid(tds1);

%% dimensions of E,A,B1,C1,D11,B2,C2,D12,D21,D22 should be compatible
% % A-B1
% tds1=tds;
% tds1.A={2*eye(2),eye(2)};
% tds1.hA=[0 1];
% tds1.B1={1,2};
% tds1.hB1=[0 2];
% tds_check_valid(tds1);

% % B1-D11
% tds1=tds;
% tds1.B1={[2;1]};
% tds1.hB1=[0];
% tds1.D11={eye(2)};
% tds1.hD11=[0];
% tds_check_valid(tds1);

% % B2-D12
% tds1=tds;
% tds1.D12={1};
% tds1.hD12=0;
% tds_check_valid(tds1);

% B1-D21
% tds1=tds;
% tds1.D21={[1 2]};
% tds1.hD21=0;
% tds_check_valid(tds1);

% % B2 -D22
% tds1=tds;
% tds1.D22={eye(2)};
% tds1.hD22=1;
% tds_check_valid(tds1);

% tds1=tds;
% tds1.A={2*eye(2),eye(2)};
% tds1.hA=[0 1];
% tds1.E={1};
% tds1.hE=0;
% tds_check_valid(tds1);