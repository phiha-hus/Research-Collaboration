% E matrices
E0=[0.1 0.2;0.3 0.4]; E1=[1.1 1.2;1.3 1.4]; E2=[2.1 2.2;2.3 2.4]; E3=[3.1 3.2;3.3 3.4];
hE=[0 1 2 3];

% A matrices
A0=[4.1 4.2;4.3 4.4]; A1=[5.1 5.2;5.3 5.4]; A2=[6.1 6.2;6.3 6.4]; A3=[7.1 7.2;7.3 7.4];
hA=[4 5 6 7];

% B1 matrices
B10=[8.1 8.2;8.3 8.4]; B11=[9.1 9.2;9.3 9.4]; B12=[10.1 10.2;10.3 10.4]; B13=[11.1 11.2;11.3 11.4];
hB1=[8 9 10 11];

% C1 matrices
C10=[12.1 12.2;12.3 12.4]; C11=[13.1 13.2;13.3 13.4]; C12=[14.1 14.2;14.3 14.4]; C13=[15.1 15.2;15.3 15.4];
hC1=[12 13 14 15];

% D11 matrices
D110=[16.1 16.2;16.3 16.4]; D111=[17.1 17.2;17.3 17.4]; D112=[18.1 18.2;18.3 18.4]; D113=[19.1 19.2;19.3 19.4];
hD11=[16 17 18 19];

% B2 matrices
B20=[20.1 20.2;20.3 20.4]; B21=[21.1 21.2;21.3 21.4]; B22=[22.1 22.2;22.3 22.4]; B23=[23.1 23.2;23.3 23.4];
hB2=[20 21 22 23];

% C2 matrices
C20=[24.1 24.2;24.3 24.4]; C21=[25.1 25.2;25.3 25.4]; C22=[26.1 26.2;26.3 26.4]; C23=[27.1 27.2;27.3 27.4];
hC2=[24 25 26 27];

% D12 matrices
D120=[28.1 28.2;28.3 28.4]; D121=[29.1 29.2;29.3 29.4]; D122=[30.1 30.2;30.3 30.4]; D123=[31.1 31.2;31.3 31.4];
hD12=[28 29 30 31];

% D21 matrices
D210=[32.1 32.2;32.3 32.4]; D211=[33.1 33.2;33.3 33.4]; D212=[34.1 34.2;34.3 34.4]; D213=[35.1 35.2;35.3 35.4];
hD21=[32 33 34 35];

% D22 matrices
D220=[36.1 36.2;36.3 36.4]; D221=[37.1 37.2;37.3 37.4]; D222=[38.1 38.2;38.3 38.4]; D223=[39.1 39.2;39.3 39.4];
hD22=[36 37 38 39];

clear tds;
%% no input
% tds = tds_create() 

%% non-numeric inputs, sparse
% tds = tds_create({A0},'a') % error non-numeric delay
% tds = tds_create({'a'},1) % error non-numeric system matrix


% tds = tds_create({sparse([1 2;2 1])},1.5);
% tds = tds_create({sparse([1 2;2 1])});

%% tds only A
% tds = tds_create({A0}) % if delay is not given sets to zero
% tds = tds_create(A0) % error, system matrices are cell arrays
% tds = tds_create({A0},hA,hA) % error one system matrix is not given

% tds = tds_create({A0,A1,A2,A3},hA)

%% tds only E
% tds = tds_create({E0},'neutral')
% tds = tds_create(E0,'neutral') % error
% tds = tds_create({E0},hE,hE,'neutral') % error

% tds = tds_create({E0,E1,E2,E3},hE,'neutral')

%% tds E,A
% tds = tds_create({E0,E1},{A0,A1},'neutral') % no delay info
% tds = tds_create({E0,E1},hE(1:2),{A0,A1},hA(1:2),'neutral')

%% tds state & output eqns (A,B1,C1,D11)
% tds = tds_create({A0,A1,A2},hA(1:3),{B10,B11},hB1(1:2),{C10,C11,C12,C13},hC1,{D110},hD11(1))
% tds = tds_create({A0,A1,A2},hA(1:3),{B10,B11},hB1(1:2),{C10,C11,C12,C13},hC1,hD11(1)) % error no cons delays

%% tds state & output eqns (E,A,B1,C1,D11)
% tds = tds_create({E0,E1},hE(1:2),{A0,A1,A2},hA(1:3),{B10,B11},hB1(1:2),{C10,C11,C12,C13},hC1,{D110},hD11(1),'neutral')

%% tds state & dist & output equations (E,A,B1,C1,D11,B2,C2,D12,D21,D22)
% tds = tds_create({E0,E1,E2},hE(1:3),...
%                     {A0,A1,A2},hA(1:3),...
%                     {B10,B11},hB1(1:2),...
%                     {C10,C11,C12,C13},hC1,...
%                     {D110},hD11(1),...
%                     {B20},hB2(1),...
%                     {C20,C21,C23},hC2(1:3),...
%                     {D120,D121},hD12(1:2),...
%                     {D210,D211,D212},...
%                     {D220,D221},hD22(1:2),...
%                      'neutral')
                 
%% assign empty matrices D11,hD11 and D22, hD22
% tds = tds_create({E0,E1,E2},hE(1:3),...
%                     {A0,A1,A2},hA(1:3),...
%                     {B10,B11},hB1(1:2),...
%                     {C10,C11,C12,C13},hC1,...
%                     {},[],...
%                     {B20},hB2(1),...
%                     {C20,C21,C23},hC2(1:3),...
%                     {},[],...
%                     {D210,D211,D212},...
%                     {},[],...
%                      'neutral')                 