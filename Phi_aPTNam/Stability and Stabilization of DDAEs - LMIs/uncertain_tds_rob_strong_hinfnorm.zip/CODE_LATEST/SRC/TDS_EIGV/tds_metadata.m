function md = tds_metadata(tds)
% tds_metadata: creates metadata of LTI time-delay system. In particular,
%
%   tds_metadata(tds)

% The function computes:
%  * dimensions of system matrices
%  * number of system delays
%  * system type
% and metadata includes
%    md.nE  : the number of columns of E matrices (square matrices)
%    md.nA  : the number of columns of A matrices (square matrices)
%    md.nB1 : the number of columns of B1 matrices
%    md.nB2 : the number of columns of B2 matrices
%    md.nC1 : the number of rows of C1 matrices
%    md.nC2 : the number of rows of C2 matrices
%    md.mE  : the number of E matrices
%    md.mA  : the number of A matrices
%    md.mB1 : the number of B1 matrices 
%    md.mB2 : the number of B2 matrices 
%    md.mC1 : the number of C1 matrices 
%    md.mC2 : the number of C2 matrices
%    md.mD11: the number of D11 matrices
%    md.mD12: the number of D12 matrices 
%    md.mD21: the number of D21 matrices
%    md.mD22: the number of D22 matrices
%
% Example:
%    tds=tds_create({2*eye(3),eye(3)},[0 0],{4*eye(3),eye(3)},[0,1],'neutral');
%    md=tds_metadata(tds)

% set the system dimensions
if ~isstruct(tds)
    error('Time-delay system is not a struct');
end

fields_mat={'E','A','B1','B2','C1','C2','D11','D12','D21','D22'};
md=struct;

% compute dimensions of the system
% check E,A
for id=1:2
    if isempty(getfield(tds,fields_mat{id}))
        md = setfield(md,['n' fields_mat{id}],0);
    else
        tdsmat=getfield(tds,fields_mat{id});
        md = setfield(md,['n' fields_mat{id}],size(tdsmat{1},2));
    end
end

% check B1 & B2 columns (if empty check D11,D21 and D12, D22)
tmpid=4;
for id=3:4
    if isempty(getfield(tds,fields_mat{id}))
        if isempty(getfield(tds,fields_mat{id+tmpid}))
            if isempty(getfield(tds,fields_mat{id+tmpid+2}))
                md = setfield(md,['n' fields_mat{id}],0);
            else
                tdsmat=getfield(tds,fields_mat{id+tmpid+2});
                md = setfield(md,['n' fields_mat{id}],size(tdsmat{1},2));
            end
        else
            tdsmat=getfield(tds,fields_mat{id+tmpid});
            md = setfield(md,['n' fields_mat{id}],size(tdsmat{1},2));
        end                                        
    else
        tdsmat=getfield(tds,fields_mat{id});
        md = setfield(md,['n' fields_mat{id}],size(tdsmat{1},2));
    end
end


% check C1 & C2 rows (if empty check D11,D12 and D21, D22)
tmpid=2;
for id=5:6
    if isempty(getfield(tds,fields_mat{id})) 
        if isempty(getfield(tds,fields_mat{id+tmpid})) %#ok<*GFLD>
            if isempty(getfield(tds,fields_mat{id+tmpid+1}))
                md = setfield(md,['n' fields_mat{id}],0);
            else
                tdsmat=getfield(tds,fields_mat{id+tmpid+1});
                md = setfield(md,['n' fields_mat{id}],size(tdsmat{1},1));
            end
        else
            tdsmat=getfield(tds,fields_mat{id+tmpid});
            md = setfield(md,['n' fields_mat{id}],size(tdsmat{1},1));
        end                                        
    else
        tdsmat=getfield(tds,fields_mat{id});
        md = setfield(md,['n' fields_mat{id}],size(tdsmat{1},1));
    end
    tmpid=3;
end

% compute number of time-delays
for id=1:length(fields_mat)
    if isempty(getfield(tds,['h' fields_mat{id}])) % delay field does not exist        
        md = setfield(md,['m' fields_mat{id}],0); %#ok<*SFLD>
    else
        md = setfield(md,['m' fields_mat{id}],length(getfield(tds,['h' fields_mat{id}]))); 
    end
end


% set the system type
md.systype='';
if (md.nA~=0)
    if (md.mE==0) && (md.nE==0)
        md.systype='retarded';
    elseif (md.mE>0) && (md.nE>0)
        id0=find(tds.hE==0);
        nzeroDelays=length(id0);
        if (nzeroDelays>0)
            if (nzeroDelays==1)
                sumE=tds.E{1};
            else
                sumE=tds.E{id0(1)};
                for idt=2:nzeroDelays
                    sumE=sumE+tds.E{id0(idt)};
                end
            end
            rankE1=rank(sumE);
            
            if (rankE1==md.nE)
                if (md.mE==nzeroDelays)
                    md.systype='retarded';
                else
                    md.systype='neutral';
                end
            end
        end
    end
end

