function [f,grad]=tds_gamma_0(diff);



Dc=diff.Dc;




% 1 delay case
if length(diff.hD)==1, 



D=diff.D{1};

DDc=D*Dc;
no=length(DDc);

u=eig(DDc);
[m1,m2]=max(abs(u));
l=u(m2);

[U,S,V]=svd(DDc-l*eye(no));
u=U(:,no);
v=V(:,no);


%
% gamma_0 and sensitivity
% 


if l==0,
    f=0;
    grad=zeros(size(Dc));
else
    f=m1;
    grad=1/m1*real(conj(l)* (1/(u'*v)*transpose(u'*D)*transpose(v)));
end

%
% above: 1 delay
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% below: multiple delays
%



else % more then one delay in difference equation

    
% step 1: prediction    
    


no=length(diff.D{1}*Dc);   
ndels= length(diff.hD)-1; % math. delays= phys delays -1
radius=0;

 N=10; % even
    id=ones(1,ndels);
    th = linspace(0,2*pi,N+1);
    th = th(1:end-1);
    
    while (id(1)<(N/2+2)),
        M=diff.D{1};
        for k=1:ndels,
           M=M+diff.D{k+1}*exp(1i*th(id(k)));
        end
        u=eig(M*Dc);
        [m1,m2]=max(abs(u));
        if m1>radius,
           radius=m1;
           radiuseig=u(m2);
           radiusind=id;      
        end 
       
         id(end)=id(end)+1;
	    k=length(id);
		while (id(k)==N+1),
        id(k)=1;
        id(k-1)=id(k-1)+1;
        k=k-1;
        end		
    end

% result predictor:
% th(radiusind): critical theta
% radiuseig: critical eigenvalue
% radius: critical value


if radius==0,
    f=0;
    grad=zeros(size(Dc));
else




%
% step 2: corrector
%

% generating starting values for u and v


theta_s=th(radiusind); % cricital values of theta

 M=diff.D{1};
        for k=1:ndels,
           M=M+diff.D{k+1}*exp(1i*theta_s(k));
        end
[U,S,V]=svd(M*Dc-radiuseig*eye(no));
v_s=V(:,no); 
u_s=U(:,no);  u_s=u_s/conj(u_s'*v_s);


% real starting value for the solver

xstart=[real(v_s);imag(v_s);real(u_s);imag(u_s); real(radiuseig) ; imag(radiuseig)];
xstart=[xstart; transpose(theta_s)];

% solve the nonlinear system

warning off
oop.Display='off';
x=fsolve(@opt_fin,xstart,oop);
warning on

%B relchange=norm(x-xstart)/norm(x);
%B improvement=norm(feval(@opt_fin,xstart))-norm(feval(@opt_fin,x));
 

theta=x(4*no+3:4*no+2+ndels);
l=x(4*no+1)+1j*x(4*no+2);
m1=abs(l);

M=diff.D{1};
        for k=1:ndels,
           M=M+diff.D{k+1}*exp(1i*theta(k));
        end       
improvement=max(abs(eig(M*Dc)))-radius;



if (improvement<=0) % corrector did not work, rely on predictor
    m1=radius;
    l=radiuseig;
    theta=th(radiusind);
     M=diff.D{1};
        for k=1:ndels,
           M=M+diff.D{k+1}*exp(1i*theta(k));
        end
end






% outcome  corrector: m1 (spectral radius), l(critical eigenvalue), 
% theta (critical angles)








% step 3: gradient computation




[U,S,V]=svd(M*Dc-l*eye(no));
u2=U(:,no);
v2=V(:,no);


if l==0,
    f=0;
    grad=zeros(size(Dc));
else
    f=m1;
    grad=1/m1*real(conj(l)* (1/(u2'*v2)*transpose(u2'*M)*transpose(v2)));
end


end




end % end multiple delay case




% inline function for fsolve


function y=opt_fin(xopt)

v_f=xopt(1:no)+1j*xopt(no+1:2*no);
u_f=xopt(2*no+1:3*no)+1j*xopt(3*no+1:4*no);
lambda_f=xopt(4*no+1)+1j*xopt(4*no+2);
theta_f=xopt(4*no+3:4*no+2+ndels);
    
    
M_f=diff.D{1};
        for k=1:ndels,
           M_f=M_f+diff.D{k+1}*exp(1i*theta_f(k));
        end
block1=(M_f*Dc-lambda_f*eye(no))*v_f;
block2=((M_f*Dc)'-conj(lambda_f)*eye(no))*u_f;
block3= v_s'*v_f-1;
block4=u_f'*v_f-1;

y=[real(block1); imag(block1); real(block2); imag(block2); real(block3);imag(block3); real(block4);imag(block4)];

for k=1:ndels,
y=[y; imag( conj(lambda_f)*exp(1j*theta_f(k))*(u_f'*(diff.D{k+1}*Dc)*v_f) ) ];
end


end % inline function




end % original function


