function [eigenvalues]=compute_roots_DDAE(tds,options)


tds=tds_sort(tds);
tds=tds_compress(tds);
n2=length(tds.A{1});



if tds.hA(1)>0
    tds.hA=[0, tds.hA];
    WK={};
    WK{1}=zeros(n2,n2);
    for i=1:1:length(tds.A)
    WK{i+1}=tds.A{i};
    end
    tds.A=WK;
end
E=tds.E{1};



if length(tds.hA)==1, % NO DDE but an ODE 
    %fprintf('Warning: ****this is an ODE****\n')
    eigenvalues.l0=eig(tds.A{1},tds.E{1});
    eigenvalues.l1=eigenvalues.l0;
 
    
else    % Case of a 'real' delay differential equation



N_max=floor(options.max_size_eigenvalue_problem/n2-1);  
if isempty(options.minimal_real_part)
    options.minimal_real_part=-1/(max(tds.hA));
end

r=options.minimal_real_part;
max_it=options.newton_max_iterations;
tol=options.root_accuracy;






% commensurate delay check
tm=[];
if isempty(options.commensurate_basic_delay)==1
    tm=0;
else
tau_com=tds.hA/(options.commensurate_basic_delay);
for i=1:1:length(tau_com)
if abs(tau_com(i)-round(tau_com(i)))<1e-10
    tm=[tm, tau_com(i)];
end
end
end


m=length(tds.hA);

if length(tm)==length(tds.hA)
   type_of_delays='commensurate delays';
elseif m==2
    type_of_delays='one delay';
elseif m==3
    type_of_delays='two delays';
elseif m==4
    type_of_delays='three delays';
else 
    type_of_delays='more than three delays';
end



% warning - type_of_delays
if (strcmp(type_of_delays,'commensurate delays')==0) && (isempty(options.commensurate_basic_delay)==0)
    disp(['delays are not commensurate delays with option.commensurate_basic_delay =', num2str(options.commensurate_basic_delay)])
end




%
% treatment of highter delay case as commensurate delays
%

if length(type_of_delays)==22,
   %  max number of sweeps over [0, 2pi]
   NN=20;    
   tau_com=round(tds.hA/tds.hA(m)*NN);
   options.commensurate_basic_delay=tds.hA(m)/NN;
   type_of_delays='commensurate delays';
end









% scale the dde to the system of maximum delay =1
tau_s=tds.hA/tds.hA(m);
for i=1:1:length(tds.A)
    K{i}=tds.hA(m)*tds.A{i};
end
r=r*tds.hA(m);


% introduce a shift of the origin
B=K{1}+(-r)*E;
C=zeros(n2,n2,m-1);
for ii=1:1:m-1
    C(:,:,ii)=K{ii+1}*exp((-r)*tau_s(ii+1));
end




if options.fixN==0, % no heuristic needed if number of N fixed


%
% begin heuristic to determine N 
%
% Check shifted difference equation
gamma0test=0;
if (isempty(tds.hD)==0),
    diff.D=tds.D;
    diff.hD=tds.hD;
    diff.Dc=tds.Dc;
	for k=1:length(tds.hD),
		diff.D{k}=diff.D{k}*exp(-options.minimal_real_part*diff.hD(k));
	end
	[gamma0test,dummy]=tds_gamma_0(diff);
end



if gamma0test>=1,  % dichotomy C_D <> c
disp(['Warning: case C_D>c.']); 
disp(['Spectral discretization with 16 points (lowered if maximum size of eigenvalue problem is exceeded)']);
N=15;
else 




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=10; h=pi/p; factor=1.05*sin(pi/p); 
a_theta=[-0.2462 -0.2266 -0.2053 -0.2302 -0.2326 -0.2335 -0.2362 -0.2421 -0.2463 -0.2604 -0.2656 -0.2749 -0.2919 -0.3030 -0.3140 -0.3265 -0.3491 -0.3664 -0.3892 -0.4204 -0.4548 -0.4855 -0.5339 -0.5872 -0.6491 -0.7354 -0.8478 -0.9930 -1.1800 -1.4448 -1.9414 -2.7149 -3.0292];
b_theta=[0.9124 0.9123 0.9136 0.9165 0.9195 0.9234 0.9285 0.9345 0.9416 0.9501 0.9592 0.9698 0.9818 0.9947 1.0090 1.0249 1.0427 1.0620 1.0833 1.1069 1.1331 1.1614 1.1936 1.2289 1.2685 1.3132 1.3642 1.4231 1.4913 1.5731 1.6783 1.7867 1.8183];
theta=[0:pi/64:pi/2];
 
switch lower(type_of_delays)
    case 'one delay'
   gk=[];    
for k=1:1:p+1
    W=B;
    W=W+C(:,:,1)*exp(1i*(k-1)*h);
    f=eig(W,E)';
    gk=[gk,f];
end

    case 'two delays'
        gk=[];
 for k=1:1:p+1,
    for j=-(p-1):1:p,
        W=B;
        W=W+C(:,:,1)*exp(1i*(k-1)*h)+C(:,:,2)*exp(1i*j*h);
        f=eig(W,E)';
        gk=[gk,f];
    end
end
        
    case 'three delays'
        gk=[];
for k=1:1:p+1,
    for j=-(p-1):1:p,
        for s=-(p-1):1:p,
        W=B;
        W=W+C(:,:,1)*exp(1i*(k-1)*h)+C(:,:,2)*exp(1i*j*h)+C(:,:,3)*exp(1i*s*h);
        f=eig(W,E)';
        gk=[gk,f];
        end
    end
end




    case 'commensurate delays'
n_k=tau_com;
jhh=pi/(p*n_k(end));
gk=[];
for k=1:1:p*n_k(end)+1
     W=B;
       for l=1:1:m-1
           W=W+C(:,:,l)*exp(1i*(k-1)*jhh*n_k(l+1));
       end
       f=eig(W,E)';
       gk=[gk,f];
end

    
end     

gk=gk(abs(gk)<inf);
si=max(real(gk));



if si<=0, 
    N=0;
else %begin alternative
  
    points=[];
    for j=1:1:length(gk),
        if (real(gk(j))>=0) && (real(gk(j))<=factor*si),
            points=[ points gk(j)]; 
        end
    end
    
    theta_points=abs(angle(points));
    pp_a=spline(theta,a_theta,theta_points);
    pp_b=spline(theta,b_theta,theta_points);
    
    r_points=abs(points);
    N_gk=(r_points-pp_a)./pp_b;
    
    if isempty(N_gk),
       N1=0;
    else
       N1=max(N_gk);
    end
   
    
switch lower(type_of_delays)
    case 'one delay'
        gk=[];
for k=1:1:p+1
    W=B;
    W=W+C(:,:,1)*(exp(1i*(k-1)*h)*exp(-factor*si*tau_s(2)));
    f=eig(W,E)';
    gk=[gk,f];
end
gk=gk(gk<inf);
 
    case 'two delays'
        gk=[];
        
    for k=1:1:p+1,
        for j=-(p-1):1:p,
            W=B;
            W=W+C(:,:,1)*exp(1i*(k-1)*h)*exp(-factor*si*tau_s(2))+C(:,:,2)*exp(1i*j*h)*exp(-factor*si*tau_s(3));
            f=eig(W,E)';
            gk=[gk,f];
        end
    end
    gk=gk(gk<inf);

    case 'three delays'
        gk=[];
   for k=1:1:p+1,
        for j=-(p-1):1:p,
            for s=-(p-1):1:p,
            W=B;
            W=W+C(:,:,1)*exp(1i*(k-1)*h)*exp(-factor*si*tau_s(2))+C(:,:,2)*exp(1i*j*h)*exp(-factor*si*tau_s(3))+C(:,:,3)*exp(1i*s*h)*exp(-factor*si*tau_s(4));
            f=eig(W,E)';
            gk=[gk,f];
            end
        end
   end
   gk=gk(gk<inf);
   
    case 'commensurate delays'

   gk=[];

for k=1:1:p*n_k(end)+1
    W=B;
    for l=1:1:m-1
          W=W+C(:,:,l)*exp(1i*(k-1)*jhh*n_k(l+1))*exp(-factor*si*tau_s(l+1));
    end
    f=eig(W,E)';
    gk=[gk,f];
end
gk=gk(gk<inf);
   
   
end
gk=gk(gk<inf);

points=[];
    for j=1:1:length(gk),
        if  real(gk(j))>=factor*si && (real(gk(j))<inf),
        points=[ points gk(j)];       
        end
    end
    theta_points=abs(angle(points));
    pp_a=spline(theta,a_theta,theta_points);
    pp_b=spline(theta,b_theta,theta_points);
    r_points=abs(points);
    N_gk=(r_points-pp_a)./pp_b;
 
    if isempty(N_gk),
        N2=0;
    else
        N2=max(N_gk);
    end
 
  
 N=ceil(max(N1,N2));
 N=max(N,6);
 
 
 end % end alternative

 
 
 end % dichotomy C_D <> c
 
 
 
 
if N==0,
    N=min(20,N_max-1);
end    

if N>= N_max,
    disp(['Recommended number of discretization points exceeded maximum value.']) 
    afm=n2*(N_max+1);
    disp(['Discretization around zero with ',num2str(N_max+1),' points (size of eigenvalue problem: ',num2str(afm),'x',num2str(afm),').'])
    N=N_max;
end


% disp(['N= ',num2str(N)]);


else % end no heuristic needed if value of N is fixed
N=options.fixN;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

QQ=tds.A;
if N==N_max || options.fixN>0;
    QQ=K;
end
if N~=N_max
    QQ{1}=B;
end
if N~=N_max
    for i=2:1:m
        QQ{i}=C(:,:,i-1);
    end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
b=zeros(N+1,N+1);
b(1,:)=4*ones(1,N+1);
b(2,[1:3])=[2 0 -1];
for i=3:1:N
    b(i,[i-1:i+1])=[1/(i-1) 0 -1/(i-1)];
end
b(N+1,[N:N+1])=[1/N 0];
b=b/4;
Bpi_N=kron(b,eye(n2));
Bpi_N(1:n2,:)=kron(ones(1,N+1),E);


Sigma_N=eye(n2*(N+1));
Sigma_N(1:n2,1:n2)=zeros(n2,n2);
for k=1:1:N+1
    for j=1:1:m-1
    Sigma_N(1:n2,(k-1)*n2+1:k*n2)=Sigma_N(1:n2,(k-1)*n2+1:k*n2)+QQ{j+1}*chebpoly(k-1, -2*tau_s(j+1)+1);
    end
    Sigma_N(1:n2,(k-1)*n2+1:k*n2)=Sigma_N(1:n2,(k-1)*n2+1:k*n2)+QQ{1};
end
size_eigenvalue_problem=size(Sigma_N);
number_of_discretization_points=N+1;

u=eig(Sigma_N,Bpi_N);
u=u(abs(u)<inf);






% backsubstitution and re-scaling
if N~=N_max,
u=u-(-r)*ones(length(u),1);
end
u=u/tds.hA(m); 
[dummy,m2]=max(real(u)); maxpred=u(m2);
u=u(real(u)>=(r/tds.hA(m)));
eigenvalues.l0=u;



if isempty(u) 
    eigenvalues.l0=maxpred;
    u=maxpred;
end






% Newton corrections

warning off

 
 


uf=[];

for j=1:1:length(u)
l=u(j);
    


QM=zeros(n2,n2);
    for i=1:1:m
        QM=QM+tds.hA(i)*tds.A{i}*exp(-l*tds.hA(i));
    end
M=l*E-tds.A{1};
for ii=1:1:m-1
    M=M-tds.A{ii+1}*exp(-l*tds.hA(ii+1));
end
[U,S,V] = svd(M);
v_a=V(:,n2);
v=v_a;
F=M;




k=1;
while (k<=max_it) & norm(F*v)>=tol,
     J=[F (E+QM)*v;(v_a)' 0];
     a=J\[-F*v;-((v_a)'*v-1)];
     v=v+a(1:n2,1);
     l=l+a(n2+1,1);
     F=l*E-tds.A{1};
    for i=1:1:m-1
        F=F-tds.A{i+1}*exp(-l*tds.hA(i+1));
    end 
    QM=zeros(n2,n2);
    for i=1:1:m
        QM=QM+tds.hA(i)*tds.A{i}*exp(-l*tds.hA(i));
    end
    k=k+1;
end
    

if norm(F*v)<=tol
  uf=[uf l];
end
end
warning on

uh=[];
for i=1:1:length(uf)
    if (isnan(real(uf(i)))==0) & (isinf(real(uf(i)))==0)
        uh=[uh;uf(i)];
    end
end

eigenvalues.l1=uh;


end  % Case of a real delay differential equation









return;

























