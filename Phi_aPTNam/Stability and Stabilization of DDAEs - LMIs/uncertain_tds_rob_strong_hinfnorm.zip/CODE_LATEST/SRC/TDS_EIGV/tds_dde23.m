function [yv,tv]=tds_dde23(tds,phi,tlim, varargin)
%  tds_solve: solve the assoc. delay-differential equation 
%
%  [yv,tv]=tds_dde23(tds,phi,tlim)
%  [yv,tv]=tds_dde23(tds,phi,tlim,u)  
% 
%  The function integrates the delay-differential equation
%  associated with the time-delay system tds, e.g, for a single
%  delay retarded system,
%         x'(t)=A_0x(t)+A_1x(t-h)+ B1u(t,x)
%  tlim takes two values which specify the start and end time and
%  phi is a function handle corresponding to the history. The
%  optional parameter u is a function handle to the input in the
%  system. The function u=u(t,x) takes two parameters time t, and x
%  which is the current state. The approximations of the state at
%  time-points tv are returned in yv.
%  
%  This is a wrapper function for dde23. Parameters can be set with
%  ddeset. See dde23 for further parameter details. 
% 
%  Example:
%   tds=tds_create({rand(3)-2*eye(3),rand(3)/5},[0 1.3]); % often stable
%   [y,tv]=tds_dde23(tds,@(t) ones(3,1), [0 20]);
%   plot(tv,y); 
%   hold on; 
%   plot([-1.3,0],[1,1]);
% 
   
    tds_check_valid(tds);
    tds_assert_properties(tds,'lti','retarded',...
                          'delay-free B1'); % Unfortunately, dde23
                                            % can not handle
                                            % delayed feedback
    tds=tds_compress(tds);
    tds=tds_sort(tds);
    
    % Make sure we have a zero delay. (since dde23 requires it)
    if (tds.hA(1)~=0)
       tds.hA=[0,tds.hA];        
       A=tds.A;
       tds.A={zeros(size(tds.A{1})), A{:}};
    end
    
    if (length(varargin)>0) 
        u=varargin{1};
    else
        u=[]; % Default is no input
    end

    %% Solve the dde
    sol=dde23(@(T,Y,Z) dde_feval(tds,T,Y,Z,u), tds.hA(2:end), phi, tlim);
    yv=sol.y;
    tv=sol.x;
    
% Evaluate the RHS in a dde23-style
function y=dde_feval(tds,t,Y,Z,u)
    y=zeros(size(tds.hA,1),1);
    y=y+tds.E{1}\tds.A{1}*Y; % First delay is no delay
    for k=2:length(tds.hA)
        y=y+tds.E{1}\(tds.A{k}*Z(:,k-1));
    end
    if (isa(u,'function_handle')) % Otherwise presume input 0
        for k=1:length(tds.hB1)
        y=y+tds.B1{k}*u(t-tds.hB1(k),Y);
        end
    end
        
