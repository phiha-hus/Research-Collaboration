function [initial_vectors] = generate_scalar_uncertainties(varargin)
%GENERATE_SCALAR_UNCERTAINTIES (local) generates initialisation vectors for scalar uncertainties  
%
%   [initial_vectors] =  initialise_scalar_uncertainties('grid',m,t)
%   returns all possible initialisation vectors in grid with           
%   m the number of scalar uncertainties (dimension grid)
%   and t the number of grid points in each direction
%   (the number of initialisation vectors equals t^m)
%   eg. initialise_scalar_uncertainties('grid',2,3) returns
%   [-1 -1;0 -1;1 -1;-1 0;0 0;1 0;-1 1;0 1;1 1]
%
%   [initial_vectors] = initialise_scalar_uncertainties('randi',m,t,n)
%   returns randomly sampled initialisation vectors from grid with
%   m the number of scalar uncertainties (dimension grid),
%   t the number of grid points in each direction
%   and n the number of initialisation vectors to be generated
%   eg. initialise_scalar_uncertainties('randi',2,5,5) returns
%   [-1 0;-0.5 0.5; 0 -1; -1 0;0.5 0]
%   
%   [initial_vectors] = initialise_scalar_uncertainties('rand',m,n)randomly
%   sample initialisation vectors in [-1,1]^{m} 
%   with m the number of scalar uncertainties
%   and n number of initialisation vectors to be generated
%   eg. initialise_scalar_uncertainties('rand',3,3) returns
%   [0.2575 0.8143 0.3500; 0.8407 0.2435 0.1966; 0.2543 0.9293 0.2511]


inputparam = varargin;
method = inputparam{1};
if strcmp(method,'grid')
    if length(inputparam) ~= 3
        error('Wrong number of parameters. Expected 3 got %i.',length(inputparam));
    end
    m = inputparam{2}; t = inputparam{3};
    n = t^m; %  if 'grid' is used the number of initialisations can be calculated
    initial_vectors = zeros(n,m);
    int=linspace(-1,1,t); %grid points in one direction
    for i=1:n
       for j = 1:m
        p = mod(floor((i-1)/t^(j-1)),t)+1;
        initial_vectors(i,j)= int(p);
       end
    end
elseif (strcmp(method,'randi'))
    if length(inputparam) ~= 4
        error('Wrong number of parameters. Expected 4 got %i.',length(inputparam));
    end
    m = inputparam{2}; t = inputparam{3}; n = inputparam{4};
    int=linspace(-1,1,t); %grid points in one direction
    initial_vectors = int(randi(t,n,m));

elseif (strcmp(method,'rand'))
    if length(inputparam) ~= 3
        error('Wrong number of parameters. Expected 3 got %i.',length(inputparam));
    end
    m = inputparam{2}; n = inputparam{3};
    initial_vectors = -1+2*rand(n,m);
else
    error('Unknown method. Possible methods: grid, randi, rand');
end


end

    
