function [rob_strong_asympt_hinfnorm,crit_delta,nb_sv_calc] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(uncertain_tds,options)
%UNCERTAIN_TDS_ROB_STRONG_ASYMPT_HINFNORM_DDAE (local function) computes
%the robust strong asymptotic H-infinity norm and associated critical delta
%and theta of an uncertain ddae time-delay system using the projected
%gradient flow method.
%
% [rob_strong_asympt_hinfnorm] =
% uncertain_tds_rob_strong_asympt_hinfnorm_ddae(uncertain_tds)
% returns the robust strong asymptotic H-infinity norm of uncertain_tds
%
% [rob_strong_asympt_hinfnorm,crit_delta] =
% uncertain_tds_rob_strong_asympt_hinfnorm_ddae(uncertain_tds) returns also
% the associated critical delta.
%
% [rob_strong_asympt_hinfnorm,crit_delta,crit_theta,nb_sv_calc] = 
% uncertain_tds_rob_strong_asympt_hinfnorm_ddae(uncertain_tds) returns also
% the number of singular value computations needed by the algorithm.
%
% [..] = uncertain_tds_rob_strong_asympt_hinfnorm_ddae(uncertain_tds,options)
%  allows to specify additional options:
%       options.metadata_tds - metadata_tds associated with uncertain_tds
%       options.caution_level - influences number of initialisations
%       0 (small number of initialisations - default), 1, 2 (large number of initialisations)
%       options.print_level: 0 (quiet - default), 1 (result each initialisation), 2 (result each succesful step)
%       options.tol - Tolerance on 2-norm of the derivative of sigma1 with respect to
%          the elements of delta and theta (default - 1e-8)
%       options.left_E - left null space of the E matrix in uncertain_tds
%       options.right_E - right null space of the E matrix in uncertain_tds


%HIGH LEVEL DESCRIPTION
% Solve 
% max_{delta in hat{delta}} max_{theta in [0,2 Pi)^K} sigma1(Ta(delta,theta));
% where Ta(delta,theta) = S2*(P0_22(delta) + sum_{k=1}^{K} Pk_22(delta) exp(1j*theta_k))^{-1}R2
% with P0_22(delta) = [A0_22(delta) B0_2(delta) 0;0 -Im 0;C0_2(delta) D0(delta) -Ip]
%      Pk_22(delta) = [Ak_22(delta) Bk_2(delta) 0;0   0 0;Ck_2(delta) Dk(delta)   0]
%      R2 = [0_{n-rank(E) x m}; I_m; 0_{p x m}] 
%      S2 = [0_{p x n-rank(E)}  0_{p x m}  I_p]
% with Ak_22 = U^{H} Ak_22 V
%      Bk_2 = U^{H}B
%      Ck_2 = CV
% with hat{delta} = {delta in R^{q1 x r1} x ... x R^{qL x rL} : ||delta_l||_F <= bar{delta_l} };
% using gradient flow method with variables theta(t) and delta_l(t) = delta_l^n(t) bar{delta_l};
% 
% Resulting path?
% We choose
% delta_l^n'(t) = MAT_l(t) - <delta^{n}_l(t),MAT(t)>F delta^{n}_l if  ||delta^n_l||_F = 1 & <delta^{n}_l(t),MAT(t)>F > 0;
%               = MAT_l(t)                                        otherwise
% where MAT_l(t) = bar{delta_l}*sum_{k=0}^K sum_{s=1}^{S_l^k} Re([transp(G_{l,s}^{k})*conj(U(t))]*[transp(V(t))*H_{l,s}^{k}]*e^{j theta_k(t)});
%
% theta_k'(t) = -Im(U(t)^{H} P²²k(delta(t)) V(t) e^{j theta_k(t)})
% 
% with U^{H}(t) = u^{H}(t) S2 (P0_22(delta(t)) + sum_{k=1}^{K} Pk_22(delta(t)) e^{j*theta_k})^-1;
% and V(t) = (P0_22(delta(t)) + sum_{k=1}^{K} Pk_22(delta(t)) e^{j*theta_k})^-1*R2*v(t);
% where u(t) and v(t) are respectively the left and right singular vectors
% associated with sigma1(S2(P0_22(delta(t))+Pk_22(delta(t))e^{j theta_k(t)})^{-1}R2);
%
% Along this path sigma1(t) will monotonically increase as 
% d sigma1(S2 (P0_22(delta(t))+Pk_22(delta(t))e^{j theta_k(t)})^{-1}R2)/d t
%               = sum_{l=1}^L <delta^{n}_l'(t),MAT_l(t)>F;
%                  - sum_{k=1}^{K} theta_k'(t)*Im(U(t)' Pk_22(delta(t)) V(t) e^{j theta_k(t)})
% 
%STEP 0: Generate starting points for theta and scalar delta
%ITERATE 1: iterate over these starting points
%|  STEP 1: Compute the singular value decomposition of
%|         S2*(P0_22(delta^{init})+Pk_22(delta^{init})e^{j theta^{init}_k})^{-1}R2
%|         with delta^{init} = 0 for non-scalar delta
%|  ITERATE 2: iterate over rightmost singular values
%|  |  STEP 2: Initialise non scalar delta_l^n
%|  |          delta_l^{n,init} = sum_{k=0}^K sum_{s=1}^{S_l^K} Re([transp(G_{l,s}^{k})*conj(U_j)]*[transp(V_j)*H_{l,s}^{k}]*e^{j theta_k^{init}})
%|  |          where with U_j^{H} = u_j^{H} S2 (P0_22(delta^{init}) + sum_{k=1}^{K} Pk_22(delta^{init}) e^{j*theta_k^{init}})^-1;
%|  |          and V_j = (P0_22(delta^{init}) + sum_{k=1}^{K} Pk_22(delta^{init}) e^{j*theta_k^{init}})^-1*R2*v_j;
%|  |          where u_j and v_j are respectivelictly the left and right singular vectors associated with jth largest singular value;
%|  |  ITERATE 3: iterate until stopping criterium is fulfilled (or maximum number of iterations reached);
%|  |  |  |  STEP 3: delta_l^n(it+1) = normalise(delta_l^n(it) + h_{it+1}*dot_delta_l(it))
%|  |  |  |          theta_k(it+1)   = normalise(theta_k(it)   + h_{it+1}*dot_theta_k(it))
%|  |  |  |       where h_{it+1} a step size such that sigma1(delta_l,theta_k) increases;
%|  |  |  |       and dot_delta_l = delta_l^n'(it)
%|  |  |  |           dot_theta_k = -Im(U(delta^{it},theta^{it})'*P²²k(delta^{it})*V(delta^{it},theta^{it})*e^{j theta_k^{it}})
%|  |  |  |  STEP 4: compute sigma1^{it+1} = sigma1(delta_l^{it+1},theta_k^{it+1})
%|  |  |  Save resulting sigma1^{it+1}, delta_l^{it+1} and theta_k^{it+1} 
%|  Select maximal sigma1 over different initialisations

%PLANNED MODIFICATIONS:
% - support uncertainties on the delays
% - if advantageous (large uncertainties): exploit low rank structure of
% critical uncertainties

if nargin == 1
    options = struct();
end

[metadata_tds,left_null_E,right_null_E,print_level,tol,caution_level] = parse_options(options,uncertain_tds);
[development_options] = get_development_options();

assert(metadata_tds.ddae,'The system family uncertain_tds is of retarded type. Use UNCERTAIN_TDS_ROB_STRONG_ASYMPT_HINFNORM_RETARDED instead.')

% Generate associated asymptotic tranfer function and corresponding
% metadata
% Ta(s;delta,tau) = S2*(P0_22(delta) + sum_{k=1}^{K} Pk_22(delta) exp(-s*tau_k))^{-1}R2
% with P0_22(delta) = [A0_22(delta) B0_2(delta) 0;0 -Im 0;C0_2(delta) D0(delta) -Ip]
%      Pk_22(delta) = [Ak_22(delta) Bk_2(delta) 0;0   0 0;Ck_2(delta) Dk(delta)   0]
%      R2 = [0_{n-rank(E) x m}; I_m; 0_{p x m}] 
%      S2 = [0_{p x n-rank(E)}  0_{p x m}  I_p]
% with Ak_22 = U^{H} Ak_22 V
%      Bk_2 = U^{H}B
%      Ck_2 = CV
[asymptotic_tf,metadata_tf] = uncertain_tds2asymptotic_tf(uncertain_tds,metadata_tds,left_null_E,right_null_E);


K = metadata_tf.KP22;
L = metadata_tf.L;
p = metadata_tf.p;
m = metadata_tf.m;

crit_delta = cell(1,L);
for l = 1:L
    crit_delta{l} = zeros(asymptotic_tf.hat_delta(l).q,asymptotic_tf.hat_delta(l).r);
end

crit_theta = zeros(1,K);

nb_sv_calc = 0;
if K == 0
    rob_strong_asympt_hinfnorm = 0;
    return;
end

[P_nominal,~] = computeP(asymptotic_tf,metadata_tf,crit_delta,crit_theta);
[sv_all] = svd(asymptotic_tf.S2*(P_nominal\asymptotic_tf.R2));
rob_strong_asympt_hinfnorm = sv_all(1);
nb_sv_calc = nb_sv_calc+1;

% No uncertainties in asymptotic transfer function and only 1 direct feed
% trough term
if ~any(metadata_tf.delta_used) && K == 1
    return;
end
%% STEP 0: Generate starting points for theta and scalar delta 
q_list= [asymptotic_tf.hat_delta.q]; % List with number of rows of uncertaities
r_list= [asymptotic_tf.hat_delta.r]; % List with number of columns of uncertainties
[is_scalar,scalar_count,n_scalar] = check_scalar(q_list,r_list,metadata_tf.delta_used); % Check which perturbations are scalar


if (caution_level == 0)
    nb_sv_start = 3;  % Number of right most singular values to start from.
    nb_theta_gridpts_dim = 5; % Number of gridpoints in each dimension for theta
    scalar_cut_off = 3; % If there are less than scalar_cut_off scalar perturbations then generate complete. Otherwise sample grid using randi.
    nb_rand_scalar_points = 30; %Number of of sample points for randi.
elseif(caution_level == 1)
    nb_sv_start = 6;
    nb_theta_gridpts_dim = 9;
    scalar_cut_off = 4;
    nb_rand_scalar_points = 70;
else
    nb_sv_start =  10;
    nb_theta_gridpts_dim = 15;
    scalar_cut_off = infty;
    nb_rand_scalar_points = 0;
end
nb_sv_start = min([p,m,nb_sv_start]);

% generate starting points for delta
if (development_options.scalar_initialisations)
    if n_scalar <= scalar_cut_off
        scalar_initialisations = generate_scalar_uncertainties('grid',n_scalar,3);
    else
        scalar_initialisations = generate_scalar_uncertainties('randi',n_scalar,3,nb_rand_scalar_points);
    end
else
    scalar_initialisations = zeros(1,0);
end
dim_theta_grid = K-1;

% generate starting points for theta
theta_grid = cell(1,dim_theta_grid);
[theta_grid{:}] = ndgrid(linspace(0,2*pi,nb_theta_gridpts_dim));

dimension_search_grid = [size(scalar_initialisations,1),numel(theta_grid{1}),nb_sv_start];


%% ITERATE 1: iterate over these starting points
for scalar_iter=1:dimension_search_grid(1) 
    for theta_iter = 1:dimension_search_grid(2)
        
        %Initialise theta vector
        theta_init = zeros(1,K);
        for k = 1:dim_theta_grid
           theta_init(k+1) = theta_grid{k}(theta_iter); 
        end
        
        %Initialise scalar uncertainties
        scalar_init = scalar_initialisations(scalar_iter,:);
        delta_init = cell(1,L);
        for l = 1:L
            if (development_options.scalar_initialisations && is_scalar(l))
                delta_init{l} = scalar_init(scalar_count(l));
            else
                delta_init{l} = zeros(asymptotic_tf.hat_delta(l).q,asymptotic_tf.hat_delta(l).r);
            end
        end
        
%% STEP 1: Compute the singular value decomposition of S²*(P²²0(delta^{init})+P²²k(delta^{init})e^{j theta^{init}_k})R² with delta^{init} = 0 for non-scalar delta
% (Needed to initialise non-scalar uncertainties)
        [P_INIT,~] = computeP(asymptotic_tf,metadata_tf,delta_init,theta_init);
        [L_SV_INIT,~,R_SV_INIT] = svd(asymptotic_tf.S2*(P_INIT\asymptotic_tf.R2));
        nb_sv_calc = nb_sv_calc +1;
        
        % Initialise other uncertainties
        % delta_l = sum_{k=0}^K sum_{s=1}^{S_l^K} Re([transp(G_{l,s}^{k})*conj(U_j)]*[transp(V_j)*H_{l,s}^{k}]*e^{j theta_k^{init}})
        % where U_j^{H} = u_j^{H} S² (P²²0(delta^{init}) + sum_{k=1}^{K} P²²k(delta^{init}) e^{j*theta_k^{init}})^-1;
        % and V_j = (P²²0(delta^{init}) + sum_{k=1}^{K} P²²k(delta^{init}) e^{j*theta_k^{init}})^-1*R²*v_j;
        % with l_sv and r_sv the left and right singular vectors associated
        % with tge sv_iter largest singular value of
        %   M(delta,theta) = S²*(P²²0(delta^{init})+P²²k(delta^{init})e^{j theta^{init}_k})R²
        for sv_iter=1:nb_sv_start
            l_sv = L_SV_INIT(:,sv_iter);
            r_sv = R_SV_INIT(:,sv_iter);
            
            theta = theta_init;
            delta = delta_init;
            conj_U = transp((l_sv'*asymptotic_tf.S2)/P_INIT);
            V = P_INIT\(asymptotic_tf.R2*r_sv);
            
            for l=1:L
                if metadata_tf.delta_used(l) && (~is_scalar(l)  || ~development_options.scalar_initialisations)
                    delta_l = zeros(q_list(l),r_list(l));
                    for k = 1:K
                        if ~isempty(asymptotic.uP22{k})
                            idx_l = find([asymptotic.uP22{k}.l] == l); 
                            for s = idx_l
                                G = asymptotic_tf.uP22{k}(s).G;
                                H = asymptotic_tf.uP22{k}(s).H;
                                delta_l = delta_l+ real((transp(G)*conj_U)*transp(H*V)*exp(1j*theta(k))); 
                            end
                        end
                    end
                    norm_delta_l = norm(delta_l,'fro');
                    if (norm_delta_l ~= 0)
                       delta{l} = delta_l/norm_delta_l; 
                    end                    
                end
            end
            
            % Prepare inner iterations
            step = development_options.step_init; sigma_prev = -Inf;
            iter = 0; % Iteration count
            svd_calc_inner = 0;% Count svd calls in inner iteration
            [P,Pk] = computeP(asymptotic_tf,metadata_tf,delta,theta);
            [left_sv_all,sigma_all,right_sv_all] = svd(asymptotic_tf.S2*(P\asymptotic_tf.R2));
            nb_sv_calc = nb_sv_calc+1; svd_calc_inner = svd_calc_inner + 1;
            
            sigma = sigma_all(1);
            l_sv = left_sv_all(:,1); r_sv = right_sv_all(:,1);
            if (print_level >=2)
               fprintf('Scalar iteration %i/%i; Theta iteration %i/%i; SV iteration %i/%i \n', ...
                   scalar_iter,dimension_search_grid(1),theta_iter,dimension_search_grid(2),sv_iter,nb_sv_start);
               fprintf('STEP %i: sigma 1 = %12.6e\n',iter,sigma)
            end
            
            
            delta_next = cell(1,L);
            while iter < development_options.max_iter
                iter = iter+1;
                conj_U = transp((l_sv'*asymptotic_tf.S2)/P);
                V = P\(asymptotic_tf.R2*r_sv);
                dot_theta = calculate_dot_theta(Pk,conj_U,V,theta);
                dot_delta = calculate_dot_delta(asymptotic_tf,metadata_tf,delta,theta,conj_U,V);
                if development_options.stop == 1
                    STOP = stop_criterium(1,dot_delta,dot_theta,tol);
                else
                    STOP = stop_criterium(2,sigma,sigma_prev,tol);
                end
                if STOP
                    if (print_level>=2)
                        fprintf('Stopping criterium fulfilled \n');
                    end
                    break;
                end
                accepted = false; step_prev = step;

                while ~accepted && step>development_options.step_min
                    for l=1:L
                        delta_next{l} = delta{l}+step*dot_delta{l};
                        norm_delta_l = norm(delta_next{l},'fro');
                        if norm_delta_l > 1
                            delta_next{l} = delta_next{l}/norm_delta_l;
                        end
                    end
                    theta_next = mod(theta+step*dot_theta,2*pi);
                    [P_next,Pk_next] = computeP(asymptotic_tf,metadata_tf,delta_next,theta_next);
                    [left_sv_all,sigma_all,right_sv_all] = svd(asymptotic_tf.S2*(P_next\asymptotic_tf.R2));
                    nb_sv_calc = nb_sv_calc + 1; svd_calc_inner = svd_calc_inner + 1;
                    sigma_next = sigma_all(1,1);
                    if sigma_next > sigma
                        left_sv_next = left_sv_all(:,1); right_sv_next = right_sv_all(:,1);
                        accepted = true;
                        if (step == step_prev)
                            if (~development_options.maximize_step_size) % Increase step size for NEXT iteration
                                step = step*development_options.step_increase;
                            else %Increase step size for THIS iteration until sigma no longer increases
                                stop_inner_iterate = false;
                                delta_interm = cell(1,L);
                                while (~ stop_inner_iterate)
                                    step = step*development_options.step_increase;
                                    for l=1:L % Apply update to deltas
                                        delta_interm{l} = delta{l}+step*dot_delta{l};
                                        norm_delta_l = norm(delta_interm{l},'fro');
                                        if norm_delta_l > 1
                                            delta_interm{l} = delta_interm{l}/norm_delta_l;
                                        end
                                    end 
                                    theta_interm = mod(theta+step*dot_theta,2*pi); % Apply update to theta
                                    [P_interm,Pk_interm] = computeP(asymptotic_tf,metadata_tf,delta_interm,theta_interm);
                                    [left_sv_intermediate,sigma_intermediate,right_sv_intermediate] = svd(asymptotic_tf.S2*(P_next\asymptotic_tf.R2));
                                    nb_sv_calc = nb_sv_calc + 1; svd_calc_inner = svd_calc_inner + 1;
                                    sigma_interm = sigma_intermediate(1,1);
                                    if (sigma_interm > sigma_next)
                                        sigma_next = sigma_interm;
                                        P_next = P_interm;
                                        Pk_next = Pk_interm;
                                        left_sv_next = left_sv_intermediate(:,1);
                                        right_sv_next = right_sv_intermediate(:,1);
                                        delta_next = delta_interm;
                                        theta_next = theta_interm;
                                    else
                                        stop_inner_iterate = true;
                                    end
                                end
                            end
                        end
                        P = P_next; Pk = Pk_next;
                        delta = delta_next; theta = theta_next;
                        l_sv = left_sv_next;
                        r_sv = right_sv_next;
                        
                        sigma_prev = sigma;
                        sigma = sigma_next;
                        if(print_level>=2)
                            fprintf('STEP %i: sigma 1 = %12.6e - step size = %9.3e\n',iter,sigma,step);
                        end
                    else
                        step = step/development_options.step_reduction;
                    end
                    
                end
                if ~accepted
                   if print_level >= 2
                       fprintf('Step size too small. \n')
                   end
                   break;
                end
                
            end
        end
        if sigma > rob_strong_asympt_hinfnorm 
            rob_strong_asympt_hinfnorm = sigma;
            crit_delta = delta;
        end
        if (development_options.max_iter == iter)
            if (print_level >=2)
            	fprintf('Maximum number of iterations reached. \n') 
            end
        end
        if (print_level ==1)
            fprintf('Scalar iteration %i/%i; Theta iteration %i/%i; SV iteration %i/%i : sigma 1 = %12.3f - svd calls = %i \n', ...
               scalar_iter,dimension_search_grid(1),theta_iter,dimension_search_grid(2),sv_iter,nb_sv_start,sigma, svd_calc_inner);
        end
    end
end

end

function [metadata,left_null_E,right_null_E,print_level,tol,caution_level] = parse_options(options,uncertain_tds)
    if isfield(options,'metadata')
        metadata = options.metadata;
    else
        metadata = uncertain_tds_metadata(uncertain_tds);
    end
    if isfield(options,'left_null_E')
        left_null_E = options.left_null_E;
    else
        left_null_E = null(uncertain_tds.E');
    end
    if isfield(options,'right_null_E')
        right_null_E = options.right_null_E;
    else
        right_null_E = null(uncertain_tds.E);
    end
    if (isfield(options,'print_level'))
        print_level = options.print_level;
    else
        print_level = 0;
    end 
    if (isfield(options,'tol'))
        tol = options.tol;
    else     
        tol = 1e-8;
    end
    if (isfield(options,'caution_level'))
        caution_level = options.caution_level;
    else
        caution_level = 1;
    end
end

function [development_options] = get_development_options()
    development_options.maximize_step_size = true;
    development_options.step_min = 1e-16;
    development_options.step_init = 1;
    development_options.step_increase = 2;
    development_options.step_reduction = 3;
    development_options.scalar_initialisations = true;
    development_options.max_iter = 500;
    development_options.stop = 1;
end
function [STOP] = stop_criterium(varargin)
    %METHOD 1 stop_condition(1,dot_delta,dot_theta,tol)
    % ||GRAD_{delta,theta} sigma1||_F  < tol
    % with GRAD_{delta,theta} sigma1 = (VEC(dsigma1/ddelta_1),..,VEC(dsigma1/ddelta_L),dsigma1/dtheta1,..,dsigma1/dthetaK)
    % 
    % dsigma1/ddelta_l = delta_bar
    % dsigma1/dthetak = -Im(U^{H} P²²k(delta)V exp(j theta_k)
    if varargin{1} == 1
        dot_delta = varargin{2};
        dot_theta = varargin{3};
        tol = varargin{4};
        grad = dot_theta';
        for l=1:length(dot_delta)
            grad = [grad;reshape(dot_delta{l},[],1)];
        end
        norm_grad = norm(grad,'F');
        STOP = (norm_grad<tol);
    %METHOD 2 stop_condition(2,sigma,sigma_prev,tol)
    % abs(sigma-sigma_prev) < tol*max([1,abs(sigma)])
    elseif varargin{1} == 2
        sigma = varargin{2}; sigma_prev = varargin{3};
        tol = varargin{4};
        STOP = (abs(sigma-sigma_prev) < tol*max([1,abs(sigma)]));
    else
        error('Invalid stopping criterium chosen');
    end
end
function [P,Pk] = computeP(asymptotic_tf,metadata,delta,theta)
 K = metadata.KP22;
 P = zeros(metadata.n22,metadata.n22);
 Pk = cell(1,K);
 for k = 1:K 
     Pk{k} = asymptotic_tf.P22{k};
     for id1 = 1:length(asymptotic_tf.uP22{k})
         l = asymptotic_tf.uP22{k}(id1).l;
         G = asymptotic_tf.uP22{k}(id1).G;
         H = asymptotic_tf.uP22{k}(id1).H;
         Pk{k} = Pk{k}+asymptotic_tf.hat_delta(l).delta_bar*G*delta{l}*H;
     end
     P = P + Pk{k}*exp(1j*theta(k));
 end
end
function [dot_delta] = calculate_dot_delta(asymptotic_tf,metadata,delta,theta,conj_U,V)
    L = metadata.L;
    K = metadata.KP22;
    dot_delta = cell(1,L);
    for l = 1:L
        dot_delta{l}= zeros(asymptotic_tf.hat_delta(l).q, asymptotic_tf.hat_delta(l).r);
    end
    used = false(1,L);

    for k=1:K
        for id1 = 1:length(asymptotic_tf.uP22{k})
            l = asymptotic_tf.uP22{k}(id1).l;
            G = asymptotic_tf.uP22{k}(id1).G;
            H = asymptotic_tf.uP22{k}(id1).H;
            dot_delta{l} = dot_delta{l} - asymptotic_tf.hat_delta(l).delta_bar*real((G'*conj_U)*transp(H*V)*exp(1j*theta(k)));
            used(l) = true;
        end
    end
    for l=1:L
        if used(l)
            dot_delta{l} = asymptotic_tf.hat_delta(l).delta_bar*dot_delta{l};
            inner = sum(sum(delta{l}*dot_delta{l}));
            if norm(delta{l},'fro') >1-1e-8 &&  inner > 0
                dot_delta{l} = dot_delta{l} - inner*delta{l};
            end
        end
    end
end
function [dot_delta] = calculate_dot_theta(Pk,conj_U,V,theta)
    dim_theta_grid = length(theta);
    dot_delta = zeros(1,dim_theta_grid);
    for k=2:dim_theta_grid
        dot_delta(k) = imag(transp(conj_U)*Pk{k}*V*exp(1j*theta(k)));
    end
end