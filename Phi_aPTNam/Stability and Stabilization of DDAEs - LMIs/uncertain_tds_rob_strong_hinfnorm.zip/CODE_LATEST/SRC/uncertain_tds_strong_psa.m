function [psa,crit_delta,crit_lambda,crit_phi,crit_psi,output] = uncertain_tds_strong_psa(uncertain_tds,options)
%UNCERTAIN_TDS_STRONG_PSA Computes the strong hat{delta}-pseudo spectral
%abscissa of an uncertain time-delay system in ddae form


error('Not implemented yet.')
end

