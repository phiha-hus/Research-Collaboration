function [metadata] = uncertain_tds_metadata(uncertain_tds)
%UNCERTAIN_TDS_METADATA(local function) generates metadata associated with
%uncertain_tds. 
%   [metadata_sdep] = uncertain_tds_metadata(uncertain_sdep) generates
%   metadata associated with uncertain_tds. The output argument metadata is
%   a struct array with the following fields 
%       ddae - boolean indicating whether system is in ddae form
%       delay_free - boolean indicating whether system is delay-free
%       if delay_free
%           A_sparse - boolean indicating whether A matrix is sparse
%       KA - number of A matrices
%       KB - number of B matrices
%       KC - number of C matrices
%       KD - number of D matrices
%       n  - dimension state vector 
%       m  - dimension input vector
%       p  - dimension output vector
%       L  - number of uncertainties

metadata = {};

% Check if system is in ddae form
if isempty(uncertain_tds.E)
    metadata.ddae = false;
else
    metadata.ddae = true;
end

% Compute number of A/B/C/D matrices
metadata.KA = length(uncertain_tds.A);
metadata.KB = length(uncertain_tds.B);
metadata.KC = length(uncertain_tds.C);
metadata.KD = length(uncertain_tds.D);

fields = {'A','B','C','D'};
delay_free = true;
for i=1:length(fields)
    if metadata.(['K' fields{i}]) > 1 || (metadata.(['K' fields{i}]) == 1 && uncertain_tds.(['h' fields{i}]) ~= 0)
        delay_free = false;
        break;
    end
end
if delay_free
    metadata.delay_free = true;
    metadata.A_sparse = ~isempty(uncertain_tds.A) && issparse(uncertain_tds.A{1});
else
    metadata.delay_free = false;
    metadata.A_sparse = false;
end

% Find n (dimension state vector)
if metadata.KA > 0
    metadata.n = size(uncertain_tds.A{1},1);
elseif metadata.KB > 0
    metadata.n = size(uncertain_tds.B{1},1);
elseif metadata.KC > 0
    metadata.n = size(uncertain_tds.C{1},2);
else
    metadata.n = 0;
end
% Find m (dimension input vector)
if metadata.KB > 0 
    metadata.m = size(uncertain_tds.B{1},2);
elseif metadata.KD
    metadata.m = size(uncertain_tds.D{1},2);
else
    metadata.m = 0;
end
% Find p (dimension output vector)
if metadata.KC > 0
    metadata.p = size(uncertain_tds.C{1},1);
elseif metadata.KD > 0
    metadata.p = size(uncertain_tds.D{1},1);
else
    metadata.p = 0;
end 

if isfield(uncertain_tds,'hat_delta') && ~isempty(uncertain_tds.hat_delta)
    metadata.L = length(uncertain_tds.hat_delta);
else
    metadata.L = 0; 
end

end

