function [rob_strong_asympt_hinfnorm,crit_delta,nb_sv_calc] = uncertain_tds_rob_strong_asympt_hinfnorm_retarded(uncertain_tds,options)
%UNCERTAIN_TDS_ROB_STRONG_ASYMPT_HINFNORM_RETARDED (local function)
%computes the robust strong asymptotic H-infinity norm and associated
%critical delta and theta of an uncertain retarded time-delay system using
%the projected gradient flow method.
%
% [rob_strong_asympt_hinfnorm] =
% uncertain_tds_rob_strong_asympt_hinfnorm_retarded(uncertain_tds)
% returns the robust strong asymptotic H-infinity norm of uncertain_tds
%
% [rob_strong_asympt_hinfnorm,crit_delta] =
% uncertain_tds_rob_strong_asympt_hinfnorm_retarded(uncertain_tds)
% returns also the associated critical delta
%
% [rob_strong_asympt_hinfnorm,crit_delta,crit_theta,nb_sv_calc] =
% uncertain_tds_rob_strong_asympt_hinfnorm_retarded(uncertain_tds)
% also returns the number of singular value calculations needed by the
% algorithm
%
%[...] =
% uncertain_tds_rob_strong_asympt_hinfnorm_retarded(uncertain_tds,options)
% allows to specify additional options:
%       options.metadata_tds - metadata_tds associated with uncertain_tds
%       options.caution_level - influences number of initialisations
%       0 (small number of initialisations - default), 1, 2 (large number of initialisations)
%       options.print_level: 0 (quiet - default), 1 (result each initialisation), 2 (result each succesful step)
%       options.tol - Tolerance on 2-norm of the derivative of sigma1 with respect to
%          the elements of delta and theta (default - 1e-8)



%HIGH LEVEL DESCRIPTION
% Solve
% max_{delta in hat{delta}} max_{theta in [0,2 Pi)^K} sigma1(D0(delta) + \sum_{k=1}^K Dk(delta) exp(j\theta_k));
% with hat{delta} = {delta in R^{q1 x r1} x ... x R^{qL x rL} : ||delta_l||_F <= bar{delta_l} };
% using the projected gradient flow method with variables theta(t) and
% delta_l(t) = delta_l^n(t) bar{delta_l};
%
% Resulting path?
% We choose
% delta_l^n'(t) = MAT_l(t) - <delta^{n}_l(t),MAT(t)>F delta^{n}_l if  ||delta^n_l||_F = 1 & <delta^{n}_l(t),MAT(t)>F > 0;
%               = MAT_l(t)                                        otherwise
% where MAT_l(t) = bar{delta_l}*sum_{k=1}^K sum_{s=1}^{S_l^Dk}
%       transp(G_{l,s}^{k})*Re(u(t)*v(t)^{H}*e^{-j theta_k(t)})*transp(H_{l,s}^{k});
%
% theta_k'(t) = -Im(u(t)^{H}Dk(delta(t))v(t) e^{j theta_k(t))
%
% where u(t) and v(t) are respectively the left and right singular vectors
% associated with sigma1(D0(delta(t)) + \sum_{k=1}^K Dk(delta(t)) exp(j\theta_k(t)));
%
%STEP 0: Generate starting points for theta and scalar delta
%ITERATE 1: iterate over these starting points
%|  STEP 1: Compute the singular value decomposition of
%|         D0(delta^{init})+\sum_{k=1}^K Dk(delta^{init})e^{j theta^{init}_k})
%|         with delta^{init} = 0 / random for non-scalar delta
%|  ITERATE 2: for j = 1:nb_sv_start
%|  |  STEP 2: Initialise delta_l^n
%|  |          delta_l^{n,init} = sum_{k=1}^K sum_{s=1}^{S_l^Dk} transp(G_{l,s}^{k})*Re(u_j*v_j^{H}*e^{-j theta_k(init)})*transp(H_{l,s}^{k});
%|  |          where u_j and v_j are respectivelictly the left and right singular vectors associated with jth largest singular value;
%|  |  ITERATE 3: iterate until stopping criterium is fulfilled (or maximum number of iterations reached);
%|  |  |  STEP 3: delta_l^n(it+1) = normalise(delta_l^n(it) + h_{it+1}*dot_delta_l(it))
%|  |  |  |       theta_k(it+1)   = normalise(theta_k(it)   + h_{it+1}*dot_theta_k(it))
%|  |  |  |       where h_{it+1} a step size such that objective function increases;
%|  |  |  |       and dot_delta_l and dot_theta_k as defined before
%|  |  |  STEP 4: compute sigma1^{it+1} and associated left and right
%|  |  |  |          singular values
%|  |  CONDITIONAL If resulting sigma1 higher than current estimate |||Ta|||
%|  |  |  Update |||Ta|||, crit_delta and crit_theta




if (nargin == 1)
    options = struct();
end


[caution_level,print_level,metadata,tol] = parse_options(options,uncertain_tds);

assert(~metadata.ddae,'The system family uncertain_tds is of ddae type. Use UNCERTAIN_TDS_ROB_STRONG_ASYMPT_HINFNORM_DDAE instead.')


%Initialise singular value computation counter
nb_sv_calc = 0;

%Initialise critical delta (all zero matrices)
crit_delta = cell(1,metadata.L);
for l = 1:metadata.L
    crit_delta{l} = zeros(uncertain_tds.hat_delta(l).q,uncertain_tds.hat_delta(l).r);
end

% If there are no direct feed through terms (D matrices) then
% |||Ta|||_{H-infty}^{hat_delta} = 0
if metadata.KD == 0
    rob_strong_asympt_hinfnorm = 0;
    return;
end

% Find the delta that are present in asymptotic transfer function
% D1(delta)+\sum_{k=2}^K D_k(delta) exp(j\theta_k)
[delta_used,l_delta_used,l_new] = find_delta_used(uncertain_tds.hat_delta,uncertain_tds.uD,metadata.L);


K = metadata.KD; % Number of direct feedthrough terms
L = length(delta_used); % Number of active uncertainties
p = metadata.p;
m = metadata.m; % Dimension D: p x m

development_options = get_development_options();

crit_theta = zeros(1,K);
% Compute sigma1(D0(0) + \sum_{k=1}^K Dk(0))
[~,rob_strong_asympt_hinfnorm,~] = computeSVD(uncertain_tds,delta_used,l_new,crit_delta(l_delta_used),crit_theta,1,false);
nb_sv_calc = nb_sv_calc+1;

% No uncertainties in asymptotic transfer function and only 1 direct feed
% trough term
if isempty(delta_used) && metadata.KD == 1
    return;
end




%% STEP 0: Generate starting points for theta and delta
q_list= [delta_used.q]; % List with number of rows of uncertaities
r_list= [delta_used.r]; % List with number of columns of uncertainties

%Find scalar perturbations
if ~isempty(delta_used)
    is_scalar = (q_list==1) & (r_list == 1);
    scalar_idx = cumsum(is_scalar);
    n_scalar = scalar_idx(end);
    scalar_idx(~is_scalar) = 0;
else
    is_scalar = [];scalar_idx = []; n_scalar = 0;
end
% Number of different initialisations
if (caution_level == 0)
    nb_sv_start = 3;  % Number of right most singular values to start from
    nb_theta_gridpts_dim = 5; % Number of gridpoints in each dimension for theta
    scalar_cut_off = 3; % If there are less than scalar_cut_off scalar delta then generate all possibilities. Otherwise use randi
    nb_rand_scalar_points = 30; %If randi is used: number of scalar starting points
    nb_rand_non_scalar = 3; % Number random initialisations for non scalar delta
elseif(caution_level == 1)
    nb_sv_start = 6;
    nb_theta_gridpts_dim = 9;
    scalar_cut_off = 4;
    nb_rand_scalar_points = 70;
    nb_rand_non_scalar = 5;
else
    nb_sv_start =  10;
    nb_theta_gridpts_dim = 15;
    scalar_cut_off = infty;
    nb_rand_scalar_points = 0;
    nb_rand_non_scalar = 10;
end
nb_sv_start = min([p,m,nb_sv_start]);
if L-n_scalar == 0 % No non-scalar perturbations
    nb_rand_non_scalar = 1; % So no need to random initialise them
end
% generate starting points for scalar uncertainties
if (development_options.scalar_initialisations)
    if n_scalar <= scalar_cut_off
        scalar_initialisations = generate_scalar_uncertainties('grid',n_scalar,2);
    else
        scalar_initialisations = generate_scalar_uncertainties('randi',n_scalar,nb_rand_scalar_points,2);
    end
else
    scalar_initialisations = zeros(1,0);
end

% generate grid for theta
theta_grid = cell(1,K-1);
[theta_grid{:}] = ndgrid(linspace(0,2*pi,nb_theta_gridpts_dim));

if isempty(theta_grid)
    size_theta_grid = 1; % Number of points in theta_grid
else
    size_theta_grid = numel(theta_grid{1});
end
% Size of search grid
size_search_grid = [size(scalar_initialisations,1) size_theta_grid nb_rand_non_scalar nb_sv_start];


%% ITERATE 1: iterate over these starting points
for scalar_iter = 1:size_search_grid(1) % Iterate over all scalar starting points
    for theta_iter = 1:size_search_grid(2) % Iterate over all theta starting points
        for non_scalar_iter = 1:size_search_grid(3) % Iterate over all non-scalar starting points
            
            % Initialise theta vector
            theta_init = zeros(1,K);
            for k=1:K-1
                theta_init(k+1) = theta_grid{k}(theta_iter);
            end
            
            % Initialisation scalar uncertainties
            scalars_init = scalar_initialisations(scalar_iter,:);
            delta_init = cell(1,L);
            for l=1:L
                if (development_options.scalar_initialisations && is_scalar(l))
                    delta_init{l} = scalars_init(scalar_idx(l));
                else
                    if non_scalar_iter == 1 % On first non_scaler_iter initialise with zero
                        delta_init{l} = zeros(q_list(l),r_list(l));
                    else % On other non_scalar_iter initialse randomly
                        delta_init{l} = rand(q_list(l),r_list(l));
                        norm_delta_l = norm(delta_init{l},'fro');
                        if  norm_delta_l~=0
                            delta_init{l} = delta_init{l}/norm_delta_l;
                        end
                    end
                end
            end
            
            %% STEP 1 Compute singular value decomposition of D0(delta^{init}) +  \sum_{k=1}^K Dk(delta^{init}) exp(j\theta_k^{init}));
            [L_SV_INIT,~,R_SV_INIT] = computeSVD(uncertain_tds,delta_used,l_new,delta_init,theta_init,nb_sv_start,development_options.use_svds);
            nb_sv_calc = nb_sv_calc +1;
            
            %% ITERATE 2 Start from different rightmost singular values
            for sv_iter=1:nb_sv_start
                theta = theta_init;
                delta = delta_init;
                left_sv = L_SV_INIT(:,sv_iter);
                right_sv = R_SV_INIT(:,sv_iter);
                
                
                
                %% STEP 2 Initialise delta_l^n
                % delta_l^n = sum_{k=1}^{K} sum_{s=1}^{S_l^k} G{l,s}^{k}.' L_SV THETA_k R_SV' H_{l,s}^{k} / ||...||_F
                % where THETA_k = [real(e^{j theta_k}) -imag(e^{j theta_k}); imag(e^{j theta_k}) real(e^{j theta_k})]
                % L_SV = [real(l_sv) imag(l_sv)], R_SV = [real(r_sv) imag(r_sv)]
                % with l_sv and r_sv the left and right singular vectors associated
                % with the sv_iter largest singular value of
                %    D0(delta^{init}) +  sum_{k=1}^{K} Dk(delta^{init}) e^{j theta_k^{init}}
                THETA = cell(1,K);
                THETA{1} = eye(2);
                for k = 2:K
                    THETA{k} = [real(exp(1j*theta_init(k))) -imag(exp(1j*theta_init(k))); ...
                        imag(exp(1j*theta_init(k))) real(exp(1j*theta_init(k)))];
                end
                
                LEFT_SV = [real(left_sv) imag(left_sv)];
                RIGHT_SV = [real(right_sv) imag(right_sv)];
                for l=1:L
                    delta_l = zeros(q_list(l),r_list(l));
                    original_l = find(l_new == l); % Compute original index of delta_used_l in delta
                    for k = 1:K
                        if ~isempty(uncertain_tds.uD{k})
                            list_s = find([uncertain_tds.uD{k}.l] == original_l); % Find indices of all elements in uD that ise this uncertainty
                            for s = list_s
                                G = uncertain_tds.uD{k}(s).G;
                                H = uncertain_tds.uD{k}(s).H;
                                delta_l = delta_l+ (G'*LEFT_SV)*THETA{k}*(H*RIGHT_SV)';
                            end
                        end
                    end
                    norm_delta_l = norm(delta_l,'fro');
                    if (norm_delta_l ~= 0)
                        delta{l} = delta_l/norm_delta_l;
                    end
                end
                 
                
                nb_sv_calc_init = 0; % Number of svd calls for this initialisation
                [left_sv,sigma,right_sv] = computeSVD(uncertain_tds,delta_used,l_new,delta,theta,1,development_options.use_svds);
                nb_sv_calc = nb_sv_calc + 1; nb_sv_calc_init = nb_sv_calc_init+1;
                
                if (print_level >=2)
                    fprintf('Scalar iteration %i/%i; Theta iteration %i/%i; Non-Scalar iteration %i/%i; SV iteration %i/%i \n', ...
                        scalar_iter,size_search_grid(1),theta_iter,size_search_grid(2),non_scalar_iter,size_search_grid(3),sv_iter,nb_sv_start);
                    fprintf('STEP 0: sigma 1 = %12.6e\n',sigma)
                end
                
                iter = 1; % Iteration count
                step = development_options.step_init;
                sigma_prev = -Inf;
                while (iter <= development_options.max_iter)
                    %% STEP 3: 
                    %delta_l^n(it+1) = normalise(delta_l^n(it) + h_{it+1}*dot_delta_l(it))
                    %theta_k(it+1)   = normalise(theta_k(it)   + h_{it+1}*dot_theta_k(it))
                    %where h_{it+1} a step size such that objective function increases;
                    % and dot_delta_l and dot_theta_k as defined before
                    dtheta = calculate_dtheta(uncertain_tds,delta_used,l_new,delta,theta,left_sv,right_sv); % calculate dtheta
                    ddelta = calculate_ddelta(uncertain_tds,delta_used,l_new,delta,theta,left_sv,right_sv,development_options.path); % calculate ddelta
                    
                    % Check if stopping criterium is fulfilled
                    if development_options.stop == 1
                        STOP = stop_criterium(1,ddelta,dtheta,tol);
                    else
                        STOP = stop_criterium(2,sigma,sigma_prev,tol);
                    end
                    if (STOP)
                        if (print_level>=2)
                            fprintf('Stopping criterium fulfilled \n');
                        end
                        break;
                    end
                    
                    % Find new step size
                    accepted = false; step_prev = step;
                    delta_next = delta;
                    while(~accepted && step>development_options.step_min)
                        for l=1:L 
                            delta_next{l} = delta{l}+step*ddelta{l};
                            norm_deltal = norm(delta_next{l},'fro');
                            if (norm_deltal > 1)
                                delta_next{l} = delta_next{l}/norm_deltal;
                            end
                        end  
                        theta_next = mod(theta+step*dtheta,2*pi); 
                        
                        [left_sv_next,sigma_next,right_sv_next] = computeSVD(uncertain_tds,delta_used,l_new,delta_next,theta_next,1,development_options.use_svds);
                        nb_sv_calc = nb_sv_calc + 1; nb_sv_calc_init = nb_sv_calc_init + 1;
                        
                        if (sigma_next > sigma)       
                            accepted = true;
                            if (step == step_prev) % Succesful on first try
                                if (~development_options.maximize_step_size) % Increase step size for NEXT iteration
                                    step = step*development_options.step_increase;
                                else %Increase step size for THIS iteration until sigma no longer increases
                                    stop_inner_iterate = false;
                                    delta_interm = delta_next;
                                    while (~ stop_inner_iterate)
                                        step = step*development_options.step_increase;
                                        for l=1:L 
                                            delta_interm{l} = delta{l}+step*ddelta{l};
                                            norm_deltal = norm(delta_interm{l},'fro');
                                            if (norm_deltal > 1)
                                                delta_interm{l} = delta_interm{l}/norm_deltal;
                                            end
                                        end
                                        theta_interm = mod(theta+step*dtheta,2*pi); % Apply update to theta
                                        [left_sv_interm,sigma_interm,right_sv_interm] = computeSVD(uncertain_tds,delta_used,l_new,delta_interm,theta_interm,1,development_options.use_svds);
                                        nb_sv_calc = nb_sv_calc + 1; nb_sv_calc_init = nb_sv_calc_init + 1;
                                        
                                        if (sigma_interm > sigma_next)
                                            sigma_next = sigma_interm;
                                            left_sv_next = left_sv_interm;
                                            right_sv_next = right_sv_interm;
                                            delta_next = delta_interm;
                                            theta_next = theta_interm;
                                        else
                                            stop_inner_iterate = true;
                                        end
                                    end
                                end
                            end
                            sigma_prev = sigma;
                            sigma = sigma_next; delta = delta_next; theta = theta_next;
                            left_sv = left_sv_next; right_sv = right_sv_next;
                            if(print_level>=2)
                                fprintf('STEP %i: sigma 1 = %12.6e - step size = %9.3e\n',iter,sigma,step);
                            end
                        else
                            step = step/development_options.step_reduction; % Current step did not increase sigma1. Try smaller step.
                        end
                    end
                    if (~accepted) % minimal step size reached
                        if print_level >= 2
                            fprintf('Step size too small \n')
                        end
                        break;
                    end
                    iter = iter+1;
                end
                %CONDITIONAL If resulting sigma1 higher than current estimate |||Ta|||
                % Update |||Ta|||, crit_delta and crit_theta
                if sigma > rob_strong_asympt_hinfnorm
                    rob_strong_asympt_hinfnorm = sigma;
                    crit_delta(l_delta_used) = delta;
                    crit_theta = theta;
                end
                if (iter == development_options.max_iter) % stopped because maximum number of iterations was reached
                    if (print_level >=2)
                        fprintf('Maximum number of iterations reached. \n')
                    end
                end
                if (print_level ==1)
                    fprintf('Scalar iteration %i/%i; Theta iteration %i/%i; SV iteration %i/%i : sigma 1 : %12.3e svd calls: %i \n', ...
                        scalar_iter,size_search_grid(1),theta_iter,size_search_grid(2),sv_iter,nb_sv_start,sigma, nb_sv_calc_init);
                end
            end
        end
    end
end

end

function [ddelta] = calculate_ddelta(uncertain_tds,delta_used,l_new,delta,theta,left_sv,right_sv,path)
% delta_l^n'(t) = MAT_l(t) - <delta^{n}_l(t),MAT(t)>F delta^{n}_l if  ||delta^n_l||_F = 1 & <delta^{n}_l(t),MAT(t)>F > 0;
%               = MAT_l(t)                                        otherwise
% with MAT_l(t) = bar{delta_l}*sum_{k=1}^K sum_{s=1}^{S_l^Dk}
%       transp(G_{l,s}^{k})*Re(u(t)*v(t)^{H}*e^{-j theta_k(t)})*transp(H_{l,s}^{k});
L = length(delta);
ddelta = cell(1,L);
for l=1:L
    ddelta{l} = zeros(delta_used(l).q,delta_used(l).r);
end

R_SV = [real(right_sv) imag(right_sv)];
L_SV = [real(left_sv) imag(left_sv)];

% Compute MAT_l
for k = 1:length(uncertain_tds.D)
    THETA_k = [real(exp(1j*theta(k))) -imag(exp(1j*theta(k))); ...
        imag(exp(1j*theta(k)))  real(exp(1j*theta(k)))];
    INTERMEDIATE = L_SV*THETA_k*R_SV';
    for idx = 1: length(uncertain_tds.uD{k})
        l = l_new(uncertain_tds.uD{k}(idx).l);
        G = uncertain_tds.uD{k}(idx).G;
        H = uncertain_tds.uD{k}(idx).H;
        ddelta{l} = ddelta{l} + (G'*INTERMEDIATE*H');
    end
end
% Projection
for l=1:L
    ddelta{l} = delta_used(l).delta_bar*ddelta{l};
    if path == 1
        inner  = sum(sum(delta{l}.*ddelta{l}));
        ddelta{l} = ddelta{l}-inner*delta{l};
    elseif path == 2
        ddelta{l} = ddelta{l};
    else 
        inner  = sum(sum(delta{l}.*ddelta{l}));
        if (norm(delta{l},'fro') >1-1e-8 && inner >0)
            ddelta{l} = ddelta{l} - inner*delta{l};
        else
            ddelta{l} = ddelta{l};
        end
    end
end
end

function [dtheta] = calculate_dtheta(uncertain_tds,delta_used,l_new,delta,theta,left_sv,right_sv)
% theta_k'(t) = -Im(u(t)^{H}Dk(delta(t))v(t) e^{j theta_k(t))
K = length(uncertain_tds.D);
dtheta = zeros(1,K);
for k = 2:K
    uH_tildeDk_v = left_sv'*uncertain_tds.D{k}*right_sv;
    for id = 1:length(uncertain_tds.uD{k})
        l = l_new(uncertain_tds.uD{k}(id).l);
        G = uncertain_tds.uD{k}(id).G;
        H = uncertain_tds.uD{k}(id).H;
        uH_tildeDk_v = uH_tildeDk_v + delta_used(l).delta_bar*(left_sv'*G)*delta{l}*(H*right_sv);
    end
    dtheta(k) = -imag(uH_tildeDk_v*exp(1j*theta(k)));
end
end

function [STOP] = stop_criterium(varargin)
%STOP_CONDITION checks if stop condition is fulfilled
%   [STOP] = stop_criterium(1,dot_delta_n,dot_theta,tol) checks if the projected
%   derivative of sigma1 with respect to the elements of delta_l^{n} and
%   theta is smaller than tolerance
%
%   [STOP] = stop_criterium(2,sigma,sigma_prev,tol) checks if change in
%   sigma1 is below tolerance
if (varargin{1} == 1)
    dot_delta_n = varargin{2};
    dot_theta = varargin{3};
    tol = varargin{4};
    grad = [dot_theta'];
    for ll=1:length(dot_delta_n)
        grad =[grad;reshape(dot_delta_n{ll},[],1)];
    end
    norm_grad = norm(grad);
    STOP = (norm_grad<tol);
elseif (varargin{1} == 2)
    sigma1 = varargin{2}; sigma1_prev = varargin{3};
    tol = varargin{4};
    STOP = (abs(sigma1-sigma1_prev) <= tol*max([1,abs(sigma1)]));
else
    error('Invalid stopping criterium chosen');
end
end

function [M] = computeM(uncertain_tds,delta_used,l_new,delta,theta)
%COMPUTEM calculates D0(delta)+\SUM_{k=1}^K Dk(delta) e^{j ŧheta_k}
p = size(uncertain_tds.D{1},1);
m = size(uncertain_tds.D{1},2);
M = zeros(p,m);
for k=1:length(uncertain_tds.D)
    tildeDk = uncertain_tds.D{k};
    for id = 1:length(uncertain_tds.uD{k})
        G = uncertain_tds.uD{k}(id).G;
        H = uncertain_tds.uD{k}(id).H;
        l = l_new(uncertain_tds.uD{k}(id).l);
        tildeDk = tildeDk + delta_used(l).delta_bar*G*delta{l}*H;
    end
    tildeDk = tildeDk*exp(1j*theta(k));
    M = M+tildeDk;
end
end
function [L_SVec,SVal,R_SVec] = computeSVD(uncertain_tds,delta_used,l_new,delta,theta,nb_sv,use_svds)
% Computes nb_sv right-most singular values (and associated singular
% vectors of D0(delta)+\SUM_{k=1}^K Dk(delta) e^{j ŧheta_k}.
if ~use_svds
    M = computeM(uncertain_tds,delta_used,l_new,delta,theta);
    [L_SVec,SVal,R_SVec] = svd(M);
    L_SVec = L_SVec(:,1:nb_sv);
    R_SVec = R_SVec(:,1:nb_sv);
    SVal = SVal(1:nb_sv,1:nb_sv);
else
    error('Not implemented yet.');
end
end

function [caution_level,print_level,metadata,tol] = parse_options(options,uncertain_tds)
if (isfield(options,'caution_level'))
    caution_level = options.caution_level;
else
    caution_level = 0;
end
if (isfield(options,'print_level'))
    print_level = options.print_level;
else
    print_level = 0;
end
if isfield(options,'metadata_tds')
    metadata = options.metadata_tds;
else
    metadata = uncertain_tds_metadata(uncertain_tds);
end
if isfield(options,'tol')
    tol = options.tol;
else
    tol = 1e-8;
end
end
function [development_options] = get_development_options()
% If in ITERATE3 the update is unsuccessful (sigma1 decreases) reduce
% stepsize with this factor
development_options.step_reduction = 5;
% Minimal step size in ITERATE3
development_options.step_min = 1e-10;
% If in ITERATE 3 the update is succesful on the first try :
%   increase step size with this factor
development_options.step_increase = 2;
% Initialise step size
development_options.step_init = 1;
% Maximum number of iterations for each initialisation
development_options.max_iter = 400;

% path for delta_l^n:
%   1. delta_l^n'(t) = (I-<delta_l^n(t),.>_F delta_l^n(t))MAT_l(t) => delta_l^n(t) always norm 1
%   2. delta_l^n'(t) = MAT_l(t) and normalise delta_l^n'(t) to have unit Frobenius norm
%   3. delta_l^n'(t) = (I-<delta_l^n(t),.>_F delta_l^n(t))MAT_l(t)  if ||delta_l^n(t)||_F = 1 & <delta_l^n(t),MAT_l(t)> >0
%                    = MAT_l(t)                    else
%      Normalise S such that ||S||_F <= 1
development_options.path = 3;

% Scalar_grid:
%   0. no different initialisations for scalar uncertainties
%   1. different initialisations for scalar uncertainties
development_options.scalar_initialisations = 1;

% Stopping condition:
%   1. |dsigma/dt| < tol (derivative small)
%   2. sigma_{i} - sigma{i-1} < tol*sigma{i} (relative change in sigma is
%   small)
development_options.stop = 1;

% Maximize step size
% If in ITERATE3 the update is succesful on the first try :
%   false. continue to next iteration and increase step size for NEXT iteration
%   true.  increase step size for THIS iteration until sigma1 no longer increases
development_options.maximize_step_size = true;
% Use svds for sparse matrices instead of svd
development_options.use_svds = false;
end
function [delta_used,l_delta_used,l_new] = find_delta_used(delta,uD,L)
%FIND_DELTA_USED(local function) returns a list (delta_used) with the delta_l that are present in
%the asymptotic transfer function, a list (l_delta_used) with the indices of these delta_l in the
%original delta and a list (l_new) with new the index of the delta_l 
%in delta_used (0 if delta_l not present in delta_used)
%
% Example if delta = {delta_1,..,delta_5} and only delta_1 and delta_3
% appear in asymptotic transfer function then
%   delta_used = {delta_1,delta_3}
%   l_new = [1 0 2 0 0]

l_delta_used = [];
for k = 1:length(uD)
    if ~isempty(uD{k})
        l_delta_used = unique([l_delta_used uD{k}.l]);
    end
end
delta_used = delta(l_delta_used);
l_new = zeros(1,L);
l_new(l_delta_used) = 1:length(l_delta_used);
end
