function [metadata_sdep] = uncertain_sdep_metadata(uncertain_sdep)
%UNCERTAIN_SDEP_METADATA(local function) generates metadata associated with
%uncertain_sdep. 
%   [metadata_sdep] = uncertain_sdep_metadata(uncertain_sdep) generates
%   metadata associated with uncertain_sdep. The output argument metadata
%   is struct array with the following fields 
%       n  - dimension of the Q and P{k} matrices
%       m  - first dimension of the complex-valued uncertainty Delta
%       p  - second dimension of the complex-valued uncertainty Delta
%       KP - number of P matrices
%       L  - number of uncertainties

metadata_sdep = {};

metadata_sdep.n = size(uncertain_sdep.Q,1);
metadata_sdep.m = size(uncertain_sdep.R,2);
metadata_sdep.p = size(uncertain_sdep.S,1);

metadata_sdep.KP = length(uncertain_sdep.P);

if isfield(uncertain_sdep,'hat_delta') && ~isempty(uncertain_sdep.hat_delta)
    metadata_sdep.L = length(uncertain_sdep.hat_delta);
else
    metadata_sdep.L = 0; 
end
end

