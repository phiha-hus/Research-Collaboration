function [sigma1] = uncertain_tds_sigma1(uncertain_tds,s,delta,metadata_tds)
%UNCERTAIN_TDS_SIGMA1(local function) returns the spectral norm of the
%transfer function of a given realisation of uncertain_tds at s  
%
% [sigma1] = uncertain_tds_sigma1(uncertain_tds,s,delta) returns the
% spectral norm of the transfer function of uncertain_tds at s for given
% delta (||T(s;delta)||_2)
%
% [sigma1] = uncertain_tds_sigma1(uncertain_tds,s) returns the
% spectral norm of the transfer function of uncertain_tds at s for delta=0
% (||T(s;0)||_2)

% [sigma1] = uncertain_tds_sigma1(uncertain_tds,s,delta,metadata_tds)
% explicitly specify the metadata associated with uncertain_tds
% use delta = [] for the nominal system (delta=0)

% Planned modification:
%   - add option to maximize spectral norm over uncertainties

if nargin < 2
    error('Insufficient number of input arguments.');
end
if nargin == 2
    delta = [];
end
if nargin <= 3
    metadata_tds = uncertain_tds_metadata(uncertain_tds);
end

if metadata_tds.KC == 0 || metadata_tds.KB == 0
    fields = {'D'};
    size_mat = {[metadata_tds.p metadata_tds.m]};
else
    fields = {'A','B','C','D'}; 
    size_mat = {[metadata_tds.n metadata_tds.n],[metadata_tds.n metadata_tds.m],...
        [metadata_tds.p metadata_tds.n],[metadata_tds.p metadata_tds.m]};
end

matrices = {};
for iField = 1:length(fields)
    field = fields{iField};
    Mats = zeros(size_mat{iField});
    for k = 1:metadata_tds.(['K' field])
        Matks = uncertain_tds.(field){k};
        if ~isempty(delta)
            for iuMat = 1:length(uncertain_tds.(['u' field]){k})
                G = uncertain_tds.(['u' field]){k}(iuMat).G;
                H = uncertain_tds.(['u' field]){k}(iuMat).H;
                l = uncertain_tds.(['u' field]){k}(iuMat).l;
                Matks = Matks + G*delta{l}*H;
            end
        end
        Mats = Mats + Matks*exp(-s*uncertain_tds.(['h' field])(k));
    end
    matrices.(field) = Mats;
end
if metadata_tds.KC == 0 || metadata_tds.KB == 0
    S = svd(matrices.D);
    sigma1 = S(1);
else
    if ~metadata_tds.ddae 
        E = eye(metadata_tds.n,metadata_tds.n);
    else
        E = uncertain_tds.E;
    end
    S = svd(matrices.C*((E*s-matrices.A)\matrices.B)+matrices.D);
    sigma1 = S(1);
end


end

