function [psa,crit_delta,crit_lambda,crit_phi,crit_psi,output] = uncertain_tds_psa(uncertain_tds,options)
%UNCERTAIN_TDS_PSA Computes the  hat{delta}-pseudo spectral
%abscissa of an uncertain time delay system using the projected gradient
%flow method. 
%
% [psa] = uncertain_tds_psa(uncertain_tds) returns the hat{delta}-pseudo
% spectral abscissa of uncertain_tds
%
% [psa,crit_delta] = uncertain_tds_psa(uncertain_tds) returns also the
% critical uncertainty delta
%
% [psa,crit_delta,crit_lambda,crit_phi,crit_psi] = uncertain_tds_psa(uncertain_tds)
%  returns also the critical eigenvalue (lambda) and its associated
%  left (crit_phi) and right (crit_psi) eigenvectors
%
%  [psa,crit_delta,crit_lambda,crit_phi,crit_psi,output] =
%  uncertain_tds_psa(uncertain_tds) returns additional information about
%  computation:
%       output.nb_eig_calc - number of eigenvalue calculations needed in
%       computations
%
%  [..] = uncertain_tds_psa(uncertain_tds,options) allows to specify
%  additional options:
%     options.metadata_tds - metadata associated with uncertain_tds
%     options.print_level - 0 (quiet - default) - 1 (normal)  - 2 (verbose)
%     options.tol - tolerance on 2-norm of the derivative of psa with
%        respect to the elements of delta
%     options.early_stop - boolean function, returns as soon as the current
%       estimate for the psa is larger than 0 (useful in bisection method
%       where we are only interested in sign and not in the exact value of
%       the psa). 
%     options.caution_level - influences the number of initialisations
%        0 (small number of initialisations - default), 1, 2 (large number of initialisations)
%

% PLANNED MODIFICATIONS:
%   - add support for uncertainties on delays
%   - use other methods to select dominant poles instead of just the right
%   most
%   - avoid computations with unused delta eg. just use [] instead of zero
%     matrix


%HIGH LEVEL DESCRIPTION
% Compute alpha^{ps}(hat{delta}) by solving
% max_{delta in hat{delta}} lambda_RM(E\lambda- \sum_{k=1}^{K} \tilde{A}_k(delta) exp(-tau_k*lambda))
% with hat{delta} = {delta in R^{q1 x r1} x ... x R^{qL x rL} : ||delta_l||_F <= bar{delta_l} };
% and 
%
% Resulting path: 
% delta_l(t) = delta_l^n(t) bar{delta_l}.
% delta_l^n'(t) = MAT_l(t) - <delta_l^n(t),MAT(t)>F delta_l^n(t) if ||delta^n_l||_F = 1 & <delta^{n}_l(t),MAT(t)>F > 0
%               = MAT_l(t)                                       otherwise
%
% with MAT_l(t) = bar{delta_l}/scal(t) sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}
% (G_{l,s}^{Ak})^{T}*[Re(phi(t)) Im(phi(t))] * 
% [Re(exp(-lambda tau_k)) -Im(exp(-lambda tau_k));Im(exp(-lambda tau_k)) Re(exp(-lambda tau_k)) ] * 
% [Re(psi(t))^{T};Im(psi(t))^{T}] *(H_{l,s}^{Ak})^{T} and
% scal(t) = phi(t)^H(E+sum_{k=1}^K tau_k Ak(delta) exp(-lambda(t) tau_k) psi(t);
% where phi(t) and psi(t) respectively the left and right eigenvectors of
% E\lambda- \sum_{k=1}^{K} \tilde{A}_k(delta) exp(-tau_k*lambda) associated
% with the rightmost eigenvalue normalised such that scal(t) is real and
% strictly positive. 
%
% Along this path Re(lambda_RM(t)) will monotonically increase as
% d Re(lambda_RM(t))/dt = Re(sum_{l=1}^L (delta_bar_l/scal)<delta_l^n'(t),MAT_l(t)>_F
% 
%STEP 0: Generate starting points for scalar delta
%ITERATE 1: iterate over these starting points
%|  STEP 1: Compute the (rightmost/dominant) eigenvalues and (associated eigenvectors) of
%|          E lambda- sum_{k=1}^{K} A{k}(delta^{init}) exp(-tau_k*lambda)
%|          #FUTURE: HOW TO SELECT SUITABLE EIGENVALUES?
%|          #* Fast approximation of the Hinfty norm via optimization over spectral value sets - Guglielmi - 6.1 Multiplicity, controllability and observability
%|          #* A structured pseudo spectral method for Hinfty-norm computation of large-scale descriptor systems - Benner - 4.2 Choice eigenvalues
%|          #Balance nearness to being rightmost with large derivative (dominant.
%|          #Exponentially dominant pole (Benner) 
%|          
%|  ITERATE 2: iterate over selected eigenvalues
%|  |   STEP 2: initialise non-scalar delta_l^n
%|  |           delta_l^{n,init} = sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}(G_{l,s}^{Pk})^{T}*[Re(phi_j) Im(phi_j)] * 
%|  |                    [Re(exp(-lambda_j tau_k)) -Im(exp(-lambda_j tau_k));Im(exp(-lambda_j tau_k)) Re(exp(-lambda_j tau_k)) ] * 
%|  |                    [Re(psi_j)^{T};Im(psi_j)^{T}] *(H_{l,s}^{Pk})^{T}
%|  |           with lambda_j the jth rightmost eigenvalue of M_init, and phi_init and psi_init its associated eigenvectors
%|  |   ITERATE 3: iterate until stopping criterium is fulfiled (or maximum number of iterations is reached)
%|  |   |   STEP 3: find h such that
%|  |   |           Re(lambda_RM(delta^{it+1})) > Re(lambda_RM(delta^{it}))
%|  |   |           with
%|  |   |           delta_l^n(it+1) = delta_l^n(it) + h_{it+1}*dot_delta_l(it)


if(nargin < 2  || ~isstruct(options))
 options = struct(); 
end

[metadata_tds,print_level,tol,early_stop,caution_level] = parse_options(options,uncertain_tds);
development_options = get_development_options();



K = metadata_tds.KA;
L = metadata_tds.L;

% Find active uncertainties
[l_delta_used] = find_delta_used(uncertain_tds.uA);
used = false(1,L);
used(l_delta_used) = true;

crit_delta = cell(1,metadata_tds.L); % Stores critical delta
for l=1:metadata_tds.L
    crit_delta{l} = zeros(uncertain_tds.hat_delta(l).q,uncertain_tds.hat_delta(l).r);
end
% Compute right-most eigenvalue of nominal system as estimate for psa
[crit_phi,crit_lambda,crit_psi] =  uncertain_tds_calculate_eigenv(uncertain_tds,metadata_tds,crit_delta,1,struct()); 
psa = real(crit_lambda);

output = {};
output.nb_eig_calc = 1;

% no active uncertainties (no need for optimisation)
if ~any(l_delta_used) 
    return
end

%% STEP 0: Generate starting points for scalar delta
 
 if (caution_level == 0)
    nb_eig_start = 3; % Number of right most eigenvalues to start from.
    scalar_cut_off = 3; % If there are less than scalar_cut_off scalar perturbations then generate complete. Otherwise sample grid using randi.
    nb_rand_scalar_points = 30; %Number of of sample points for randi.
 elseif(caution_level == 1)
    nb_eig_start = 6;
    scalar_cut_off = 4;
    nb_rand_scalar_points = 70;
 else
    nb_eig_start = max([rank(uncertain_tds.E)*0.1,12]);
    scalar_cut_off = infty;
    nb_rand_scalar_points = 0;
 end
 

q_list= [uncertain_tds.hat_delta.q]; % List with row dimensions of uncertaities
r_list= [uncertain_tds.hat_delta.r]; % List with column dimensions of uncertainties
[is_scalar,scalar_count,n_scalar] = check_scalar(q_list,r_list,used); % Check which active uncertainties are scalar
if development_options.scalar_initialisations
    if n_scalar <= scalar_cut_off
        scalar_initialisations = generate_scalar_uncertainties('grid',n_scalar,3);
    else
        scalar_initialisations = generate_scalar_uncertainties('randi',n_scalar,3,nb_rand_scalar_points);
    end
else
    scalar_initialisations = zeros(1,0);
end
dimension_1_start_grid= size(scalar_initialisations,1);

 
%% ITERATE 1: iterate over these starting points 
for scalar_iter = 1:dimension_1_start_grid
    %Initialise scalar uncertainties
    
    delta_init = cell(1,L);

    scalar_init = scalar_initialisations(scalar_iter,:);
    for l=1:L
        if development_options.scalar_initialisations && is_scalar(l)
            delta_init{l} = scalar_init(scalar_count(l));
        else
            delta_init{l} = zeros(q_list(l),r_list(l));
        end
    end    

    
%% STEP 1: Compute the (rightmost) eigenvalues and (associated eigenvectors) of E lambda- sum_{k=1}^{K} A{k}(delta^{init}) exp(-tau_k*lambda)
% (needed to initialise non-scalar uncertainties)
    options_eigenv = struct();
    [Phi0,Lambda0,Psi0,~] = uncertain_tds_calculate_eigenv(uncertain_tds,metadata_tds,delta_init,nb_eig_start,options_eigenv);
    output.nb_eig_calc = output.nb_eig_calc + 1;
    nb_eig = length(Lambda0); 
%% ITERATE 2: Iterate over rightmost eigenvalues
    for eig_iter=1:nb_eig
%% STEP 2: initialise non-scalar delta_l^n, u and v.


% lambda0 is the (eig_iter)th rightmost eigenvalue of M_init, and phi0 and psi0 are its associated eigenvectors
        lambda0 = Lambda0(eig_iter);
        phi0 = Phi0(:,eig_iter);
        psi0 = Psi0(:,eig_iter);        
        
        delta = delta_init;
% Initialise non-scalar delta
% delta_l^{n,init} = sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}(G_{l,s}^{Pk})^{T}*[Re(phi_j) Im(phi_j)] * 
%                        [Re(exp(-lambda_j tau_k)) -Im(exp(-lambda_j tau_k));Im(exp(-lambda_j tau_k)) Re(exp(-lambda_j tau_k)) ] * 
%                        [Re(psi_j)^{T};Im(psi_j)^{T}*(H_{l,s}^{Pk})^{T}/||..||_F
        
        PHI = [real(phi0) imag(phi0)]; PSI = [real(psi0) imag(psi0)];
        Gamma = cell(1,K); % 1 \times K cell with \Gamma_k matrices
        for k=1:K
            term = exp(-uncertain_tds.hA(k)*lambda0);
            Gamma{k} = [real(term) -imag(term);imag(term) real(term)];
        end
        
        % Potential improvement: eliminate find outer iteration over k
        % instead over l
        for l=l_delta_used
            if ~development_options.scalar_initialisations || ~is_scalar(l)
                delta_l = zeros(q_list(l),r_list(l));
                for k=1:K
                    if ~isempty(uncertain_tds.uA{k})
                        idx_l = find([uncertain_tds.uA{k}.l] == l);
                        for s = idx_l
                            G = uncertain_tds.uA{k}(s).G;
                            H = uncertain_tds.uA{k}(s).H;
                            delta_l = delta_l + ((transp(G)*PHI)*Gamma{k}*transp(H*PSI));
                        end
                    end
                end
                norm_deltal = norm(delta_l,'fro');
                if (norm_deltal ~= 0)
                    delta{l} = delta_l/norm_deltal;
                end
            end
        end
        
        
        % Prepare inner iterations
        step = development_options.step_init; lambda_prev = -Inf;
        iter = 1; % Iteration count
        eig_calc_inner = 0; % Count eigenvalue computations in inner iteration
        options_eigenv = struct();
        [phi,lambda,psi,scal] = uncertain_tds_calculate_eigenv(uncertain_tds,metadata_tds,delta,1,options_eigenv);
        output.nb_eig_calc = output.nb_eig_calc + 1; eig_calc_inner = eig_calc_inner + 1;
        
        if (print_level >=2)
            fprintf('Scalar iteration %i/%i;  EV iteration %i/%i \n', ...
                scalar_iter,size(scalar_initialisations,1),eig_iter,nb_eig);
            fprintf('STEP %i: Re(lambda RM) = %12.6e\n',0,real(lambda))
        end
        delta_next = cell(1,metadata_tds.L);
        %% ITERATE 3: iterate until stopping criterium is fulfiled (or maximum number of iterations is reached)
        while(iter < development_options.max_iter) 
            dot_delta = calculate_dot_delta(uncertain_tds,metadata_tds,delta,phi,psi,scal,lambda); 
            if development_options.stop_criterium == 1
                STOP = stop_criterium(1,dot_delta,tol);
            else
                STOP = stop_criterium(2,lambda,lambda_prev,tol);
            end
            
            if STOP
                if (print_level>=2)
                    fprintf('Stopping criterium fulfilled. \n');
                end
                break;
            end

            
%% STEP 3: find h such that
%       Re(lambda_RM(delta^{it+1},Delta^{it+1})) > Re(lambda_RM(delta^{it},Delta^{it}))
%       with
%       delta_l^n(it+1) = delta_l^n(it) + h_{it+1}*dot_delta_l(it)
            accepted = false;
            step_prev = step;
            while(~accepted && step>development_options.step_min)
                for l=l_delta_used
                    delta_next{l} = delta{l}+step*dot_delta{l};
                    norm_delta = norm(delta_next{l},'fro');
                    if(norm_delta>1)
                        delta_next{l} = delta_next{l}/norm_delta;
                    end
                end
                options_eigenv = struct();
                options_eigenv.minimal_real_part = real(lambda)-0.1*max([1 abs(real(lambda))]);
                [phi_next,lambda_next,psi_next,scal_next] = uncertain_tds_calculate_eigenv(uncertain_tds,metadata_tds,delta_next,1,options_eigenv);
                output.nb_eig_calc = output.nb_eig_calc + 1; eig_calc_inner = eig_calc_inner + 1;
                
                if(real(lambda_next)>real(lambda))
                    accepted = true;
                    if step==step_prev
                        if (~development_options.maximize_step_size) % Increase step size for NEXT iteration
                            step = step*development_options.step_increase;
                        else %Increase step size for THIS iteration until Re(lambda) no longer increases
                            stop_inner_iterate = false;
                            while ~stop_inner_iterate
                                step = step*development_options.step_increase;
                                delta_interm = cell(1,L);
                                for l=l_delta_used
                                    delta_interm{l} = delta{l}+step*dot_delta{l};
                                    norm_deltal = norm(delta_interm{l},'fro');
                                    if (norm_deltal > 1)
                                        delta_interm{l} = delta_interm{l}/norm_deltal;
                                    end
                                end
                                options_eigenv = struct();
                                options_eigenv.minimal_real_part = real(lambda_next)-0.1*max([1 abs(real(lambda_next))]);
                                [phi_interm,lambda_interm,psi_interm,scal_interm] = uncertain_tds_calculate_eigenv(uncertain_tds,metadata_tds,delta_interm,1,options_eigenv);
                                output.nb_eig_calc = output.nb_eig_calc + 1; eig_calc_inner = eig_calc_inner + 1;
                                if (real(lambda_interm) > real(lambda_next))
                                    lambda_next = lambda_interm;
                                    phi_next = phi_interm;
                                    psi_next = psi_interm;
                                    delta_next = delta_interm;
                                    scal_next = scal_interm;
                                else
                                    stop_inner_iterate = true;
                                end
                            end
                        end
                    end
                    phi = phi_next; psi = psi_next;
                    delta = delta_next;
                    lambda_prev = lambda;
                    lambda = lambda_next;
                    scal = scal_next;
                    if print_level >= 2
                         fprintf('STEP %i: Re(lambda RM) = %12.6e - step size = %12.6e \n',iter,real(lambda),step)
                    end
                else
                    step = step/development_options.step_reduction;
                end
            end
            if(~accepted) % minimal step size reached
                if print_level >= 2
                    fprintf('Step size too small. \n')
                end
                break;
            end
            if(early_stop && real(lambda)>0) % Early stopping
                if print_level >= 2
                    fprintf('Early stopping. \n')
                end
                psa = real(lambda);
                crit_delta = delta;
                crit_lambda = lambda;
                crit_phi = phi; 
                crit_psi = psi;
                return;
            end
            iter = iter + 1;
        end

        if real(lambda)>psa
            psa = real(lambda);
            crit_delta = delta;
            crit_lambda = lambda;
            crit_phi = phi;
            crit_psi = psi;
        end

        if(iter == development_options.max_iter) % maximum number of steps reached
            if (print_level >=2)
                fprintf('Maximum number of iterations reached. \n')
            end
        end
        if (print_level ==1)
            fprintf('Scalar iteration %i/%i; EV iteration %i/%i : Re(lambda1) = %12.3e - eig calls = %i \n', ...
                scalar_iter,size(scalar_initialisations,1),eig_iter,nb_eig,real(lambda),eig_calc_inner);
        end
    end
end

end
function [STOP] = stop_criterium(varargin)
   if(varargin{1} == 1) 
       %stop_criterium(1,dot_delta,dot_u,dot_v
       % ||PGRAD_{delta,theta} sigma 1||_2) < tol
       %PGRAD projection of gradient on search space
       %PGRAD_{delta,theta} = (VEC(P_deltan_1(dsigma1/ddeltan_1)),..,VEC(P_deltan_1(dsigma1/ddeltan_L)),P_u(dsigma1/du),P_v(dsigma1/dv))
       % with dsigma1/ddeltan_l = (delta_bar_l/scal)*sum_k=0^K sum_s=1^{S_l^Pk} G_ls^{Pk}'PHI*GAMMA_k*PSI'*H_ls^{Pk}
       % where PHI = [real(phi) imag(phi)]; PSI = [real(psi) imag(psi)]; gamma_k = exp(-lambda tau_k) 
       % GAMMA_k = [real(gamma_k) -imag(gamma_k);imag(gamma_k) real(gamma_k)]
       % P_deltan_l(M) = M-<deltan_l,M>F deltan_l if ||deltan_l||_F >= 1 & <deltan_l,M> >0 
       %               = M otherwise
       % dsigma1
       dot_delta = varargin{2};
       tol = varargin{3};
       grad = [];
       for l=1:length(dot_delta)
           grad = [grad; reshape(dot_delta{l},[],1)];
       end
       STOP = norm(grad,'fro')<tol;
   else 
       %stop_criterium(2,lambda,lambda_prev,tol)
       % |lambda - lambda_prev| < tol*max([1,abs(lambda)])
       lambda = varargin{2}; lambda_prev = varargin{3}; tol = varargin{4};
       STOP = abs(lambda-lambda_prev)<(tol*max([1, abs(lambda)])) ;
   end
end

function [development_options] = get_development_options() 
    development_options.stop_criterium = 2;
    development_options.step_min = 1e-8; 
    development_options.step_init = 1; 
    development_options.step_reduction = 3;
    development_options.step_increase = 2;
    development_options.integration_method = 1;
    development_options.scalar_initialisations = true;
    development_options.maximize_step_size = false;
    development_options.max_iter = 400;
end
function [metadata_tds,print_level,tol,early_stop,caution_level] = parse_options(options,uncertain_tds)
    if isfield(options,'metadata_tds')
        metadata_tds = options.metadata_tds;
    else
        metadata_tds = uncertain_tds_metadata(uncertain_tds);
    end
    if (isfield(options,'print_level'))
        print_level = options.print_level;
    else
        print_level = 0;
    end 
    if (isfield(options,'tol'))
        tol = options.tol;
    else     
        tol = 1e-8;
    end
    if (isfield(options,'early_stop')) % stop as soon alpha > 0
        early_stop = options.early_stop;
    else
       early_stop = false;
    end
    if (isfield(options,'caution_level'))
        caution_level = options.caution_level;
    else
        caution_level = 1;
    end
end
function [dot_delta] = calculate_dot_delta(uncertain_tds,metadata_tds,delta,phi,psi,scal,lambda)
% delta_l^n'(t) = MAT_l(t) - <delta_l^n(t),MAT(t)>F delta_l^n(t) if ||delta^n_l||_F = 1 & <delta^{n}_l(t),MAT(t)>F > 0
%               = MAT_l(t)                                       otherwise
%
% MAT_l(t) = bar{delta_l}/scal(t) sum_{k=0}^{K} sum_{s=1}^{S_l^Pk}
% transp(G_{l,s}^{Pk})*[Re(phi(t)) Im(phi(t))] * 
% [Re(exp(-lambda tau_k)) -Im(exp(-lambda tau_k));Im(exp(-lambda tau_k)) Re(exp(-lambda tau_k)) ] * 
% [transp(Re(psi(t)));transp(Im(psi(t)))] *transp(H_{l,s}^{Pk}
% scal(t) = phi(t)^H(Q+sum_{k=1}^K tau_k Pk(delta) exp(-lambda(t) tau_k) psi(t);
    PHI = [real(phi) imag(phi)]; PSI = [real(psi) imag(psi)];
    Gamma = cell(1,metadata_tds.KA);
    for k=1:metadata_tds.KA % If uncertainty on delays modify this part (UNCERTAINTY DELAY)
        tauk = uncertain_tds.hA(k);
        term = exp(-tauk*lambda);
        Gamma{k} = [real(term) -imag(term);imag(term) real(term)];
    end
    dot_delta = cell(1,metadata_tds.L);
    for l=1:metadata_tds.L
        dot_delta{l} = zeros(size(delta(l)));
    end
    used = false(1,metadata_tds.L);
    for k = 1: metadata_tds.KA
        for s = 1:length(uncertain_tds.uA{k})
            l = uncertain_tds.uA{k}(s).l;
            G = uncertain_tds.uA{k}(s).G;
            H = uncertain_tds.uA{k}(s).H;
            dot_delta{l} = dot_delta{l} + (G'*PHI)*Gamma{k}*(H*PSI)';        
            used(l) = true;
        end
    end
    for l=1:length(delta)
        if used(l)
            dot_delta{l} = uncertain_tds.hat_delta(l).delta_bar/scal* dot_delta{l};
            inner_dotdelta_delta = sum(sum(dot_delta{l}.*delta{l}));
            norm_delta_l = norm(delta{l},'fro');
            if norm_delta_l>1-1e-8 && real(inner_dotdelta_delta)>0
                dot_delta{l} = (dot_delta{l} - inner_dotdelta_delta/(norm_delta_l)^2*delta{l});
            end
        end
    end
end
function [l_delta_used] = find_delta_used(uA)
    l_delta_used = [];
    for k = 1:length(uA)
        if ~isempty(uA{k})
            l_delta_used = unique([l_delta_used uA{k}.l]);
        end
    end
end

