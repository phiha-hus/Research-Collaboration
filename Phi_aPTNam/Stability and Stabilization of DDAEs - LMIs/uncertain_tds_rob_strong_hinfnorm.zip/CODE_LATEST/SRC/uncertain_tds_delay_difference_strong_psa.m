function [psa,crit_delta,crit_lambda,crit_phi,crit_psi,output] = uncertain_tds_delay_difference_strong_psa(uncertain_tds,options)
%UNCERTAIN_TDS_DELAY_DIFFERENCE_STRONG_PSA Computes the strong hat{delta}-pseudo spectral
%abscissa of the delay difference equation associated with the neutral part
%of an uncertain time delay system in ddae form using the projected gradient flow method. 
%
%


error('Not implemented yet.');
end

