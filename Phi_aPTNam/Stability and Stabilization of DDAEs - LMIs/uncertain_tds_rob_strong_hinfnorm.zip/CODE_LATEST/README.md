#UNCERTAIN\_TDS\_ROB\_STRONG\_HINFNORM

An algorithm to compute the robust strong H-infinity norm of a retarded time-delay system with real-valued, structured, Frobenius norm bounded uncertainties.


## HOW TO USE?

STEP 0) Add the folders 'SRC' and 'SRC\TDS\_EIGV' to your Matlab path

STEP 1) Create an uncertain time-delay system using the method uncertain\_tds\_create.m (some examples can be found in EXAMPLES\\example\_uncertain\_tds\_create.m).

STEP 2) Compute its robust strong H-infinity norm using uncertain\_tds\_rob\_strong\_hinfnorm.m.

## BENCHMARK PROBLEMS:

The following benchmark problems are included:

 - EXAMPLES\\benchmark\_Gumussoy\_Michiels\_2011.m : Open loop systems (to which real-valued uncertainties are added) of the benchmark problems introduced in Section 7.3 of "Fixed-order H-infinity control for interconnected systems using delay differential algebraic equations" by Suat Gumussoy and Wim Michiels (Published in SIAM Journal on Control and Optimization,49(5):2212-2238 in 2011).

 - EXAMPLES\\example\_problems\_Appeltans\_Michiels.m : Examples 2, 3 and 4 from "A pseudo-spectra based characterisation of the robust strong H-infinity norm of time-delay systems with real-valued and structured uncertainties" by Appeltans and Michiels (Preprint available on https://arxiv.org/abs/1909.07778).

## USAGE EXISTING CODE:

This package uses some code from TDS\_STABIL by Wim Michiels (files in the directory TDS\_EIGENV) to compute the right-most eigenvalues of DDAE systems. The complete TDS\_STABIL software package is available from http://twr.cs.kuleuven.be/research/software/delay-control/stab/. More information about this package can be found in "Spectrum based stability analysis and stabilization of systems described by delay differential algebraic equations. Technical Report TW582, Department of Computer Science, K.U.Leuven, December 2010." by Wim Michiels. TDS\_STABIL is released under the GNU GPL v3.0 license (available at https://www.gnu.org/licenses/gpl-3.0.html). 

## REMARKS:

 - Currently the robust strong H-infinity norm can only be computed for retarded systems. Support for DDAE systems will be added in subsequent versions.
 - Currently there is no support for systems with uncertainties on the delays. This will be added in subsequent versions.

## MORE DETAILS ON ALGORITHM?
"A pseudo-spectra based characterisation of the robust strong H-infinity norm of time-delay systems with real-valued and structured uncertainties" by Appeltans and Michiels (Preprint available on https://arxiv.org/abs/1909.07778).
