This directory contains M-files for the solution of all the examples, 
exercises and problems in the tutorial
  L.F. Shampine, S. Thompson, and J. Kierzenka, Solving Delay
  Differential Equations with DDE23.

The M-files require MATLAB 6.5 (R13) or later.
