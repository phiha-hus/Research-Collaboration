This directory contains M-files for the solution of all the examples, 
exercises and problems in the tutorial
  L.F. Shampine, S. Thompson, and J. Kierzenka, Solving Delay
  Differential Equations with DDE23.

The M-files in this directory have been updated to take advantage 
of features available in MATLAB 7.0 (R14).  In particular, nested 
functions are used to avoid passing additional arguments to the solver.
